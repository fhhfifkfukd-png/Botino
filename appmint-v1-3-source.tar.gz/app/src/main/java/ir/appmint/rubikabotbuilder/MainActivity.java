package ir.appmint.rubikabotbuilder;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String START_URL = "file:///android_asset/index.html";
    private static final String RUBIKA_API_BASE = "https://botapi.rubika.ir/v3/";
    private static final int CONNECT_TIMEOUT_MS = 15_000;
    private static final int READ_TIMEOUT_MS = 15_000;
    private static final int MAX_RESPONSE_BYTES = 2 * 1024 * 1024;

    private WebView webView;
    private static final int REQUEST_POST_NOTIFICATIONS = 7412;
    private String pendingBackgroundBotJson;
    private String pendingBackgroundCallbackId;
    private final ExecutorService networkExecutor = Executors.newFixedThreadPool(3);

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23, 21, 44));
        getWindow().setNavigationBarColor(Color.rgb(23, 21, 44));
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(23, 21, 44));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AppMintNativeBridge(), "AppMintNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternalUrl(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternalUrl(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installPromiseBridge(view);
            }
        });

        setContentView(webView);
        webView.loadUrl(START_URL);
    }

    private boolean handleExternalUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme();
        if ("file".equalsIgnoreCase(scheme)) {
            String path = uri.getPath() == null ? "" : uri.getPath();
            return !path.startsWith("/android_asset/");
        }
        if ("about".equalsIgnoreCase(scheme)) {
            return false;
        }
        if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
                // Do not crash the app when the device has no browser handler.
            }
            return true;
        }
        return true;
    }

    private void installPromiseBridge(WebView view) {
        String script = "(function(){"
                + "if(window.__appMintBridgeInstalled)return;"
                + "window.__appMintBridgeInstalled=true;"
                + "const pending=new Map();let seq=0;"
                + "window.__appMintResolve=function(id,responseText){const item=pending.get(id);if(!item)return;pending.delete(id);clearTimeout(item.timer);item.resolve(responseText);};"
                + "window.__appMintReject=function(id,message){const item=pending.get(id);if(!item)return;pending.delete(id);clearTimeout(item.timer);item.reject(new Error(String(message||'ارتباط بومی ناموفق بود.')));};"
                + "window.AppMint=window.AppMint||{};"
                + "function callNative(method,payload,timeout){return new Promise(function(resolve,reject){"
                + "const id=String(++seq)+'_'+Date.now();"
                + "const timer=setTimeout(function(){pending.delete(id);reject(new Error('درخواست بومی بیش از حد طول کشید.'));},timeout||25000);"
                + "pending.set(id,{resolve:resolve,reject:reject,timer:timer});"
                + "try{window.AppMintNative[method](payload||'',id);}"
                + "catch(error){pending.delete(id);clearTimeout(timer);reject(error);}"
                + "});}"
                + "window.AppMint.rubikaRequest=function(request){return callNative('rubikaRequest',JSON.stringify(request||{}),18000);};"
                + "window.AppMint.rubikaRequestForBot=function(request){return callNative('rubikaRequestForBot',JSON.stringify(request||{}),18000);};"
                + "window.AppMint.startBackgroundBot=function(bot){return callNative('startBackgroundBot',JSON.stringify(bot||{}),30000);};"
                + "window.AppMint.stopBackgroundBot=function(botId){return callNative('stopBackgroundBot',String(botId||''),15000);};"
                + "window.AppMint.removeBackgroundBot=function(botId){return callNative('removeBackgroundBot',String(botId||''),15000);};"
                + "window.AppMint.resumeBackgroundBot=function(botId){return callNative('resumeBackgroundBot',String(botId||''),30000);};"
                + "window.AppMint.getBackgroundStatus=function(){return callNative('getBackgroundStatus','',15000);};"
                + "window.AppMint.setPollingInterval=function(seconds){return callNative('setPollingInterval',String(seconds),15000);};"
                + "window.AppMint.updateBackgroundBotConfig=function(payload){return callNative('updateBackgroundBotConfig',JSON.stringify(payload||{}),15000);};"
                + "})();";
        view.evaluateJavascript(script, null);
    }

    private final class AppMintNativeBridge {

        @JavascriptInterface
        public void rubikaRequestForBot(String requestJson, String callbackId) {
            if (!validCallback(callbackId)) return;
            try {
                JSONObject request = new JSONObject(requestJson == null ? "{}" : requestJson);
                String botId = request.optString("id", "").trim();
                String method = request.optString("method", "").trim();
                JSONObject payload = request.optJSONObject("payload");
                if (payload == null) payload = new JSONObject();
                JSONObject saved = BotCredentialVault.get(MainActivity.this, botId);
                String token = saved == null ? "" : saved.optString("token", "");
                if (token.isEmpty()) throw new IllegalStateException("توکن امن ربات پیدا نشد؛ دوباره آن را متصل کن.");
                if (!method.matches("[A-Za-z][A-Za-z0-9]{0,63}")) throw new IllegalArgumentException("نام متد API معتبر نیست.");
                final JSONObject requestPayload = payload;
                networkExecutor.execute(() -> {
                    try { postSuccess(callbackId, sendRubikaRequest(token, method, requestPayload)); }
                    catch (Exception error) { postFailure(callbackId, error.getMessage() == null ? "درخواست ناموفق بود." : error.getMessage()); }
                });
            } catch (Exception error) {
                postFailure(callbackId, error.getMessage() == null ? "درخواست ربات ناموفق بود." : error.getMessage());
            }
        }

        @JavascriptInterface
        public void startBackgroundBot(String botJson, String callbackId) {
            if (!validCallback(callbackId)) return;
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                pendingBackgroundBotJson = botJson;
                pendingBackgroundCallbackId = callbackId;
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_POST_NOTIFICATIONS));
                return;
            }
            startBackgroundBotNow(botJson, callbackId, true);
        }

        @JavascriptInterface
        public void stopBackgroundBot(String botId, String callbackId) {
            if (!validCallback(callbackId)) return;
            String safeId = botId == null ? "" : botId.trim();
            if (safeId.isEmpty()) { postFailure(callbackId, "شناسه ربات نامعتبر است."); return; }
            if (BotForegroundService.isRunning()) {
                Intent intent = new Intent(MainActivity.this, BotForegroundService.class);
                intent.setAction(BotForegroundService.ACTION_STOP);
                intent.putExtra(BotForegroundService.EXTRA_BOT_ID, safeId);
                try { startService(intent); postSuccess(callbackId, "{\"stopped\":true}"); }
                catch (Exception error) { postFailure(callbackId, "توقف سرویس ناموفق بود: " + error.getMessage()); }
            } else {
                BotCredentialVault.setEnabled(MainActivity.this, safeId, false);
                postSuccess(callbackId, "{\"stopped\":true}");
            }
        }

        @JavascriptInterface
        public void removeBackgroundBot(String botId, String callbackId) {
            if (!validCallback(callbackId)) return;
            String safeId = botId == null ? "" : botId.trim();
            if (safeId.isEmpty()) { postFailure(callbackId, "شناسه ربات نامعتبر است."); return; }
            BotCredentialVault.remove(MainActivity.this, safeId);
            if (BotForegroundService.isRunning()) {
                Intent intent = new Intent(MainActivity.this, BotForegroundService.class);
                intent.setAction(BotForegroundService.ACTION_REMOVE_BOT);
                intent.putExtra(BotForegroundService.EXTRA_BOT_ID, safeId);
                try { startService(intent); } catch (Exception ignored) { }
            }
            postSuccess(callbackId, "{\"removed\":true}");
        }

        @JavascriptInterface
        public void resumeBackgroundBot(String botId, String callbackId) {
            if (!validCallback(callbackId)) return;
            String safeId = botId == null ? "" : botId.trim();
            JSONObject saved = BotCredentialVault.get(MainActivity.this, safeId);
            if (saved == null) { postFailure(callbackId, "توکن امن این ربات در دسترس نیست؛ دوباره آن را متصل کن."); return; }
            try { saved.put("enabled", true); BotCredentialVault.put(MainActivity.this, safeId, saved); }
            catch (Exception error) { postFailure(callbackId, "بازیابی تنظیمات ربات ناموفق بود."); return; }
            startBackgroundBotNow(saved.toString(), callbackId, Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
        }

        @JavascriptInterface
        public void updateBackgroundBotConfig(String payloadJson, String callbackId) {
            if (!validCallback(callbackId)) return;
            try {
                JSONObject payload = new JSONObject(payloadJson == null ? "{}" : payloadJson);
                String id = payload.optString("id", "").trim();
                JSONObject config = payload.optJSONObject("config");
                if (id.isEmpty() || config == null) throw new IllegalArgumentException("تنظیمات ربات معتبر نیست.");
                JSONObject saved = BotCredentialVault.get(MainActivity.this, id);
                if (saved == null) throw new IllegalStateException("این ربات اجرای پس‌زمینه فعالی ندارد.");
                saved.put("config", config);
                BotCredentialVault.put(MainActivity.this, id, saved);
                if (BotForegroundService.isRunning()) {
                    Intent intent = new Intent(MainActivity.this, BotForegroundService.class);
                    intent.setAction(BotForegroundService.ACTION_UPDATE_CONFIG);
                    intent.putExtra(BotForegroundService.EXTRA_BOT_ID, id);
                    intent.putExtra("bot_config", config.toString());
                    startService(intent);
                }
                postSuccess(callbackId, "{\"updated\":true}");
            } catch (Exception error) {
                postFailure(callbackId, "به‌روزرسانی ربات پس‌زمینه ناموفق بود: " + error.getMessage());
            }
        }

        @JavascriptInterface
        public void setPollingInterval(String secondsText, String callbackId) {
            if (!validCallback(callbackId)) return;
            try {
                int seconds = Integer.parseInt(secondsText == null ? "2" : secondsText.trim());
                if (seconds < 1 || seconds > 5) throw new IllegalArgumentException("فاصله پولینگ باید بین ۱ تا ۵ ثانیه باشد.");
                getSharedPreferences("appmint_runtime_settings", MODE_PRIVATE)
                        .edit().putInt("poll_interval_seconds", seconds).apply();
                if (BotForegroundService.isRunning()) {
                    Intent intent = new Intent(MainActivity.this, BotForegroundService.class);
                    intent.setAction(BotForegroundService.ACTION_UPDATE_POLL_INTERVAL);
                    intent.putExtra(BotForegroundService.EXTRA_POLL_INTERVAL_SECONDS, seconds);
                    startService(intent);
                }
                JSONObject result = new JSONObject();
                result.put("saved", true);
                result.put("seconds", seconds);
                postSuccess(callbackId, result.toString());
            } catch (Exception error) {
                postFailure(callbackId, error.getMessage() == null ? "ذخیره فاصله پولینگ ناموفق بود." : error.getMessage());
            }
        }

        @JavascriptInterface
        public void getBackgroundStatus(String callbackId) {
            if (!validCallback(callbackId)) return;
            JSONObject result = new JSONObject();
            try {
                java.util.Map<String, JSONObject> enabledBots = BotCredentialVault.getEnabledAll(MainActivity.this);
                java.util.ArrayList<String> botIds = new java.util.ArrayList<>(enabledBots.keySet());
                if (!botIds.isEmpty() && !BotForegroundService.isRunning()) {
                    Intent restart = new Intent(MainActivity.this, BotForegroundService.class);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(restart);
                    else startService(restart);
                }
                org.json.JSONArray stats = new org.json.JSONArray();
                for (java.util.Map.Entry<String, JSONObject> entry : enabledBots.entrySet()) {
                    JSONObject item = new JSONObject();
                    item.put("id", entry.getKey());
                    item.put("totalUpdates", entry.getValue().optInt("totalUpdates", 0));
                    item.put("totalActions", entry.getValue().optInt("totalActions", 0));
                    item.put("lastError", entry.getValue().optString("lastError", ""));
                    JSONObject savedConfig = entry.getValue().optJSONObject("config");
                    item.put("config", savedConfig == null ? new JSONObject() : savedConfig);
                    stats.put(item);
                }
                result.put("ids", new org.json.JSONArray(botIds));
                result.put("bots", stats);
                result.put("serviceRunning", BotForegroundService.isRunning());
                result.put("notificationPermission", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
                postSuccess(callbackId, result.toString());
            } catch (Exception error) { postFailure(callbackId, "خواندن وضعیت پس‌زمینه ناموفق بود."); }
        }

        private boolean validCallback(String callbackId) {
            return callbackId != null && callbackId.length() <= 100;
        }

        @JavascriptInterface
        public void rubikaRequest(String requestJson, String callbackId) {
            if (callbackId == null || callbackId.length() > 100) {
                return;
            }
            final String safeCallbackId = callbackId;
            final String token;
            final String method;
            final JSONObject payload;

            try {
                JSONObject request = new JSONObject(requestJson == null ? "{}" : requestJson);
                token = request.optString("token", "").trim();
                method = request.optString("method", "").trim();
                payload = request.optJSONObject("payload") == null
                        ? new JSONObject()
                        : request.optJSONObject("payload");
            } catch (JSONException error) {
                postFailure(safeCallbackId, "درخواست ارسالی معتبر نیست.");
                return;
            }

            if (token.isEmpty() || token.length() > 4096) {
                postFailure(safeCallbackId, "توکن ربات خالی یا نامعتبر است.");
                return;
            }
            if (!method.matches("[A-Za-z][A-Za-z0-9]{0,63}")) {
                postFailure(safeCallbackId, "نام متد API معتبر نیست.");
                return;
            }

            networkExecutor.execute(() -> {
                try {
                    String response = sendRubikaRequest(token, method, payload);
                    postSuccess(safeCallbackId, response);
                } catch (Exception error) {
                    String message = error.getMessage();
                    postFailure(safeCallbackId,
                            message == null || message.trim().isEmpty()
                                    ? "ارتباط با API روبیکا ناموفق بود."
                                    : message);
                }
            });
        }
    }

    private void startBackgroundBotNow(String botJson, String callbackId, boolean notificationPermission) {
        try {
            JSONObject bot = new JSONObject(botJson == null ? "{}" : botJson);
            String id = bot.optString("id", "").trim();
            String token = bot.optString("token", "").trim();
            if (id.isEmpty() || token.isEmpty() || token.length() > 4096) {
                postFailure(callbackId, "اطلاعات ربات یا توکن معتبر نیست.");
                return;
            }
            Intent intent = new Intent(this, BotForegroundService.class);
            intent.setAction(BotForegroundService.ACTION_START);
            intent.putExtra(BotForegroundService.EXTRA_BOT, bot.toString());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
            else startService(intent);
            JSONObject result = new JSONObject();
            result.put("started", true);
            result.put("notificationPermission", notificationPermission);
            postSuccess(callbackId, result.toString());
        } catch (Exception error) {
            postFailure(callbackId, "شروع اجرای پس‌زمینه ممکن نشد: " + error.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_POST_NOTIFICATIONS && pendingBackgroundBotJson != null && pendingBackgroundCallbackId != null) {
            String botJson = pendingBackgroundBotJson;
            String callbackId = pendingBackgroundCallbackId;
            pendingBackgroundBotJson = null;
            pendingBackgroundCallbackId = null;
            boolean granted = Build.VERSION.SDK_INT < 33 || (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED);
            // Android permits a foreground service to run when notification permission is denied.
            // Its ongoing status remains visible in Android's foreground-service task manager.
            startBackgroundBotNow(botJson, callbackId, granted);
        }
    }

    private String sendRubikaRequest(String token, String method, JSONObject payload) throws Exception {
        String encodedToken = URLEncoder.encode(token, "UTF-8").replace("+", "%20");
        URL url = new URL(RUBIKA_API_BASE + encodedToken + "/" + method);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setUseCaches(false);
        connection.setDoOutput(true);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        connection.setFixedLengthStreamingMode(body.length);

        try {
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
                output.flush();
            }

            int statusCode = connection.getResponseCode();
            InputStream stream = statusCode >= 400 ? connection.getErrorStream() : connection.getInputStream();
            String responseBody = stream == null ? "{}" : readLimited(stream);

            try {
                new JSONObject(responseBody);
            } catch (JSONException invalidJson) {
                throw new IOException("پاسخ روبیکا JSON معتبر نیست (HTTP " + statusCode + ").");
            }

            if (statusCode < 200 || statusCode >= 300) {
                throw new IOException(extractApiError(responseBody, statusCode));
            }
            return responseBody;
        } finally {
            connection.disconnect();
        }
    }

    private String readLimited(InputStream input) throws IOException {
        try (InputStream stream = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int count;
            while ((count = stream.read(buffer)) != -1) {
                total += count;
                if (total > MAX_RESPONSE_BYTES) {
                    throw new IOException("حجم پاسخ روبیکا بیش از حد مجاز است.");
                }
                output.write(buffer, 0, count);
            }
            return output.toString("UTF-8");
        }
    }

    private String extractApiError(String responseBody, int statusCode) {
        try {
            JSONObject body = new JSONObject(responseBody);
            String description = body.optString("description", "");
            if (description.isEmpty()) description = body.optString("message", "");
            if (description.isEmpty()) description = body.optString("error", "");
            if (!description.isEmpty()) return description;
        } catch (JSONException ignored) {
            // Fall through to the generic HTTP message.
        }
        return "خطای سرور روبیکا (HTTP " + statusCode + ").";
    }

    private void postSuccess(String callbackId, String responseText) {
        runOnUiThread(() -> {
            if (webView == null) return;
            String script = "window.__appMintResolve && window.__appMintResolve("
                    + JSONObject.quote(callbackId) + "," + JSONObject.quote(responseText) + ");";
            webView.evaluateJavascript(script, null);
        });
    }

    private void postFailure(String callbackId, String message) {
        runOnUiThread(() -> {
            if (webView == null) return;
            String script = "window.__appMintReject && window.__appMintReject("
                    + JSONObject.quote(callbackId) + "," + JSONObject.quote(message) + ");";
            webView.evaluateJavascript(script, null);
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AppMintNative");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        networkExecutor.shutdownNow();
        super.onDestroy();
    }
}
