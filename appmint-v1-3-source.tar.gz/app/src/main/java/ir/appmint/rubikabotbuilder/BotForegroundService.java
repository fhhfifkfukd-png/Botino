package ir.appmint.rubikabotbuilder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** User-visible foreground service that keeps explicitly enabled Rubika bots polling. */
public class BotForegroundService extends Service {
    public static final String ACTION_START = "ir.appmint.action.START_BOT";
    public static final String ACTION_STOP = "ir.appmint.action.STOP_BOT";
    public static final String ACTION_STOP_ALL = "ir.appmint.action.STOP_ALL";
    public static final String ACTION_UPDATE_CONFIG = "ir.appmint.action.UPDATE_CONFIG";
    public static final String ACTION_REMOVE_BOT = "ir.appmint.action.REMOVE_BOT";
    public static final String EXTRA_BOT = "bot_json";
    public static final String EXTRA_BOT_ID = "bot_id";
    public static final String ACTION_UPDATE_POLL_INTERVAL = "ir.appmint.action.UPDATE_POLL_INTERVAL";
    public static final String EXTRA_POLL_INTERVAL_SECONDS = "poll_interval_seconds";
    private static final String CHANNEL_ID = "appmint_bot_service";
    private static final int NOTIFICATION_ID = 7182;
    private static final String API_BASE = "https://botapi.rubika.ir/v3/";
    private static final int DEFAULT_POLL_INTERVAL_SECONDS = 2;
    private static final int MIN_POLL_INTERVAL_SECONDS = 1;
    private static final int MAX_POLL_INTERVAL_SECONDS = 5;
    private static final int MAX_RESPONSE_BYTES = 2 * 1024 * 1024;

    private static volatile boolean running;
    private final Map<String, JSONObject> bots = new ConcurrentHashMap<>();
    private final Map<String, ArrayDeque<Long>> floodWindows = new ConcurrentHashMap<>();
    private ScheduledExecutorService executor;
    private ScheduledFuture<?> pollingFuture;
    private volatile int pollIntervalSeconds = DEFAULT_POLL_INTERVAL_SECONDS;
    private PowerManager.WakeLock wakeLock;

    public static boolean isRunning() { return running; }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        createNotificationChannel();
        pollIntervalSeconds = getSharedPreferences("appmint_runtime_settings", MODE_PRIVATE)
                .getInt("poll_interval_seconds", DEFAULT_POLL_INTERVAL_SECONDS);
        if (pollIntervalSeconds < MIN_POLL_INTERVAL_SECONDS || pollIntervalSeconds > MAX_POLL_INTERVAL_SECONDS) {
            pollIntervalSeconds = DEFAULT_POLL_INTERVAL_SECONDS;
        }
        startAsForeground();
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AppMint:BotPolling");
            wakeLock.setReferenceCounted(false);
            try { wakeLock.acquire(); } catch (RuntimeException ignored) { }
        }
        executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread thread = new Thread(r, "AppMint-Bot-Polling");
            thread.setDaemon(true);
            return thread;
        });
        bots.putAll(BotCredentialVault.getEnabledAll(this));
        schedulePolling();
        updateNotification();
    }

    private void startAsForeground() {
        Notification notification = buildNotification("در حال آماده‌سازی ربات‌ها…");
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            if (bots.isEmpty()) {
                bots.putAll(BotCredentialVault.getEnabledAll(this));
                updateNotification();
            }
            if (bots.isEmpty()) {
                stopSelf(startId);
                return START_NOT_STICKY;
            }
            return START_STICKY;
        }
        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            String raw = intent.getStringExtra(EXTRA_BOT);
            try {
                JSONObject bot = new JSONObject(raw == null ? "{}" : raw);
                String id = bot.optString("id", "");
                String token = bot.optString("token", "");
                if (id.isEmpty() || token.isEmpty() || token.length() > 4096) {
                    throw new IllegalArgumentException("شناسه یا توکن ربات معتبر نیست.");
                }
                bot.put("enabled", true);
                BotCredentialVault.put(this, id, bot);
                bots.put(id, bot);
                updateNotification();
            } catch (Exception error) {
                android.util.Log.e("AppMintService", "Could not save bot", error);
                updateNotification();
            }
        } else if (ACTION_STOP.equals(action)) {
            String id = intent.getStringExtra(EXTRA_BOT_ID);
            if (id != null) {
                bots.remove(id);
                BotCredentialVault.setEnabled(this, id, false);
            }
            stopIfEmpty(startId);
        } else if (ACTION_REMOVE_BOT.equals(action)) {
            String id = intent.getStringExtra(EXTRA_BOT_ID);
            if (id != null) { bots.remove(id); BotCredentialVault.remove(this, id); }
            stopIfEmpty(startId);
        } else if (ACTION_UPDATE_POLL_INTERVAL.equals(action)) {
            int requested = intent.getIntExtra(EXTRA_POLL_INTERVAL_SECONDS, DEFAULT_POLL_INTERVAL_SECONDS);
            if (requested >= MIN_POLL_INTERVAL_SECONDS && requested <= MAX_POLL_INTERVAL_SECONDS) {
                pollIntervalSeconds = requested;
                getSharedPreferences("appmint_runtime_settings", MODE_PRIVATE)
                        .edit().putInt("poll_interval_seconds", requested).apply();
                reschedulePolling();
                updateNotification();
            }
        } else if (ACTION_UPDATE_CONFIG.equals(action)) {
            String id = intent.getStringExtra(EXTRA_BOT_ID);
            String rawConfig = intent.getStringExtra("bot_config");
            JSONObject bot = id == null ? null : bots.get(id);
            if (bot != null && rawConfig != null) {
                try {
                    bot.put("config", new JSONObject(rawConfig));
                    BotCredentialVault.put(this, id, bot);
                } catch (Exception error) {
                    android.util.Log.w("AppMintService", "Could not update bot config", error);
                }
            }
            updateNotification();
        } else if (ACTION_STOP_ALL.equals(action)) {
            bots.clear();
            BotCredentialVault.clear(this);
            stopSelf(startId);
        }
        return START_STICKY;
    }

    private void schedulePolling() {
        if (executor == null || executor.isShutdown()) return;
        pollingFuture = executor.scheduleWithFixedDelay(
                this::pollAllBotsSafely, 0, pollIntervalSeconds, TimeUnit.SECONDS);
    }

    private void reschedulePolling() {
        if (executor == null || executor.isShutdown()) return;
        if (pollingFuture != null) pollingFuture.cancel(false);
        schedulePolling();
    }

    private void pollAllBotsSafely() {
        for (String id : new ArrayList<>(bots.keySet())) {
            JSONObject bot = bots.get(id);
            if (bot == null) continue;
            try {
                pollBot(id, bot);
                if (bot.has("lastError")) {
                    bot.remove("lastError");
                    BotCredentialVault.put(this, id, bot);
                }
            } catch (Exception error) {
                String message = error.getMessage() == null ? "خطای ارتباط با روبیکا" : error.getMessage();
                android.util.Log.w("AppMintService", "Polling failed for " + id + ": " + message);
                if (!message.equals(bot.optString("lastError", ""))) {
                    try { bot.put("lastError", message); BotCredentialVault.put(this, id, bot); }
                    catch (Exception ignored) { }
                }
            }
        }
        updateNotification();
    }

    private void pollBot(String id, JSONObject bot) throws Exception {
        String token = bot.optString("token", "");
        if (token.isEmpty()) return;
        JSONObject payload = new JSONObject();
        payload.put("limit", 50);
        String offset = bot.optString("offsetId", "");
        if (!offset.isEmpty()) payload.put("offset_id", offset);
        JSONObject result = unwrap(api(token, "getUpdates", payload));
        JSONArray updates = result.optJSONArray("updates");
        String nextOffset = result.optString("next_offset_id", result.optString("nextOffsetId", ""));
        boolean changed = false;
        if (!nextOffset.isEmpty() && !nextOffset.equals(bot.optString("offsetId", ""))) {
            bot.put("offsetId", nextOffset);
            changed = true;
        }
        if (updates != null && updates.length() > 0) {
            bot.put("totalUpdates", bot.optInt("totalUpdates", 0) + updates.length());
            changed = true;
            for (int i = 0; i < updates.length(); i++) {
                JSONObject update = updates.optJSONObject(i);
                if (update == null) continue;
                try { processUpdate(bot, update); }
                catch (Exception error) { android.util.Log.w("AppMintService", "Update processing failed", error); }
            }
        }
        if (changed) BotCredentialVault.put(this, id, bot);
    }

    private void processUpdate(JSONObject bot, JSONObject update) throws Exception {
        JSONObject message = update.optJSONObject("new_message");
        String chatId = update.optString("chat_id", "");
        if (chatId.isEmpty() && message != null) chatId = message.optString("chat_id", "");
        if (chatId.isEmpty()) return;

        String template = bot.optString("templateId", "");
        String botName = bot.optString("name", "AppMint");
        JSONObject config = bot.optJSONObject("config");
        if (config == null) config = new JSONObject();
        String helpText = config.optString("welcomeMessage", config.optString("supportWelcome", "سلام! به ربات " + botName + " خوش اومدی 🌱\nبرای راهنما /help رو بفرست."));

        if ("StartedBot".equalsIgnoreCase(update.optString("type", ""))) {
            sendUserStartMenu(bot, chatId, helpText);
            return;
        }
        if (!"NewMessage".equalsIgnoreCase(update.optString("type", "")) || message == null) return;
        if ("Bot".equalsIgnoreCase(message.optString("sender_type", ""))) return;
        String text = message.optString("text", "").trim();
        if (text.isEmpty()) return;
        String messageId = message.optString("message_id", "");
        String senderId = message.optString("sender_id", "کاربر");
        String command = text.split("\\s+", 2)[0];
        if (command.contains("@")) command = command.substring(0, command.indexOf('@'));
        if ("/myid".equalsIgnoreCase(command)) {
            sendMessage(bot, chatId,
                    "🆔 شناسه این گفتگو:\n" + chatId + "\n\n👤 شناسه کاربر:\n" + senderId,
                    messageId);
            return;
        }

        // Secure one-time owner claim: the code is accepted only in a private User chat.
        Matcher claimMatcher = Pattern.compile("^(?:/claim|مالک)\\s+(\\d{6})$", Pattern.CASE_INSENSITIVE).matcher(text);
        if (claimMatcher.matches()) {
            handleOwnerClaim(bot, config, tokenOf(bot), chatId, senderId, claimMatcher.group(1), messageId);
            return;
        }

        if (!config.optString("ownerUserId", "").isEmpty()
                && config.optString("ownerUserId", "").equals(senderId)
                && config.optString("ownerChatId", "").equals(chatId)
                && handleOwnerCommand(bot, config, chatId, senderId, text, messageId)) {
            return;
        }

        if ("/start".equalsIgnoreCase(text) || "/help".equalsIgnoreCase(text)) {
            sendUserStartMenu(bot, chatId, helpText);
            return;
        }

        if ("support".equals(template)) {
            JSONArray waiting = config.optJSONArray("supportWaiting"); if (waiting == null) waiting = new JSONArray();
            JSONArray cleanedWaiting = new JSONArray(); boolean wasWaiting = false; long now = System.currentTimeMillis();
            for (int i = 0; i < waiting.length(); i++) {
                JSONObject entry = waiting.optJSONObject(i); if (entry == null) continue;
                boolean sameUser = String.valueOf(chatId).equals(entry.optString("chatId")) && String.valueOf(senderId).equals(entry.optString("senderId"));
                boolean fresh = now - entry.optLong("createdAt", 0L) <= 30L * 60L * 1000L;
                if (sameUser && fresh) wasWaiting = true;
                else if (fresh) cleanedWaiting.put(entry);
            }
            if ("🎫 ثبت درخواست".equals(text) || "/ticket".equalsIgnoreCase(text)) {
                JSONObject entry = new JSONObject(); entry.put("chatId", chatId); entry.put("senderId", senderId); entry.put("createdAt", System.currentTimeMillis());
                cleanedWaiting.put(entry); config.put("supportWaiting", cleanedWaiting); saveBotConfig(bot, config);
                sendMessage(bot, chatId, "🎫 لطفاً متن درخواستت را در پیام بعدی بفرست. اطلاعاتت فقط برای رسیدگی به پشتیبانی استفاده می‌شود.", messageId); return;
            }
            if ("📋 پیگیری درخواست".equals(text)) {
                config.put("supportWaiting", cleanedWaiting); saveBotConfig(bot, config);
                JSONArray tickets = config.optJSONArray("supportTickets"); StringBuilder out = new StringBuilder("📋 درخواست‌های اخیر شما\n"); int found = 0;
                if (tickets != null) for (int i = tickets.length() - 1; i >= 0 && found < 5; i--) { JSONObject t = tickets.optJSONObject(i); if (t != null && senderId.equals(t.optString("senderId"))) { out.append("#").append(t.optString("code")).append(" — ").append(t.optString("status")).append("\n"); found++; } }
                if (found == 0) out.append("درخواستی برای نمایش وجود ندارد."); sendMessage(bot, chatId, out.toString(), messageId); return;
            }
            if (wasWaiting) {
                JSONArray tickets = config.optJSONArray("supportTickets"); if (tickets == null) tickets = new JSONArray();
                String code = String.format(java.util.Locale.ROOT, "%07d", System.currentTimeMillis() % 10_000_000L);
                JSONObject ticket = new JSONObject(); ticket.put("code", code); ticket.put("chatId", chatId); ticket.put("senderId", senderId);
                ticket.put("text", text); ticket.put("createdAt", System.currentTimeMillis()); ticket.put("status", "باز");
                JSONArray initialConversation = new JSONArray(); JSONObject firstMessage = new JSONObject(); firstMessage.put("by", "user"); firstMessage.put("text", text); firstMessage.put("createdAt", System.currentTimeMillis()); initialConversation.put(firstMessage); ticket.put("conversation", initialConversation); tickets.put(ticket);
                JSONArray trimmed = new JSONArray(); for (int i = Math.max(0, tickets.length() - 50); i < tickets.length(); i++) trimmed.put(tickets.get(i));
                config.put("supportTickets", trimmed); config.put("supportWaiting", cleanedWaiting); saveBotConfig(bot, config);
                sendMessage(bot, chatId, "✅ درخواست ثبت شد.\nکد پیگیری: #" + code + "\nبرای بررسی وضعیت، «پیگیری درخواست» را بزن.", messageId);
                String ownerChat = config.optString("ownerChatId", ""); if (!ownerChat.isEmpty()) sendMessageWithKeypad(bot, ownerChat, "🎫 تیکت جدید #" + code + "\nکاربر: " + senderId + "\n" + text, new String[][]{{"📥 درخواست‌های جدید"}, {"✅ بستن آخرین تیکت"}}, null);
                return;
            }
            JSONArray activeTickets = config.optJSONArray("supportTickets"); JSONObject activeTicket = null;
            if (activeTickets != null) for (int i = activeTickets.length() - 1; i >= 0; i--) { JSONObject candidate = activeTickets.optJSONObject(i); if (candidate != null && senderId.equals(candidate.optString("senderId")) && chatId.equals(candidate.optString("chatId")) && !"بسته".equals(candidate.optString("status"))) { activeTicket = candidate; break; } }
            if (activeTicket != null) {
                JSONArray conversation = activeTicket.optJSONArray("conversation"); if (conversation == null) conversation = new JSONArray();
                JSONObject entry = new JSONObject(); entry.put("by", "user"); entry.put("text", text); entry.put("createdAt", System.currentTimeMillis()); conversation.put(entry);
                JSONArray trimmedConversation = new JSONArray(); for (int i = Math.max(0, conversation.length() - 30); i < conversation.length(); i++) trimmedConversation.put(conversation.get(i));
                activeTicket.put("conversation", trimmedConversation); config.put("supportTickets", activeTickets); saveBotConfig(bot, config);
                sendMessage(bot, chatId, "✅ پیام تو به تیکت #" + activeTicket.optString("code") + " اضافه شد.", messageId);
                String ownerChat = config.optString("ownerChatId", ""); if (!ownerChat.isEmpty()) sendMessage(bot, ownerChat, "💬 پیام تازه در تیکت #" + activeTicket.optString("code") + "\n" + text, null);
                return;
            }
            sendMessage(bot, chatId, "برای ثبت درخواست، دکمه «🎫 ثبت درخواست» را بزن.", messageId); return;
        }

        if ("guardian".equals(template)) {
            if ("/rules".equalsIgnoreCase(text) || "📜 قوانین گروه".equals(text) || "📌 قوانین".equals(text)) {
                sendMessage(bot, chatId, config.optString("rulesText", "قوانین گروه: احترام، پرهیز از اسپم و رعایت موضوع گروه 🌿"), messageId);
                return;
            }
            boolean filterWords = config.optBoolean("filterWords", true);
            boolean filterLinks = config.optBoolean("filterLinks", true);
            String lower = text.toLowerCase();
            String blocked = config.optString("blockedWords", "اسپم\nتبلیغ ناخواسته");
            boolean wordHit = false;
            for (String word : blocked.split("\\r?\\n")) {
                String candidate = word.trim().toLowerCase();
                if (filterWords && !candidate.isEmpty() && lower.contains(candidate)) { wordHit = true; break; }
            }
            boolean linkHit = filterLinks && (lower.contains("https://") || lower.contains("http://") || lower.contains("www."));
            boolean floodHit = config.optBoolean("filterFlood", true)
                    && isFlooding(chatId, senderId, config.optInt("maxMessagesPer10s", 6));
            boolean duplicateHit = config.optBoolean("filterDuplicates", true)
                    && isDuplicateMessage(chatId, senderId, text);
            if ((wordHit || linkHit || floodHit || duplicateHit) && !messageId.isEmpty()) {
                JSONObject delete = new JSONObject(); delete.put("chat_id", chatId); delete.put("message_id", messageId);
                api(bot.optString("token"), "deleteMessage", delete);
                bot.put("totalActions", bot.optInt("totalActions", 0) + 1);
                if (config.optBoolean("sendModerationNotice", false)) {
                    sendMessage(bot, chatId, wordHit ? "⚠️ پیام به‌دلیل واژه ممنوع حذف شد." : linkHit ? "⚠️ پیام دارای لینک حذف شد." : floodHit ? "⚠️ پیام‌های پیاپی حذف شدند." : "⚠️ پیام تکراری حذف شد.", null);
                }
                BotCredentialVault.put(this, bot.optString("id"), bot);
                return;
            }
            if ("/rules".equalsIgnoreCase(text)) {
                sendMessage(bot, chatId, config.optString("rulesText", "قوانین گروه: احترام، پرهیز از اسپم و رعایت موضوع گروه 🌿"), messageId);
            }
            return;
        }

        if ("auto_reply".equals(template)) {
            if ("📞 پشتیبانی".equals(text)) {
                sendMessage(bot, chatId, config.optString("supportContact", "برای ارتباط با پشتیبانی، پیام خود را همین‌جا ارسال کن."), messageId); return;
            }
            if ("❓ راهنمای خدمات".equals(text) || "📚 راهنمای پاسخ‌ها".equals(text)) {
                sendMessage(bot, chatId, helpText + "\n\nبرای پاسخ فوری، موضوعت را بنویس.", messageId); return;
            }
            if (config.optBoolean("autoReplyPaused", false)) return;
            String rules = config.optString("replyRules", "سلام=سلام! خوش اومدی 🌸\nقیمت=برای اطلاع از قیمت، نام محصول رو بفرست.");
            String normalizedText = text.toLowerCase();
            for (String line : rules.split("\\r?\\n")) {
                int split = line.indexOf('=');
                if (split <= 0) continue;
                String keyword = line.substring(0, split).trim();
                String reply = line.substring(split + 1).trim();
                if (!keyword.isEmpty() && !reply.isEmpty() && normalizedText.contains(keyword.toLowerCase())) {
                    sendMessage(bot, chatId, reply, messageId);
                    return;
                }
            }
            String fallback = config.optString("fallbackReply", "");
            if (!fallback.isEmpty()) sendMessage(bot, chatId, fallback, messageId);
            return;
        }

        if ("shop".equals(template)) {
            if ("/products".equalsIgnoreCase(text) || "محصولات".equals(text) || "🛍 محصولات".equals(text)) {
                sendMessage(bot, chatId, config.optString("shopProducts", "برای دریافت فهرست محصولات با پشتیبانی تماس بگیر."), messageId);
                return;
            }
            if ("🧾 راهنمای سفارش".equals(text)) {
                sendMessage(bot, chatId, "برای سفارش بنویس: /order نام کالا - تعداد\nمثال: /order کتاب - 2", messageId); return;
            }
            if ("📦 پیگیری سفارش".equals(text) || "/myorders".equalsIgnoreCase(text)) {
                JSONArray history = config.optJSONArray("orderHistory"); StringBuilder out = new StringBuilder("📦 سفارش‌های اخیر شما\n"); int found = 0;
                if (history != null) for (int i = history.length() - 1; i >= 0 && found < 5; i--) { JSONObject item = history.optJSONObject(i); if (item != null && senderId.equals(item.optString("senderId"))) { out.append("#").append(item.optString("code", "-")).append(" — ").append(item.optString("status", "جدید")).append("\n").append(item.optString("details", "")).append("\n"); found++; } }
                if (found == 0) out.append("سفارشی برای این حساب ثبت نشده است."); sendMessage(bot, chatId, out.toString(), messageId); return;
            }
            if (text.startsWith("/order") || text.startsWith("سفارش ")) {
                if (!config.optBoolean("shopOpen", true)) {
                    sendMessage(bot, chatId, "⛔ فروشگاه موقتاً سفارش جدید نمی‌پذیرد. لطفاً بعداً مراجعه کن.", messageId);
                    return;
                }
                String order = text.replaceFirst("^/order\\s*", "").replaceFirst("^سفارش\\s*", "").trim();
                if (order.isEmpty()) {
                    sendMessage(bot, chatId, "برای ثبت سفارش بنویس:\n/order نام کالا - تعداد", messageId);
                    return;
                }
                String orderCode = String.format(java.util.Locale.ROOT, "%06d", System.currentTimeMillis() % 1_000_000L);
                sendMessage(bot, chatId, "✅ درخواست سفارش شما ثبت شد.\nکد پیگیری: #" + orderCode + "\nجزئیات: " + order + "\nمدیر فروشگاه از سفارش مطلع شد.", messageId);
                JSONArray history = config.optJSONArray("orderHistory");
                if (history == null) history = new JSONArray();
                JSONObject orderRecord = new JSONObject();
                orderRecord.put("senderId", senderId); orderRecord.put("chatId", chatId);
                orderRecord.put("details", order); orderRecord.put("code", orderCode); orderRecord.put("status", "جدید"); orderRecord.put("createdAt", System.currentTimeMillis());
                history.put(orderRecord);
                JSONArray trimmed = new JSONArray();
                for (int i = Math.max(0, history.length() - 50); i < history.length(); i++) trimmed.put(history.get(i));
                config.put("orderHistory", trimmed); bot.put("config", config);
                BotCredentialVault.put(this, bot.optString("id"), bot);
                String adminChat = config.optString("ownerChatId", config.optString("adminChatId", "")).trim();
                if (!adminChat.isEmpty()) {
                    sendMessage(bot, adminChat, "🛍 سفارش جدید\nاز: " + senderId + "\nچت مشتری: " + chatId + "\nجزئیات: " + order, null);
                }
                return;
            }
            String rules = config.optString("replyRules", "ارسال=زمان ارسال بعد از تأیید سفارش اعلام می‌شود.\nپشتیبانی=پیام شما ثبت شد.");
            String normalizedText = text.toLowerCase();
            for (String line : rules.split("\\r?\\n")) {
                int split = line.indexOf('=');
                if (split <= 0) continue;
                String keyword = line.substring(0, split).trim();
                String reply = line.substring(split + 1).trim();
                if (!keyword.isEmpty() && !reply.isEmpty() && normalizedText.contains(keyword.toLowerCase())) {
                    sendMessage(bot, chatId, reply, messageId);
                    return;
                }
            }
            return;
        }

        if ("quiz".equals(template)) {
            if ("🥇 جدول برترین‌ها".equals(text)) {
                sendMessage(bot, chatId, getLeaderboard(bot.optString("id"), chatId), messageId); return;
            }
            if ("🏆 امتیاز من".equals(text)) {
                sendMessage(bot, chatId, "🏆 امتیاز تو: " + getScore(bot.optString("id"), chatId, senderId), messageId); return;
            }
            if ("🎯 شروع مسابقه".equals(text) || "/quiz".equalsIgnoreCase(text)) {
                sendMessage(bot, chatId, "🧠 چالش مسابقه\n" + config.optString("quizQuestion", "پایتخت ایران کدام شهر است؟") + "\n\nجوابت رو بفرست!", messageId);
                return;
            }
            if ("/score".equalsIgnoreCase(text)) {
                int score = getScore(bot.optString("id"), chatId, senderId);
                sendMessage(bot, chatId, "🏆 امتیاز تو: " + score + "\nبرای دیدن سؤال جدید /quiz رو بفرست.", messageId);
                return;
            }
            if ("/leaderboard".equalsIgnoreCase(text)) {
                sendMessage(bot, chatId, getLeaderboard(bot.optString("id"), chatId), messageId);
                return;
            }
            String answer = config.optString("quizAnswer", "تهران").trim();
            if (!answer.isEmpty() && normalize(text).equals(normalize(answer))) {
                int score = addScore(bot.optString("id"), chatId, senderId);
                sendMessage(bot, chatId, "🎉 آفرین! پاسخ درست بود.\nامتیاز تو: " + score, messageId);
            }
        }
    }


    private String tokenOf(JSONObject bot) { return bot.optString("token", ""); }

    private void handleOwnerClaim(JSONObject bot, JSONObject config, String token, String chatId,
                                  String senderId, String suppliedCode, String messageId) throws Exception {
        String owner = config.optString("ownerUserId", "");
        if (!owner.isEmpty()) {
            sendMessage(bot, chatId, owner.equals(senderId)
                    ? "مالک قبلاً متصل شده است. برای مدیریت /panel را بفرست."
                    : "⛔ این ربات قبلاً مالک دارد و کد جدید پذیرفته نمی‌شود.", messageId);
            return;
        }
        // Verify a private user chat before checking/incrementing the one-time code.
        JSONObject chatRequest = new JSONObject(); chatRequest.put("chat_id", chatId);
        JSONObject chatResult = unwrap(api(token, "getChat", chatRequest));
        JSONObject chat = chatResult.optJSONObject("chat");
        if (chat == null) chat = chatResult;
        String chatType = chat.optString("chat_type", "");
        String verifiedUserId = chat.optString("user_id", senderId);
        if (!"User".equalsIgnoreCase(chatType) || senderId == null || senderId.isEmpty()
                || (!verifiedUserId.isEmpty() && !verifiedUserId.equals(senderId))) {
            sendMessage(bot, chatId, "برای امنیت، اتصال مالک فقط از گفت‌وگوی خصوصی کاربر با ربات امکان‌پذیر است.", messageId);
            return;
        }
        String savedCode = config.optString("claimCode", "");
        long expiry = config.optLong("claimExpiresAt", 0L);
        if (savedCode.isEmpty() || !savedCode.equals(suppliedCode) || System.currentTimeMillis() > expiry) {
            int attempts = config.optInt("claimFailedAttempts", 0) + 1;
            config.put("claimFailedAttempts", attempts);
            if (attempts >= 5) { config.put("claimCode", ""); config.put("claimExpiresAt", 0L); }
            bot.put("config", config); BotCredentialVault.put(this, bot.optString("id"), bot);
            sendMessage(bot, chatId, attempts >= 5
                    ? "⛔ کد به‌دلیل چند تلاش ناموفق باطل شد. از داخل AppMint کد تازه بساز."
                    : "❌ کد اتصال نامعتبر یا منقضی شده است. کد را دوباره بررسی کن.", messageId);
            return;
        }
        config.put("ownerUserId", senderId);
        config.put("ownerChatId", chatId);
        config.put("claimCode", "");
        config.put("claimExpiresAt", 0L);
        config.put("claimFailedAttempts", 0);
        bot.put("config", config);
        BotCredentialVault.put(this, bot.optString("id"), bot);
        sendOwnerPanel(bot, chatId, "✅ مالکیت تأیید شد. از منوی زیر رباتت را مدیریت کن.");
    }

    private void sendUserStartMenu(JSONObject bot, String chatId, String greeting) throws Exception {
        String template = bot.optString("templateId", "");
        String[][] rows;
        if ("guardian".equals(template)) rows = new String[][]{{"📜 قوانین گروه"}, {"/help"}};
        else if ("auto_reply".equals(template)) rows = new String[][]{{"❓ راهنمای خدمات"}, {"📞 پشتیبانی"}};
        else if ("shop".equals(template)) rows = new String[][]{{"🛍 محصولات"}, {"🧾 راهنمای سفارش"}, {"📦 پیگیری سفارش"}};
        else if ("support".equals(template)) rows = new String[][]{{"🎫 ثبت درخواست"}, {"📋 پیگیری درخواست"}};
        else rows = new String[][]{{"🎯 شروع مسابقه", "🏆 امتیاز من"}, {"🥇 جدول برترین‌ها"}};
        sendMessageWithKeypad(bot, chatId, greeting, rows, null);
    }

    private void sendOwnerPanel(JSONObject bot, String chatId, String intro) throws Exception {
        String template = bot.optString("templateId", "");
        String[][] rows;
        if ("guardian".equals(template)) rows = new String[][]{{"📊 وضعیت نگهبان"}, {"🔗 تغییر فیلتر لینک", "🚫 تغییر فیلتر واژه"}, {"🌊 تغییر ضدسیل", "📜 قوانین گروه"}, {"📚 راهنمای نگهبان"}, {"⚙ پنل مدیریت"}};
        else if ("auto_reply".equals(template)) rows = new String[][]{{"📊 وضعیت پاسخگو"}, {"⏸ توقف پاسخگویی", "▶ ادامه پاسخگویی"}, {"📚 راهنمای پاسخ‌ها", "📞 راه تماس"}, {"⚙ پنل مدیریت"}};
        else if ("shop".equals(template)) rows = new String[][]{{"📊 وضعیت فروشگاه"}, {"🛍 باز/بسته کردن فروشگاه"}, {"📦 محصولات", "🧾 آخرین سفارش"}, {"✅ تأیید آخرین سفارش", "❌ رد آخرین سفارش"}, {"✏️ راهنمای ویرایش کالاها"}, {"⚙ پنل مدیریت"}};
        else if ("support".equals(template)) rows = new String[][]{{"📊 وضعیت تیکت‌ها"}, {"📥 درخواست‌های جدید"}, {"✅ بستن آخرین تیکت"}, {"📚 راهنمای پاسخ"}, {"⚙ پنل مدیریت"}};
        else rows = new String[][]{{"🎯 سؤال فعلی", "📊 آمار مسابقه"}, {"🧹 صفرکردن امتیازها"}, {"📚 راهنمای تغییر سؤال"}, {"⚙ پنل مدیریت"}};
        sendMessageWithKeypad(bot, chatId, intro + "\n\n👑 پنل فقط برای مالک متصل فعال است.", rows, null);
    }

    private void sendMessageWithKeypad(JSONObject bot, String chatId, String text, String[][] labels, String replyTo) throws Exception {
        JSONArray rows = new JSONArray();
        for (int i = 0; i < labels.length; i++) {
            JSONObject row = new JSONObject(); JSONArray buttons = new JSONArray();
            for (int j = 0; j < labels[i].length; j++) {
                JSONObject button = new JSONObject();
                button.put("id", "am_" + i + "_" + j);
                button.put("type", "Simple");
                button.put("button_text", labels[i][j]);
                buttons.put(button);
            }
            row.put("buttons", buttons); rows.put(row);
        }
        JSONObject keypad = new JSONObject(); keypad.put("rows", rows);
        keypad.put("resize_keyboard", true); keypad.put("one_time_keyboard", false);
        JSONObject payload = new JSONObject(); payload.put("chat_id", chatId); payload.put("text", text);
        payload.put("chat_keypad_type", "New"); payload.put("chat_keypad", keypad);
        if (replyTo != null && !replyTo.isEmpty()) payload.put("reply_to_message_id", replyTo);
        api(bot.optString("token"), "sendMessage", payload);
        bot.put("totalActions", bot.optInt("totalActions", 0) + 1);
    }

    private boolean handleOwnerCommand(JSONObject bot, JSONObject config, String chatId, String senderId,
                                        String text, String messageId) throws Exception {
        String template = bot.optString("templateId", "");
        String normalized = text.trim();
        if ("/panel".equalsIgnoreCase(normalized) || "⚙ پنل مدیریت".equals(normalized)) {
            sendOwnerPanel(bot, chatId, "پنل کنترل AppMint"); return true;
        }
        if ("guardian".equals(template)) {
            if ("🔗 تغییر فیلتر لینک".equals(normalized)) { config.put("filterLinks", !config.optBoolean("filterLinks", true)); }
            else if ("🚫 تغییر فیلتر واژه".equals(normalized)) { config.put("filterWords", !config.optBoolean("filterWords", true)); }
            else if ("🌊 تغییر ضدسیل".equals(normalized)) { config.put("filterFlood", !config.optBoolean("filterFlood", true)); }
            else if ("📊 وضعیت نگهبان".equals(normalized)) {
                sendMessage(bot, chatId, "🛡 وضعیت نگهبان\nفیلتر لینک: " + onOff(config.optBoolean("filterLinks", true))
                        + "\nفیلتر واژه: " + onOff(config.optBoolean("filterWords", true))
                        + "\nضدسیل: " + onOff(config.optBoolean("filterFlood", true)), messageId); return true;
            } else if ("📜 قوانین گروه".equals(normalized)) {
                sendMessage(bot, chatId, config.optString("rulesText", "قوانین ثبت نشده است."), messageId); return true;
            } else if (normalized.startsWith("/addword ")) {
                String word = normalized.substring(9).trim();
                if (word.isEmpty()) { sendMessage(bot, chatId, "فرمت: /addword کلمه", messageId); return true; }
                String current = config.optString("blockedWords", "");
                if (!current.toLowerCase().contains(word.toLowerCase())) config.put("blockedWords", current.isEmpty() ? word : current + "\n" + word);
            } else if (normalized.startsWith("/delword ")) {
                String word = normalized.substring(9).trim(); StringBuilder kept = new StringBuilder();
                for (String item : config.optString("blockedWords", "").split("\\r?\\n")) {
                    if (!item.trim().equalsIgnoreCase(word) && !item.trim().isEmpty()) { if (kept.length() > 0) kept.append('\n'); kept.append(item.trim()); }
                }
                config.put("blockedWords", kept.toString());
            } else if (normalized.startsWith("/setrules ")) {
                config.put("rulesText", normalized.substring(10).trim());
            } else if ("📚 راهنمای نگهبان".equals(normalized)) {
                sendMessage(bot, chatId, "افزودن واژه ممنوع: /addword کلمه\nحذف واژه: /delword کلمه\nتغییر قوانین: /setrules متن قوانین", messageId); return true;
            } else return false;
            saveBotConfig(bot, config); sendOwnerPanel(bot, chatId, "✅ تنظیمات نگهبان به‌روزرسانی شد."); return true;
        }
        if ("auto_reply".equals(template)) {
            if ("⏸ توقف پاسخگویی".equals(normalized)) config.put("autoReplyPaused", true);
            else if ("▶ ادامه پاسخگویی".equals(normalized)) config.put("autoReplyPaused", false);
            else if ("📊 وضعیت پاسخگو".equals(normalized)) {
                sendMessage(bot, chatId, "💬 وضعیت پاسخگو: " + (config.optBoolean("autoReplyPaused", false) ? "متوقف" : "فعال")
                        + "\nقوانین پاسخ: " + config.optString("replyRules", "").split("\\r?\\n").length, messageId); return true;
            } else if (normalized.startsWith("/setwelcome ")) config.put("welcomeMessage", normalized.substring(12).trim());
            else if (normalized.startsWith("/setfaq ")) {
                String entry = normalized.substring(8).trim();
                if (!entry.contains("=")) { sendMessage(bot, chatId, "فرمت صحیح: /setfaq کلیدواژه=پاسخ", messageId); return true; }
                String current = config.optString("replyRules", ""); config.put("replyRules", current.isEmpty() ? entry : current + "\n" + entry);
            } else if (normalized.startsWith("/removefaq ")) {
                String keyword = normalized.substring(11).trim(); StringBuilder kept = new StringBuilder();
                for (String line : config.optString("replyRules", "").split("\\r?\\n")) {
                    int eq = line.indexOf('=');
                    if (eq > 0 && line.substring(0, eq).trim().equalsIgnoreCase(keyword)) continue;
                    if (!line.trim().isEmpty()) { if (kept.length() > 0) kept.append('\n'); kept.append(line); }
                }
                config.put("replyRules", kept.toString());
            } else if (normalized.startsWith("/setfallback ")) config.put("fallbackReply", normalized.substring(13).trim());
            else if (normalized.startsWith("/setsupport ")) config.put("supportContact", normalized.substring(12).trim());
            else if ("📞 راه تماس".equals(normalized)) { sendMessage(bot, chatId, "راه تماس فعلی: " + config.optString("supportContact", "تعریف نشده") + "\nبرای تغییر: /setsupport متن راه ارتباطی", messageId); return true; }
            else if ("📚 راهنمای پاسخ‌ها".equals(normalized)) {
                sendMessage(bot, chatId, "افزودن پاسخ: /setfaq کلیدواژه=متن پاسخ\nحذف پاسخ: /removefaq کلیدواژه\nتغییر خوشامد: /setwelcome متن\nتغییر پاسخ پیش‌فرض: /setfallback متن\nتغییر راه پشتیبانی: /setsupport متن", messageId); return true;
            } else return false;
            saveBotConfig(bot, config); sendMessage(bot, chatId, "✅ تنظیمات پاسخگو ذخیره شد.", messageId); return true;
        }
        if ("shop".equals(template)) {
            if ("🛍 باز/بسته کردن فروشگاه".equals(normalized)) config.put("shopOpen", !config.optBoolean("shopOpen", true));
            else if ("📊 وضعیت فروشگاه".equals(normalized)) {
                JSONArray orders = config.optJSONArray("orderHistory");
                sendMessage(bot, chatId, "🛍 وضعیت فروشگاه: " + (config.optBoolean("shopOpen", true) ? "باز" : "بسته")
                        + "\nتعداد سفارش‌های ذخیره‌شده: " + (orders == null ? 0 : orders.length())
                        + "\nمحصولات: " + config.optString("shopProducts", "تعریف نشده"), messageId); return true;
            } else if ("📦 محصولات".equals(normalized)) {
                sendMessage(bot, chatId, config.optString("shopProducts", "محصولی ثبت نشده است."), messageId); return true;
            } else if ("🧾 آخرین سفارش".equals(normalized)) {
                JSONArray orders = config.optJSONArray("orderHistory"); StringBuilder out = new StringBuilder("🧾 آخرین سفارش‌ها\n");
                if (orders == null || orders.length() == 0) out.append("هنوز سفارشی ثبت نشده است.");
                else for (int i = orders.length() - 1, shown = 0; i >= 0 && shown < 5; i--, shown++) {
                    JSONObject order = orders.optJSONObject(i); if (order != null) out.append("• #").append(order.optString("code", "-")).append(" ").append(order.optString("details", "-")).append(" | ").append(order.optString("status", "جدید")).append("\n");
                }
                sendMessage(bot, chatId, out.toString(), messageId); return true;
            } else if ("✏️ راهنمای ویرایش کالاها".equals(normalized)) {
                sendMessage(bot, chatId, "برای جایگزینی فهرست کالاها بنویس:\n/setproducts نام کالا — قیمت\nنام کالای دوم — قیمت\n\nهر محصول را در یک خط وارد کن.", messageId); return true;
            } else if ("✅ تأیید آخرین سفارش".equals(normalized) || "❌ رد آخرین سفارش".equals(normalized)) {
                JSONArray orders = config.optJSONArray("orderHistory"); JSONObject latest = null;
                if (orders != null) for (int i = orders.length() - 1; i >= 0; i--) { JSONObject item = orders.optJSONObject(i); if (item != null && "جدید".equals(item.optString("status", "جدید"))) { latest = item; break; } }
                if (latest == null) { sendMessage(bot, chatId, "سفارش جدیدی برای بررسی وجود ندارد.", messageId); return true; }
                boolean approved = "✅ تأیید آخرین سفارش".equals(normalized); latest.put("status", approved ? "تأییدشده" : "ردشده");
                String customerChat = latest.optString("chatId", ""); if (!customerChat.isEmpty()) sendMessage(bot, customerChat, approved ? "✅ سفارش شما تأیید شد. فروشگاه به‌زودی برای هماهنگی با شما تماس می‌گیرد." : "❌ متأسفانه سفارش شما پذیرفته نشد. برای راهنمایی بیشتر با پشتیبانی تماس بگیرید.", null);
            } else if (normalized.startsWith("/setproducts ")) config.put("shopProducts", normalized.substring(13).trim());
            else return false;
            saveBotConfig(bot, config); sendOwnerPanel(bot, chatId, "✅ وضعیت فروشگاه به‌روزرسانی شد."); return true;
        }
        if ("support".equals(template)) {
            JSONArray tickets = config.optJSONArray("supportTickets");
            if ("📊 وضعیت تیکت‌ها".equals(normalized)) {
                int open = 0; if (tickets != null) for (int i = 0; i < tickets.length(); i++) { JSONObject t = tickets.optJSONObject(i); if (t != null && !"بسته".equals(t.optString("status"))) open++; }
                sendMessage(bot, chatId, "🎫 تیکت‌های باز: " + open + "\nکل تیکت‌های ذخیره‌شده: " + (tickets == null ? 0 : tickets.length()), messageId); return true;
            }
            if ("📥 درخواست‌های جدید".equals(normalized)) {
                StringBuilder out = new StringBuilder("📥 درخواست‌های باز\n"); int shown = 0;
                if (tickets != null) for (int i = tickets.length() - 1; i >= 0 && shown < 8; i--) { JSONObject t = tickets.optJSONObject(i); if (t != null && !"بسته".equals(t.optString("status"))) { out.append("#").append(t.optString("code")).append(" | ").append(t.optString("senderId")).append("\n").append(t.optString("text")).append("\n\n"); shown++; } }
                if (shown == 0) out.append("درخواست بازی وجود ندارد.");
                sendMessage(bot, chatId, out.toString(), messageId); return true;
            }
            if ("✅ بستن آخرین تیکت".equals(normalized)) {
                JSONObject latest = null; if (tickets != null) for (int i = tickets.length() - 1; i >= 0; i--) { JSONObject t = tickets.optJSONObject(i); if (t != null && !"بسته".equals(t.optString("status"))) { latest = t; break; } }
                if (latest == null) { sendMessage(bot, chatId, "تیکت بازی وجود ندارد.", messageId); return true; }
                latest.put("status", "بسته"); String customerChat = latest.optString("chatId", ""); if (!customerChat.isEmpty()) sendMessage(bot, customerChat, "✅ درخواست با کد پیگیری #" + latest.optString("code") + " بسته شد.", null);
                saveBotConfig(bot, config); sendOwnerPanel(bot, chatId, "تیکت بسته شد."); return true;
            }
            if (normalized.startsWith("/reply ")) {
                String value = normalized.substring(7).trim(); int sep = value.indexOf('|');
                if (sep <= 0 || sep == value.length() - 1) { sendMessage(bot, chatId, "فرمت: /reply کدپیگیری|متن پاسخ", messageId); return true; }
                String code = value.substring(0, sep).trim(), reply = value.substring(sep + 1).trim(); JSONObject target = null;
                if (tickets != null) for (int i = 0; i < tickets.length(); i++) { JSONObject t = tickets.optJSONObject(i); if (t != null && code.equals(t.optString("code"))) { target = t; break; } }
                if (target == null) { sendMessage(bot, chatId, "تیکتی با این کد پیدا نشد.", messageId); return true; }
                sendMessage(bot, target.optString("chatId", ""), "💬 پاسخ پشتیبانی به تیکت #" + code + "\n" + reply, null);
                JSONArray conversation = target.optJSONArray("conversation"); if (conversation == null) conversation = new JSONArray();
                JSONObject answer = new JSONObject(); answer.put("by", "owner"); answer.put("text", reply); answer.put("createdAt", System.currentTimeMillis()); conversation.put(answer);
                JSONArray trimmed = new JSONArray(); for (int i = Math.max(0, conversation.length() - 30); i < conversation.length(); i++) trimmed.put(conversation.get(i));
                target.put("conversation", trimmed); target.put("status", "باز"); target.put("lastReply", reply); saveBotConfig(bot, config); sendMessage(bot, chatId, "✅ پاسخ برای کاربر ارسال شد.", messageId); return true;
            }
            if ("📚 راهنمای پاسخ".equals(normalized)) { sendMessage(bot, chatId, "برای پاسخ به تیکت: /reply کدپیگیری|متن پاسخ\nاز دکمه درخواست‌های جدید برای مشاهده تیکت‌ها استفاده کن.\nبرای بستن یک تیکت، کد آن را با /close کدپیگیری ببند.", messageId); return true; }
            if (normalized.startsWith("/close ")) {
                String code = normalized.substring(7).trim(); JSONObject target = null;
                if (tickets != null) for (int i = 0; i < tickets.length(); i++) { JSONObject item = tickets.optJSONObject(i); if (item != null && code.equals(item.optString("code"))) { target = item; break; } }
                if (target == null) { sendMessage(bot, chatId, "تیکتی با این کد پیدا نشد.", messageId); return true; }
                target.put("status", "بسته"); String customerChat = target.optString("chatId", "");
                if (!customerChat.isEmpty()) sendMessage(bot, customerChat, "✅ تیکت شما با کد #" + code + " بسته شد.", null);
                saveBotConfig(bot, config); sendMessage(bot, chatId, "✅ تیکت #" + code + " بسته شد.", messageId); return true;
            }
            return false;
        }
        if ("quiz".equals(template)) {
            if ("🎯 سؤال فعلی".equals(normalized)) { sendMessage(bot, chatId, "🎯 " + config.optString("quizQuestion", "سؤالی ثبت نشده است"), messageId); return true; }
            if ("📊 آمار مسابقه".equals(normalized)) {
                int users = 0; for (String key : getSharedPreferences("appmint_quiz_scores", MODE_PRIVATE).getAll().keySet()) if (key.startsWith(bot.optString("id") + "|")) users++;
                sendMessage(bot, chatId, "📊 تعداد رکوردهای امتیاز این ربات: " + users + "\nبرای تغییر سؤال: /setquestion سؤال|پاسخ", messageId); return true;
            }
            if ("🧹 صفرکردن امتیازها".equals(normalized)) {
                android.content.SharedPreferences prefs = getSharedPreferences("appmint_quiz_scores", MODE_PRIVATE);
                android.content.SharedPreferences.Editor editor = prefs.edit();
                for (String key : prefs.getAll().keySet()) if (key.startsWith(bot.optString("id") + "|")) editor.remove(key);
                editor.apply(); sendMessage(bot, chatId, "امتیازهای این ربات پاک شد.", messageId); return true;
            }
            if ("📚 راهنمای تغییر سؤال".equals(normalized)) { sendMessage(bot, chatId, "فرمت تغییر سؤال: /setquestion متن سؤال|پاسخ صحیح", messageId); return true; }
            if (normalized.startsWith("/setquestion ")) {
                String[] parts = normalized.substring(13).split("\\|", 2);
                if (parts.length < 2 || parts[0].trim().isEmpty() || parts[1].trim().isEmpty()) sendMessage(bot, chatId, "فرمت صحیح: /setquestion متن سؤال|پاسخ صحیح", messageId);
                else { config.put("quizQuestion", parts[0].trim()); config.put("quizAnswer", parts[1].trim()); saveBotConfig(bot, config); sendMessage(bot, chatId, "✅ سؤال و پاسخ جدید ذخیره شد.", messageId); }
                return true;
            }
        }
        return false;
    }

    private void saveBotConfig(JSONObject bot, JSONObject config) throws Exception {
        bot.put("config", config);
        BotCredentialVault.put(this, bot.optString("id"), bot);
    }

    private String onOff(boolean enabled) { return enabled ? "روشن ✅" : "خاموش ⛔"; }

    private final Map<String, Long> lastMessageFingerprints = new ConcurrentHashMap<>();
    private boolean isDuplicateMessage(String chatId, String userId, String text) {
        String key = chatId + "|" + userId + "|" + text.trim().toLowerCase();
        long now = System.currentTimeMillis(); Long previous = lastMessageFingerprints.put(key, now);
        if (lastMessageFingerprints.size() > 5000) lastMessageFingerprints.clear();
        return previous != null && now - previous < 8000L;
    }

    private boolean isFlooding(String chatId, String userId, int configuredLimit) {
        int limit = Math.max(3, Math.min(configuredLimit, 30));
        long now = System.currentTimeMillis();
        String key = chatId + "|" + userId;
        ArrayDeque<Long> window = floodWindows.get(key);
        if (window == null) {
            ArrayDeque<Long> created = new ArrayDeque<>();
            ArrayDeque<Long> existing = floodWindows.putIfAbsent(key, created);
            window = existing == null ? created : existing;
        }
        synchronized (window) {
            while (!window.isEmpty() && now - window.peekFirst() > 10_000L) window.removeFirst();
            window.addLast(now);
            if (floodWindows.size() > 5000) floodWindows.clear();
            return window.size() > limit;
        }
    }

    private String getLeaderboard(String botId, String chatId) {
        String prefix = botId + "|" + chatId + "|";
        ArrayList<Map.Entry<String, ?>> scores = new ArrayList<>();
        for (Map.Entry<String, ?> entry : getSharedPreferences("appmint_quiz_scores", MODE_PRIVATE).getAll().entrySet()) {
            if (entry.getKey().startsWith(prefix) && entry.getValue() instanceof Integer) scores.add(entry);
        }
        scores.sort((left, right) -> Integer.compare((Integer) right.getValue(), (Integer) left.getValue()));
        if (scores.isEmpty()) return "🏆 هنوز امتیازی ثبت نشده است.\nبرای شروع /quiz را بفرست.";
        StringBuilder text = new StringBuilder("🏆 جدول امتیاز مسابقه\n\n");
        int count = Math.min(10, scores.size());
        for (int i = 0; i < count; i++) {
            Map.Entry<String, ?> entry = scores.get(i);
            String userId = entry.getKey().substring(prefix.length());
            text.append(i + 1).append(". ").append(userId).append(" — ").append(entry.getValue()).append(" امتیاز\n");
        }
        return text.toString();
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().replace('ي', 'ی').replace('ك', 'ک').replaceAll("\\s+", " ").toLowerCase();
    }

    private int getScore(String botId, String chatId, String userId) {
        return getSharedPreferences("appmint_quiz_scores", MODE_PRIVATE).getInt(botId + "|" + chatId + "|" + userId, 0);
    }

    private int addScore(String botId, String chatId, String userId) {
        String key = botId + "|" + chatId + "|" + userId;
        int next = getScore(botId, chatId, userId) + 1;
        getSharedPreferences("appmint_quiz_scores", MODE_PRIVATE).edit().putInt(key, next).apply();
        return next;
    }

    private void sendMessage(JSONObject bot, String chatId, String text, String replyTo) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("chat_id", chatId);
        payload.put("text", text);
        if (replyTo != null && !replyTo.isEmpty()) payload.put("reply_to_message_id", replyTo);
        api(bot.optString("token"), "sendMessage", payload);
        bot.put("totalActions", bot.optInt("totalActions", 0) + 1);
    }

    private JSONObject api(String token, String method, JSONObject payload) throws Exception {
        String encodedToken = URLEncoder.encode(token, "UTF-8").replace("+", "%20");
        HttpURLConnection connection = (HttpURLConnection) new URL(API_BASE + encodedToken + "/" + method).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(15000);
        connection.setUseCaches(false);
        connection.setDoOutput(true);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        connection.setFixedLengthStreamingMode(body.length);
        try {
            try (OutputStream output = connection.getOutputStream()) { output.write(body); output.flush(); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
            String raw = stream == null ? "{}" : readLimited(stream);
            JSONObject parsed = new JSONObject(raw);
            if (code < 200 || code >= 300) {
                String error = parsed.optString("description", parsed.optString("message", "خطای API روبیکا: HTTP " + code));
                throw new java.io.IOException(error);
            }
            String status = parsed.optString("status", "OK");
            if (!"OK".equalsIgnoreCase(status) && !"SUCCESS".equalsIgnoreCase(status)) {
                throw new java.io.IOException(parsed.optString("description", parsed.optString("message", status)));
            }
            return parsed;
        } finally { connection.disconnect(); }
    }

    private JSONObject unwrap(JSONObject raw) {
        JSONObject data = raw.optJSONObject("data");
        if (data != null) return data;
        JSONObject result = raw.optJSONObject("result");
        return result == null ? raw : result;
    }

    private String readLimited(InputStream input) throws Exception {
        try (InputStream stream = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int total = 0; int count;
            while ((count = stream.read(buffer)) != -1) {
                total += count;
                if (total > MAX_RESPONSE_BYTES) throw new java.io.IOException("پاسخ روبیکا بیش از حد بزرگ است.");
                output.write(buffer, 0, count);
            }
            return output.toString("UTF-8");
        }
    }

    private void stopIfEmpty(int startId) {
        if (bots.isEmpty()) stopSelf(startId);
        else updateNotification();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "اجرای ربات‌های AppMint", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("اعلان دائمی برای ربات‌هایی که خودت فعال کرده‌ای");
            channel.setShowBadge(false);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                .setContentTitle("AppMint · ربات‌ها فعال‌اند")
                .setContentText(text)
                .setContentIntent(pending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void updateNotification() {
        if (bots.isEmpty()) return;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID,
                buildNotification(bots.size() + " ربات در پس‌زمینه فعال‌اند · بررسی هر " + pollIntervalSeconds + " ثانیه"));
    }

    @Override
    public void onDestroy() {
        running = false;
        if (pollingFuture != null) pollingFuture.cancel(true);
        if (executor != null) executor.shutdownNow();
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (RuntimeException ignored) { }
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
