plugins {
    id("com.android.application")
}

android {
    namespace = "ir.appmint.rubikabotbuilder"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.appmint.rubikabotbuilder"
        minSdk = 23
        targetSdk = 34
        versionCode = 2
        versionName = "1.1.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
