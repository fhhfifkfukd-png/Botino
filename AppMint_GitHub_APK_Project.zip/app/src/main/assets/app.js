'use strict';

const API_BASE = 'https://botapi.rubika.ir/v3/';
const POLL_INTERVAL = 5000;
const DB_NAME = 'appmint-secure-vault';
const STORE_NAME = 'keys';
const APP_DATA_KEY = 'appmint_data_v1';

const TEMPLATES = [
  {id:'guardian',name:'نگهبان گروه',emoji:'🛡️',category:'moderation',tint:'#eeeaff',desc:'فیلتر کلمات و لینک‌ها، حذف پیام‌های مشخص و مدیریت امن گروه.',tag:'مدیریتی',features:['فیلتر کلمات ممنوع','کنترل لینک‌ها','ثبت اقدامات مدیریتی'],defaults:{filterWords:true,blockedWords:'اسپم\nتبلیغ ناخواسته',filterLinks:false,welcomeMessage:'به گروه خوش اومدی 🌱 قوانین رو حتماً بخون.',autoWelcome:false}},
  {id:'welcome',name:'خوشامدگوی شروع گفتگو',emoji:'👋',category:'communication',tint:'#fff0e7',desc:'ارسال پیام خوشامد هنگام شروع گفتگو با ربات و نمایش راهنمای دستورات.',tag:'ارتباطی',features:['خوشامد هنگام شروع بات','راهنمای دستورات','پیام شروع قابل ویرایش'],defaults:{welcomeMessage:'سلام! به جمع ما خوش اومدی 🌟\nبرای دیدن راهنما /help رو بفرست.',autoWelcome:false}},
  {id:'auto_reply',name:'پاسخگوی هوشمند',emoji:'💬',category:'communication',tint:'#e9f8f4',desc:'به کلمات کلیدی و پرسش‌های پرتکرار با پاسخ دلخواهت جواب بده.',tag:'ارتباطی',features:['پاسخ بر اساس کلمه','چند قانون هم‌زمان','اولویت‌بندی پاسخ‌ها'],defaults:{replyRules:'سلام=سلام! خوش اومدی 🌸\nقیمت=برای اطلاع از قیمت، نام محصول رو بفرست.\nساعت کاری=هر روز از ۹ تا ۱۸ پاسخگو هستیم.'}},
  {id:'shop',name:'دستیار فروشگاه',emoji:'🛍️',category:'business',tint:'#fff2e8',desc:'منوی پشتیبانی، پاسخ قیمت و راهنمای سفارش برای مشتری‌ها.',tag:'کسب‌وکار',features:['منوی خدمات','پاسخ به پرسش‌های فروش','پیام پشتیبانی'],defaults:{shopName:'فروشگاه من',welcomeMessage:'سلام به فروشگاه ما خوش اومدی 🛍️\nبرای راهنما /help رو بفرست.',replyRules:'سفارش=برای ثبت سفارش، نام کالا و تعداد رو بفرست.\nپشتیبانی=پیام شما ثبت شد؛ به‌زودی پاسخ می‌دیم.\nارسال=اطلاعات ارسال پس از ثبت سفارش اعلام می‌شه.'}},
  {id:'poll',name:'نظرسنجی‌ساز',emoji:'📊',category:'fun',tint:'#eaf1ff',desc:'با یک دستور، نظرسنجی آماده را در گفت‌وگو منتشر کن.',tag:'سرگرمی',features:['سؤال و گزینه‌های دلخواه','ارسال نظرسنجی با دستور /poll','مدیریت از پنل'],defaults:{pollQuestion:'کدوم گزینه رو بیشتر می‌پسندی؟',pollOptions:'گزینه اول\nگزینه دوم\nگزینه سوم'}},
  {id:'quiz',name:'مسابقه و کوئیز',emoji:'🧠',category:'fun',tint:'#f5edff',desc:'سؤال روز و چالش دانستنی‌ها را برای اعضا ارسال کن.',tag:'سرگرمی',features:['سؤال اختصاصی','ارسال با دستور /quiz','امکان تغییر سؤال'],defaults:{quizQuestion:'پایتخت ایران کدام شهر است؟',quizAnswer:'تهران'}},
  {id:'reminder',name:'یادآور گروهی',emoji:'⏰',category:'business',tint:'#fff5dc',desc:'با دستور ساده، پیام یادآوری زمان‌دار در همان چت ارسال کن.',tag:'کسب‌وکار',features:['یادآور دقیقه‌ای','ارسال خودکار در زمان تعیین‌شده','فقط هنگام باز بودن برنامه'],defaults:{maxReminderMinutes:'1440'}},
  {id:'announcer',name:'ناشر کانال',emoji:'📣',category:'business',tint:'#fcecf2',desc:'ارسال اطلاعیه و پیام‌های آماده از پنل یا دستور اختصاصی.',tag:'کسب‌وکار',features:['پیام آماده','ارسال دستی از پنل','دستور /announce'],defaults:{announcePrefix:'📣 اطلاعیه جدید'}},
  {id:'faq',name:'راهنمای پاسخ سریع',emoji:'✨',category:'communication',tint:'#f0efff',desc:'راهنمای مرحله‌ای با پاسخ به دستورهای پرکاربرد و منوی راهنما.',tag:'ارتباطی',features:['دستور /help','متن راهنمای قابل تنظیم','پاسخ‌های پایه'],defaults:{welcomeMessage:'سلام! من راهنمای شما هستم. برای دیدن امکانات /help رو بفرست.'}},
  {id:'moderator',name:'مدیر ابزارها',emoji:'⚖️',category:'moderation',tint:'#e9f3ff',desc:'ابزارهای مدیریتی دستی برای حذف پیام و مسدودسازی با شناسه.',tag:'مدیریتی',features:['حذف پیام مشخص','مسدودسازی دستی','رفع مسدودیت دستی'],defaults:{confirmAdminActions:true}}
];

const state = {page:'home',bots:[],logs:[],activeBotId:null,filter:'all',search:'',vaultReady:false,key:null,runtime:new Map(),memoryTokens:new Map(),reminders:new Map(),selectedTemplate:'guardian',vaultPromise:null};
const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
const digits = value => String(value).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
const nowTime = () => new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});
const todayFa = () => new Date().toLocaleDateString('fa-IR',{weekday:'long',day:'numeric',month:'long'});
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid = () => 'b_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);
const templateById = id => TEMPLATES.find(t=>t.id===id) || TEMPLATES[0];

function loadData(){
  try{const raw=JSON.parse(localStorage.getItem(APP_DATA_KEY)||'{}');state.bots=Array.isArray(raw.bots)?raw.bots:[];state.logs=Array.isArray(raw.logs)?raw.logs:[];}catch(e){state.bots=[];state.logs=[];}
}
function saveData(){
  const safeBots=state.bots.map(({token,...bot})=>bot);
  try{localStorage.setItem(APP_DATA_KEY,JSON.stringify({bots:safeBots,logs:state.logs.slice(0,300)}));}catch(e){toast('فضای ذخیره‌سازی دستگاه در دسترس نیست.','error');}
}
async function openVault(){
  if(!('indexedDB' in window)||!window.crypto?.subtle)return false;
  let db;
  try{
    db=await new Promise((resolve,reject)=>{
      const req=indexedDB.open(DB_NAME,1);
      req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(STORE_NAME))req.result.createObjectStore(STORE_NAME);};
      req.onsuccess=()=>resolve(req.result);
      req.onerror=()=>reject(req.error||new Error('باز کردن مخزن امن ناموفق بود.'));
      req.onblocked=()=>reject(new Error('مخزن امن توسط پنجره دیگری قفل شده است.'));
    });
    let storedKey=await new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE_NAME,'readonly');
      const req=tx.objectStore(STORE_NAME).get('aes-key');
      req.onsuccess=()=>resolve(req.result||null);
      req.onerror=()=>reject(req.error||new Error('خواندن کلید امن ناموفق بود.'));
      tx.onabort=()=>reject(tx.error||new Error('تراکنش خواندن کلید لغو شد.'));
    });
    if(storedKey){state.key=storedKey;state.vaultReady=true;return true;}
    // Generate the CryptoKey outside an IndexedDB transaction. Awaiting crypto inside
    // an active transaction can make the transaction inactive before store.put().
    const generatedKey=await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE_NAME,'readwrite');
      tx.objectStore(STORE_NAME).put(generatedKey,'aes-key');
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error||new Error('ذخیره کلید امن ناموفق بود.'));
      tx.onabort=()=>reject(tx.error||new Error('ذخیره کلید امن لغو شد.'));
    });
    state.key=generatedKey;state.vaultReady=true;return true;
  }catch(error){
    state.key=null;state.vaultReady=false;
    console.warn('AppMint secure vault unavailable:',error);
    return false;
  }finally{if(db)db.close();}
}
async function encryptToken(token){
  if(!state.vaultReady||!state.key)return {mode:'memory',value:null};
  try{
    const iv=crypto.getRandomValues(new Uint8Array(12));const encoded=new TextEncoder().encode(token);const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},state.key,encoded);
    return {mode:'aes-gcm',iv:Array.from(iv),value:Array.from(new Uint8Array(cipher))};
  }catch(error){state.vaultReady=false;state.key=null;console.warn('AppMint token encryption failed:',error);return {mode:'memory',value:null};}
}
async function decryptToken(bot){
  if(state.memoryTokens.has(bot.id))return state.memoryTokens.get(bot.id);
  if(bot.tokenVault?.mode==='memory')return null;
  if(!state.vaultReady||!state.key||!bot.tokenVault)return null;
  try{const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:new Uint8Array(bot.tokenVault.iv)},state.key,new Uint8Array(bot.tokenVault.value));return new TextDecoder().decode(plain);}catch(e){return null;}
}
function toast(message,type='info'){
  const el=document.createElement('div');el.className='toast '+type;el.textContent=message;$('#toastStack').appendChild(el);setTimeout(()=>el.remove(),3600);
}
function addLog(botId,type,title,message){
  const bot=state.bots.find(b=>b.id===botId);state.logs.unshift({id:uid(),botId,type,title,message,time:Date.now(),botName:bot?.name||'AppMint'});state.logs=state.logs.slice(0,300);saveData();renderActivity();renderHome();if(state.activeBotId===botId)renderBotDetail();
}
function showPage(page){
  state.page=page;$$('.page').forEach(p=>{const isActive=p.dataset.page===page;p.classList.toggle('active',isActive);p.classList.toggle('hidden',!isActive);});$$('.nav-item[data-nav]').forEach(b=>b.classList.toggle('active',b.dataset.nav===page));window.scrollTo({top:0,behavior:'smooth'});
  if(page==='home')renderHome();if(page==='templates')renderTemplates();if(page==='mybots')renderMyBots();if(page==='activity')renderActivity();if(page==='bot-detail')renderBotDetail();
}
function renderHome(){
  $('#todayLabel').textContent=todayFa();$('#statTotal').textContent=digits(state.bots.length);$('#statRunning').textContent=digits(state.bots.filter(b=>state.runtime.has(b.id)).length);$('#statEvents').textContent=digits(state.logs.filter(l=>new Date(l.time).toDateString()===new Date().toDateString()).length);
  $('#featuredTemplates').innerHTML=TEMPLATES.slice(0,4).map(t=>`<article class="featured-card" data-template="${t.id}" style="--tint:${t.tint}"><span class="template-emoji">${t.emoji}</span><div><b>${t.name}</b><small>${t.desc}</small></div></article>`).join('');
  const recent=state.bots.slice(0,3);$('#homeBotList').innerHTML=recent.length?recent.map(bot=>compactBotHTML(bot)).join(''):'<div class="empty-inline">هنوز رباتی نساختی؛ از دکمه ساخت ربات شروع کن.</div>';
}
function compactBotHTML(bot){const t=templateById(bot.templateId);const running=state.runtime.has(bot.id);return `<div class="compact-row" data-bot="${bot.id}"><span class="template-emoji" style="--tint:${t.tint}">${t.emoji}</span><div><b>${escapeHtml(bot.name)}</b><small>${t.name}</small></div><span class="status-mini" style="${running?'':'background:#f2f0f6;color:#999'}">${running?'فعال':'متوقف'}</span></div>`;}
function renderTemplates(){
  const term=state.search.trim().toLocaleLowerCase('fa');const list=TEMPLATES.filter(t=>(state.filter==='all'||t.category===state.filter)&&(!term||(t.name+' '+t.desc+' '+t.tag).toLocaleLowerCase('fa').includes(term)));
  $('#allTemplates').innerHTML=list.map(t=>`<article class="template-card" data-template="${t.id}" style="--tint:${t.tint}"><span class="template-emoji">${t.emoji}</span><b>${t.name}</b><p>${t.desc}</p><div class="template-meta">${t.features.length} قابلیت آماده · ${t.tag}</div><span class="card-arrow">←</span></article>`).join('')||'<div class="empty-inline">قالبی با این جست‌وجو پیدا نشد.</div>';
}
function renderMyBots(){
  const running=state.bots.filter(b=>state.runtime.has(b.id)).length;$('#myBotSummary').innerHTML=`<div><b>${digits(state.bots.length)} ربات</b><small>ذخیره‌شده روی همین دستگاه</small></div><div class="summary-right"><b>${digits(running)} فعال</b><small>از ${digits(state.bots.length)} ربات</small></div>`;
  $('#myBotList').innerHTML=state.bots.map(bot=>botCardHTML(bot)).join('');$('#emptyBots').classList.toggle('hidden',state.bots.length>0);
}
function botCardHTML(bot){const t=templateById(bot.templateId);const run=state.runtime.has(bot.id);const err=bot.lastError;return `<div class="bot-card" data-bot="${bot.id}"><span class="template-emoji" style="--tint:${t.tint}">${t.emoji}</span><div class="bot-card-main"><b>${escapeHtml(bot.name)}</b><small>${t.name} · ${escapeHtml(bot.username||'ربات متصل')}</small></div><div class="bot-card-end"><span class="status-pill ${run?'running':err?'error':''}">${run?'در حال اجرا':err?'نیازمند بررسی':'متوقف'}</span><span class="chevron">‹</span></div></div>`;}
function renderActivity(){
  $('#activityCount').textContent=digits(state.logs.length);$('#activityList').innerHTML=state.logs.slice(0,100).map(l=>`<div class="activity-item ${l.type==='error'?'error':l.type==='success'?'success':''}"><span class="activity-dot">${l.type==='error'?'!':l.type==='success'?'✓':'•'}</span><div><b>${escapeHtml(l.title)}</b><p>${escapeHtml(l.message)} <span class="muted">· ${escapeHtml(l.botName)}</span></p></div><time>${digits(new Date(l.time).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'}))}</time></div>`).join('');$('#emptyActivity').classList.toggle('hidden',state.logs.length>0);
}
function openModal(html){$('#modalContent').innerHTML=html;$('#modalBackdrop').classList.remove('hidden');document.body.style.overflow='hidden';}
function closeModal(){$('#modalBackdrop').classList.add('hidden');document.body.style.overflow='';}
function openCreateModal(templateId){
  state.selectedTemplate=templateId||'guardian';
  const templateOptions=TEMPLATES.map(t=>`<button class="picker-option ${t.id===state.selectedTemplate?'selected':''}" data-pick-template="${t.id}"><span class="template-emoji" style="--tint:${t.tint}">${t.emoji}</span><span><b>${t.name}</b><small>${t.tag}</small></span></button>`).join('');
  openModal(`<div class="section-kicker">مرحله ۱ از ۲ · انتخاب قالب</div><h2 class="modal-title" id="modalTitle">ربات جدید بساز</h2><p class="modal-subtitle">یک ربات آماده انتخاب کن. بعد از اتصال توکن، تنظیمات اختصاصی آن را تغییر می‌دهی.</p><div class="template-picker" id="templatePicker">${templateOptions}</div><label class="field"><span>اسم دلخواه ربات در AppMint</span><input id="newBotName" maxlength="40" placeholder="مثلاً نگهبان گروه من" value="${escapeHtml(templateById(state.selectedTemplate).name)}"></label><div class="modal-actions"><button class="primary-button" id="continueCreate">ادامه و اتصال توکن ←</button></div>`);
}
function showTokenStep(){
  const t=templateById(state.selectedTemplate);const name=$('#newBotName')?.value.trim()||t.name;
  openModal(`<div class="section-kicker">مرحله ۲ از ۲ · اتصال روبیکا</div><h2 class="modal-title" id="modalTitle">اتصال «${escapeHtml(name)}»</h2><p class="modal-subtitle">توکن را از BotFather روبیکا دریافت کن. AppMint با متد getMe اتصال را بررسی می‌کند.</p><label class="field"><span>توکن ربات</span><div class="token-field-row"><input id="botTokenInput" type="password" autocomplete="off" spellcheck="false" placeholder="توکن ربات را اینجا وارد کن"><button class="token-visibility" type="button" id="toggleTokenVisibility">نمایش</button></div></label><label class="checkline"><input type="checkbox" id="tokenConfirm"> <span>می‌دانم این توکن مانند رمز عبور ربات است و فقط توکن رباتی را وارد می‌کنم که مالک یا مجاز به مدیریت آن هستم.</span></label><div class="token-note">🔒 توکن در گزارش‌ها نمایش داده نمی‌شود. در صورت پشتیبانی دستگاه، با AES-GCM و کلید محلی رمزنگاری می‌شود؛ اگر این قابلیت در WebView فعال نباشد، توکن فقط تا بسته‌شدن برنامه در حافظه می‌ماند.</div><div id="connectError" class="warning-box hidden"></div><div class="modal-actions"><button class="outline-button" id="backToTemplates">بازگشت</button><button class="primary-button" id="verifyAndCreate">✓ بررسی و ساخت ربات</button></div>`);
  $('#verifyAndCreate').addEventListener('click',()=>createBotFromToken(name));$('#backToTemplates').addEventListener('click',()=>openCreateModal(state.selectedTemplate));
  $('#toggleTokenVisibility').addEventListener('click',()=>{const input=$('#botTokenInput');const reveal=input.type==='password';input.type=reveal?'text':'password';$('#toggleTokenVisibility').textContent=reveal?'مخفی':'نمایش';});
}
async function rubikaRequest(token,method,payload={}){
  if(window.AppMint && typeof window.AppMint.rubikaRequest==='function'){
    const result=await window.AppMint.rubikaRequest({token,method,payload});return normalizeResponse(result);
  }
  let response;const controller=typeof AbortController!=='undefined'?new AbortController():null;const timeout=controller?setTimeout(()=>controller.abort(),15000):null;
  try{response=await fetch(API_BASE+encodeURIComponent(token)+'/'+method,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),cache:'no-store',signal:controller?.signal});}
  catch(error){if(error?.name==='AbortError')throw new Error('درخواست از روبیکا پس از ۱۵ ثانیه پاسخی نگرفت؛ اینترنت یا وضعیت API را بررسی کن.');throw new Error('ارتباط مستقیم WebView با API روبیکا برقرار نشد. احتمالاً دسترسی شبکه یا محدودیت CORS وجود دارد؛ AppMint باید پل ارتباطی بومی (Native) را فعال کند.');}
  finally{if(timeout)clearTimeout(timeout);}
  const text=await response.text();let data;try{data=JSON.parse(text);}catch(e){throw new Error('پاسخ روبیکا قابل خواندن نبود ('+response.status+').');}
  if(!response.ok)throw new Error(data?.description||data?.message||'خطای ارتباط با سرور روبیکا: '+response.status);
  return normalizeResponse(data);
}
function normalizeResponse(raw){
  if(typeof raw==='string'){try{raw=JSON.parse(raw);}catch(e){throw new Error('پاسخ پل بومی JSON معتبر نیست.');}}
  if(raw?.status && !['OK','SUCCESS'].includes(String(raw.status).toUpperCase())){throw new Error(raw.description||raw.message||raw.data?.description||raw.error||String(raw.status));}
  return raw?.data??raw?.result??raw;
}
async function createBotFromToken(name){
  const input=$('#botTokenInput');const token=input.value.trim();const confirm=$('#tokenConfirm').checked;const err=$('#connectError');
  if(!token){err.textContent='لطفاً توکن ربات را وارد کن.';err.classList.remove('hidden');return;}if(!confirm){err.textContent='برای ادامه، تأیید مالکیت یا مجوز مدیریت توکن لازم است.';err.classList.remove('hidden');return;}
  const button=$('#verifyAndCreate');button.disabled=true;button.textContent='در حال بررسی اتصال…';err.classList.add('hidden');
  try{
    const data=await rubikaRequest(token,'getMe',{});const botInfo=data?.bot||data?.result?.bot||data?.data?.bot||data;
    if(!botInfo?.bot_id)throw new Error('پاسخ getMe شناسه معتبر ربات ندارد؛ توکن یا پاسخ API را بررسی کن.');
    const template=templateById(state.selectedTemplate);
    if(state.vaultPromise)await state.vaultPromise;
    const tokenVault=await encryptToken(token);const bot={id:uid(),templateId:template.id,name:name||template.name,username:botInfo?.username||'',rubikaTitle:botInfo?.bot_title||'',rubikaId:botInfo.bot_id,createdAt:Date.now(),config:{...template.defaults},tokenVault,offsetId:'',lastError:'',totalUpdates:0,totalActions:0};
    state.bots.unshift(bot);if(tokenVault.mode==='memory')state.memoryTokens.set(bot.id,token);saveData();addLog(bot.id,'success','اتصال موفق',`ربات ${bot.name} با متد getMe شناسایی شد.`);closeModal();showPage('bot-detail');state.activeBotId=bot.id;renderBotDetail();toast(tokenVault.mode==='memory'?'ربات اضافه شد؛ این دستگاه ذخیره امن توکن را پشتیبانی نکرد و پس از بستن برنامه باید دوباره توکن را وارد کنی.':'ربات با موفقیت اضافه و توکن رمزنگاری شد.','success');
  }catch(e){err.textContent='اتصال برقرار نشد: '+(e.message||'خطای نامشخص')+' — ممکن است توکن اشتباه باشد یا WebView اجازه ارتباط مستقیم با API را ندهد.';err.classList.remove('hidden');button.disabled=false;button.textContent='✓ بررسی و ساخت ربات';}
}
function openReconnectModal(){
  const bot=getActiveBot();if(!bot)return;
  openModal(`<div class="section-kicker">اتصال دوباره به روبیکا</div><h2 class="modal-title" id="modalTitle">اتصال مجدد «${escapeHtml(bot.name)}»</h2><p class="modal-subtitle">توکن جدید یا همان توکن قبلی را وارد کن. قبل از ذخیره، با متد getMe بررسی می‌شود.</p><label class="field"><span>توکن ربات</span><div class="token-field-row"><input id="reconnectTokenInput" type="password" autocomplete="off" spellcheck="false" placeholder="توکن ربات را وارد کن"><button class="token-visibility" type="button" id="toggleReconnectVisibility">نمایش</button></div></label><div id="reconnectError" class="warning-box hidden"></div><div class="modal-actions"><button class="outline-button" id="cancelReconnect">انصراف</button><button class="primary-button" id="verifyReconnect">بررسی و ذخیره</button></div>`);
  $('#cancelReconnect').onclick=closeModal;
  $('#toggleReconnectVisibility').onclick=()=>{const input=$('#reconnectTokenInput');const reveal=input.type==='password';input.type=reveal?'text':'password';$('#toggleReconnectVisibility').textContent=reveal?'مخفی':'نمایش';};
  $('#verifyReconnect').onclick=async()=>{
    const token=$('#reconnectTokenInput').value.trim();const error=$('#reconnectError');const button=$('#verifyReconnect');
    if(!token){error.textContent='توکن را وارد کن.';error.classList.remove('hidden');return;}
    button.disabled=true;button.textContent='در حال بررسی…';error.classList.add('hidden');
    try{
      const data=await rubikaRequest(token,'getMe',{});const info=data?.bot||data?.result?.bot||data?.data?.bot||data;
      if(!info?.bot_id)throw new Error('شناسه ربات در پاسخ getMe پیدا نشد.');
      if(bot.rubikaId&&String(info.bot_id)!==String(bot.rubikaId))throw new Error('این توکن متعلق به ربات دیگری است. برای جلوگیری از جابه‌جایی اشتباه، توکن قبلی این ربات را وارد کن.');
      if(state.vaultPromise)await state.vaultPromise;
      bot.tokenVault=await encryptToken(token);if(bot.tokenVault.mode==='memory')state.memoryTokens.set(bot.id,token);else state.memoryTokens.delete(bot.id);
      bot.username=info.username||bot.username||'';bot.rubikaTitle=info.bot_title||bot.rubikaTitle||'';bot.rubikaId=info.bot_id;bot.lastError='';saveData();addLog(bot.id,'success','اتصال مجدد موفق','توکن با متد getMe تأیید و ذخیره شد.');closeModal();renderBotDetail();toast('اتصال مجدد انجام شد.','success');
    }catch(err){error.textContent='اتصال ناموفق بود: '+(err.message||'خطای نامشخص');error.classList.remove('hidden');button.disabled=false;button.textContent='بررسی و ذخیره';}
  };
}
function getActiveBot(){return state.bots.find(b=>b.id===state.activeBotId);}
function openBot(id){state.activeBotId=id;showPage('bot-detail');}
function renderBotDetail(){
  const bot=getActiveBot();if(!bot)return;const t=templateById(bot.templateId);const running=state.runtime.has(bot.id);$('#detailTitle').textContent=bot.name;$('#detailAvatar').textContent=t.emoji;
  $('#detailStatusCard').innerHTML=`<div><b>${escapeHtml(bot.name)}</b><small>${t.name} · ${escapeHtml(bot.username||'اتصال محلی')}</small></div><span class="status-pill ${running?'running':bot.lastError?'error':''}">${running?'در حال اجرا':bot.lastError?'خطا در اجرا':'متوقف'}</span>`;
  $('#toggleBotRun').textContent=running?'■ توقف ربات':'▶ شروع ربات';$('#toggleBotRun').className=running?'outline-button':'primary-button';
  const logs=state.logs.filter(l=>l.botId===bot.id);$('#detail-overview').innerHTML=`<div class="panel-card"><h3>عملکرد ربات</h3><div class="metric-grid"><div class="metric-box"><b>${digits(bot.totalUpdates||0)}</b><small>آپدیت پردازش‌شده</small></div><div class="metric-box"><b>${digits(bot.totalActions||0)}</b><small>اقدام انجام‌شده</small></div></div><p>پولینگ با فاصله ثابت ۵ ثانیه، تنها زمانی اجرا می‌شود که AppMint باز و ربات فعال باشد.</p></div><div class="panel-card"><h3>قابلیت‌های این قالب</h3>${t.features.map(f=>`<div class="toggle-row"><span>${f}</span><span class="secure-pill">آماده</span></div>`).join('')}</div><div class="panel-card"><h3>آخرین وضعیت</h3><p>${bot.lastError?escapeHtml(bot.lastError):running?'اتصال در حال دریافت آپدیت است.':'ربات در حال حاضر متوقف است.'}</p><p>آخرین گزارش: ${logs[0]?digits(new Date(logs[0].time).toLocaleString('fa-IR')):'هنوز گزارشی ثبت نشده'}</p></div>`;
  $('#detail-config').innerHTML=renderConfigForm(bot,t);
  $('#detail-tools').innerHTML=renderTools(bot,t);
  $('#detail-logs').innerHTML=logs.slice(0,30).map(l=>`<div class="mini-log"><span>${escapeHtml(l.title)} — ${escapeHtml(l.message)}</span><small>${digits(new Date(l.time).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'}))}</small></div>`).join('')||'<div class="empty-inline">گزارشی برای این ربات وجود ندارد.</div>';
}
function renderConfigForm(bot,t){
  const c=bot.config||{};let fields='';
  const addText=(key,label,placeholder='')=>{fields+=`<label class="field"><span>${label}</span><textarea data-config="${key}" placeholder="${escapeHtml(placeholder)}">${escapeHtml(c[key]||'')}</textarea></label>`;};
  const addInput=(key,label,placeholder='')=>{fields+=`<label class="field"><span>${label}</span><input data-config="${key}" value="${escapeHtml(c[key]||'')}" placeholder="${escapeHtml(placeholder)}"></label>`;};
  const addToggle=(key,label,defaultVal=false)=>{fields+=`<div class="toggle-row"><span>${label}</span><input class="toggle" type="checkbox" data-config-toggle="${key}" ${(c[key]??defaultVal)?'checked':''}></div>`;};
  if(t.id==='guardian'){addToggle('filterWords','فیلتر کلمات ممنوع',true);addText('blockedWords','کلمات ممنوع','هر کلمه در یک خط');addToggle('filterLinks','حذف پیام‌های حاوی لینک',false);}
  if(t.id==='auto_reply'||t.id==='shop'){if(t.id==='shop')addInput('shopName','نام کسب‌وکار','فروشگاه من');addText('replyRules','قوانین پاسخ خودکار','هر خط به شکل کلمه=پاسخ');}
  if(['welcome','faq','shop'].includes(t.id)){addText('welcomeMessage','متن پیام راهنما / شروع','متن پیام برای دستور /start');}
  if(t.id==='poll'){addInput('pollQuestion','سؤال نظرسنجی');addText('pollOptions','گزینه‌ها','هر گزینه در یک خط');}
  if(t.id==='quiz'){addInput('quizQuestion','سؤال مسابقه');addInput('quizAnswer','پاسخ صحیح');}
  if(t.id==='reminder'){addInput('maxReminderMinutes','حداکثر زمان یادآور (دقیقه)','1440');}
  if(t.id==='announcer'){addInput('announcePrefix','پیشوند اطلاعیه','📣 اطلاعیه جدید');}
  if(t.id==='moderator'){fields+='<div class="warning-box">اقدامات حذف پیام و مسدودسازی فقط از ابزارهای دستی انجام می‌شوند و قبل از اجرا تأیید می‌گیرند.</div>';}
  return `<div class="panel-card"><h3>تنظیمات اختصاصی ${t.name}</h3>${fields||'<p>برای این قالب تنظیمات دیگری تعریف نشده است.</p>'}<button class="primary-button" id="saveBotConfig">ذخیره تغییرات</button></div><div class="panel-card"><h3>تنظیمات اجرای ربات</h3><div class="toggle-row"><span>پولینگ خودکار هر ۵ ثانیه</span><span class="secure-pill">ثابت</span></div><div class="toggle-row"><span>ثبت رویدادها در همین دستگاه</span><span class="secure-pill">فعال</span></div></div>`;
}
function renderTools(bot,t){
  let html=`<div class="panel-card"><h3>ارسال پیام از پنل</h3><label class="field"><span>شناسه چت (chat_id)</span><input id="toolChatId" placeholder="شناسه چت روبیکا"></label><label class="field"><span>متن پیام</span><textarea id="toolMessage" placeholder="متن پیام برای ارسال…"></textarea></label><button class="primary-button" id="sendPanelMessage">ارسال پیام</button></div>`;
  if(['moderator','guardian'].includes(t.id))html+=`<div class="panel-card"><h3>ابزار مدیریت گروه</h3><label class="field"><span>شناسه چت</span><input id="modChatId" placeholder="chat_id"></label><label class="field"><span>شناسه پیام برای حذف</span><input id="modMessageId" placeholder="message_id"></label><button class="outline-button" id="deleteTargetMessage">حذف پیام مشخص</button><div class="divider"></div><label class="field"><span>شناسه کاربر</span><input id="modUserId" placeholder="user_id"></label><div class="inline-form"><button class="outline-button" id="banTargetUser">مسدودسازی</button><button class="outline-button" id="unbanTargetUser">رفع مسدودیت</button></div><p>این عملیات به دسترسی ادمین و مجوز مربوطه در گروه نیاز دارد. هر عملیات قبل از ارسال تأیید می‌شود.</p></div>`;
  if(t.id==='poll')html+=`<div class="panel-card"><h3>ارسال نظرسنجی آماده</h3><label class="field"><span>شناسه چت</span><input id="pollChatId" placeholder="chat_id"></label><button class="primary-button" id="sendConfiguredPoll">ارسال نظرسنجی</button></div>`;
  if(t.id==='announcer')html+=`<div class="panel-card"><h3>ارسال اطلاعیه</h3><label class="field"><span>شناسه چت / کانال</span><input id="announceChatId" placeholder="chat_id"></label><label class="field"><span>متن اطلاعیه</span><textarea id="announceText" placeholder="متن اطلاعیه…"></textarea></label><button class="primary-button" id="sendAnnouncement">انتشار اطلاعیه</button></div>`;
  html+=`<div class="panel-card"><h3>دستورات قابل استفاده در چت</h3><p>/start — شروع و نمایش پیام راهنما<br>/help — راهنمای ربات<br>${t.id==='poll'?'/poll — ارسال نظرسنجی':''}${t.id==='quiz'?'/quiz — ارسال سؤال مسابقه':''}${t.id==='announcer'?'/announce متن — انتشار اطلاعیه':''}${t.id==='reminder'?'/remind 10 متن — یادآور پس از ۱۰ دقیقه':''}</p></div>`;
  return html;
}
function persistBotConfig(){const bot=getActiveBot();if(!bot)return;$$('[data-config]').forEach(el=>bot.config[el.dataset.config]=el.value);$$('[data-config-toggle]').forEach(el=>bot.config[el.dataset.configToggle]=el.checked);saveData();addLog(bot.id,'info','تنظیمات به‌روزرسانی شد','تنظیمات قالب ربات ذخیره شد.');toast('تنظیمات ذخیره شد.','success');renderBotDetail();}
async function toggleBot(){const bot=getActiveBot();if(!bot)return;if(state.runtime.has(bot.id)){stopBot(bot.id);toast('ربات متوقف شد.');return;}await startBot(bot);}
async function startBot(bot){
  if(state.vaultPromise)await state.vaultPromise;
  const token=await decryptToken(bot);if(!token){toast('توکن این ربات در دسترس نیست. برای امنیت، دوباره آن را متصل کن.','error');addLog(bot.id,'error','توکن در دسترس نیست','به دلیل محدودیت ذخیره‌سازی امن، لازم است ربات دوباره متصل شود.');return;}
  if(state.runtime.has(bot.id))return;
  const runtime={stopped:false,token,loop:null,busy:false,lastErrorAt:0};state.runtime.set(bot.id,runtime);bot.lastError='';saveData();addLog(bot.id,'success','ربات شروع شد','دریافت آپدیت با فاصله ۵ ثانیه آغاز شد.');renderBotDetail();renderMyBots();
  const loop=async()=>{
    if(runtime.stopped)return;runtime.busy=true;
    try{const payload={limit:50};if(bot.offsetId)payload.offset_id=bot.offsetId;const result=await rubikaRequest(token,'getUpdates',payload);const updates=Array.isArray(result?.updates)?result.updates:[];if(result?.next_offset_id)bot.offsetId=String(result.next_offset_id);else if(result?.nextOffsetId)bot.offsetId=String(result.nextOffsetId);
      if(updates.length){bot.totalUpdates=(bot.totalUpdates||0)+updates.length;for(const update of updates){try{await processUpdate(bot,token,update);}catch(err){addLog(bot.id,'error','خطا در پردازش آپدیت',err.message||'خطای نامشخص');}}saveData();}
      else if(result?.next_offset_id||result?.nextOffsetId){saveData();}
      bot.lastError='';
    }catch(err){bot.lastError=err.message||'خطای ارتباط با روبیکا';if(Date.now()-runtime.lastErrorAt>20000){addLog(bot.id,'error','خطای دریافت آپدیت',bot.lastError);runtime.lastErrorAt=Date.now();}saveData();}
    runtime.busy=false;if(!runtime.stopped)runtime.loop=setTimeout(loop,POLL_INTERVAL);
  };
  runtime.loop=setTimeout(loop,0);
}
function stopBot(botId){const runtime=state.runtime.get(botId);if(runtime){runtime.stopped=true;clearTimeout(runtime.loop);state.runtime.delete(botId);}const bot=state.bots.find(b=>b.id===botId);if(bot)addLog(botId,'info','ربات متوقف شد','درخواست‌های پولینگ متوقف شدند.');renderBotDetail();renderMyBots();renderHome();}
async function processUpdate(bot,token,update){
  const msg=update?.new_message;const chatId=update.chat_id||msg?.chat_id;if(!chatId)return;
  const cfg=bot.config||{};const template=bot.templateId;
  if(update.type==='StartedBot' && ['welcome','faq','shop'].includes(template)){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:cfg.welcomeMessage||`سلام! من ${bot.name} هستم. برای راهنما /help رو بفرست.`});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','پیام شروع ارسال شد','کاربر گفت‌وگو با ربات را آغاز کرد.');return;}
  if(update.type!=='NewMessage'||!msg||msg.sender_type==='Bot')return;const text=String(msg.text||'').trim();const messageId=msg.message_id;const senderId=msg.sender_id;
  if(!text)return;
  if(template==='guardian'){
    const words=String(cfg.blockedWords||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
    const containsBad=cfg.filterWords!==false&&words.some(w=>w&&text.toLocaleLowerCase('fa').includes(w.toLocaleLowerCase('fa')));const hasLink=cfg.filterLinks===true&&/(https?:\/\/|www\.)/i.test(text);
    if((containsBad||hasLink)&&messageId){await rubikaRequest(token,'deleteMessage',{chat_id:chatId,message_id:messageId});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','پیام حذف شد',containsBad?'پیام شامل کلمه فیلترشده بود.':'پیام شامل لینک بود.');return;}
  }
  if(text==='/start'||text==='/help'){
    const greeting=cfg.welcomeMessage||`سلام! من ${bot.name} هستم.\nبرای راهنما /help رو بفرست.`;await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:greeting});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','پاسخ به دستور',`دستور ${text} پاسخ داده شد.`);return;
  }
  if(template==='auto_reply'||template==='shop'){
    const rules=String(cfg.replyRules||'').split(/\r?\n/).map(line=>{const i=line.indexOf('=');return i>0?{key:line.slice(0,i).trim(),value:line.slice(i+1).trim()}:null;}).filter(Boolean);
    const match=rules.find(r=>r.key&&text.toLocaleLowerCase('fa').includes(r.key.toLocaleLowerCase('fa')));if(match){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:match.value,reply_to_message_id:messageId});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','پاسخ خودکار ارسال شد',`کلیدواژه: ${match.key}`);return;}
  }
  if(template==='poll'&&text==='/poll'){
    const options=String(cfg.pollOptions||'گزینه اول\nگزینه دوم').split(/\r?\n/).map(x=>x.trim()).filter(Boolean).slice(0,10);if(options.length>=2){await rubikaRequest(token,'sendPoll',{chat_id:chatId,question:cfg.pollQuestion||'نظرت چیه؟',options});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','نظرسنجی ارسال شد','نظرسنجی به چت فرستاده شد.');}else await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:'برای نظرسنجی حداقل دو گزینه در تنظیمات وارد کن.'});return;
  }
  if(template==='quiz'&&text==='/quiz'){
    await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:'🧠 چالش امروز\n'+(cfg.quizQuestion||'سؤال مسابقه هنوز تنظیم نشده است.')});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','سؤال مسابقه ارسال شد','سؤال کوئیز در چت منتشر شد.');return;
  }
  if(template==='quiz'&&cfg.quizAnswer&&text.toLocaleLowerCase('fa')===String(cfg.quizAnswer).trim().toLocaleLowerCase('fa')){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:'آفرین! پاسخ درست بود 🎉',reply_to_message_id:messageId});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','پاسخ صحیح مسابقه','پاسخ درست دریافت شد.');return;}
  if(template==='announcer'&&text.startsWith('/announce ')){
    const announcement=text.slice(10).trim();if(announcement){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:(cfg.announcePrefix?cfg.announcePrefix+'\n':'')+announcement});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','اطلاعیه منتشر شد','اطلاعیه از طریق دستور ارسال شد.');}return;
  }
  if(template==='reminder'&&text.startsWith('/remind ')){
    const match=text.match(/^\/remind\s+(\d+)\s+([\s\S]+)/);if(!match){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:'فرمت درست: /remind 10 متن یادآوری'});return;}const requestedMinutes=Number.parseInt(match[1],10);const configuredMax=Number.parseInt(cfg.maxReminderMinutes||'1440',10);const safeMax=Number.isFinite(configuredMax)&&configuredMax>0?configuredMax:1440;const minutes=Math.max(1,Math.min(Number.isFinite(requestedMinutes)?requestedMinutes:1,safeMax));const reminderText=match[2].trim();const key=bot.id+'_'+uid();const timer=setTimeout(async()=>{if(!state.runtime.has(bot.id))return;try{await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:'⏰ یادآوری:\n'+reminderText});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','یادآور ارسال شد',reminderText);}catch(e){addLog(bot.id,'error','ارسال یادآور ناموفق بود',e.message);}},minutes*60000);state.reminders.set(key,timer);await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:`یادآور برای ${minutes} دقیقه دیگر ثبت شد. (تا وقتی برنامه باز و ربات فعال باشد)`});addLog(bot.id,'info','یادآور تنظیم شد',`${minutes} دقیقه دیگر`);return;
  }
  if(text.startsWith('/'))addLog(bot.id,'info','دستور دریافت شد',text.slice(0,100));
}
async function runBotMethod(method,payload,successMessage){
  const bot=getActiveBot();if(!bot)return;const token=await decryptToken(bot);if(!token){toast('توکن در دسترس نیست.','error');return;}
  try{await rubikaRequest(token,method,payload);bot.totalActions=(bot.totalActions||0)+1;bot.lastError='';addLog(bot.id,'success',successMessage,'درخواست با موفقیت به API روبیکا ارسال شد.');toast(successMessage,'success');renderBotDetail();}
  catch(e){addLog(bot.id,'error','عملیات ناموفق بود',e.message);toast('خطا: '+e.message,'error');}
}
function confirmAction(message,yesLabel,action){openModal(`<h2 class="modal-title" id="modalTitle">تأیید عملیات</h2><p class="modal-subtitle">${escapeHtml(message)}</p><div class="modal-actions"><button class="outline-button" id="cancelConfirm">انصراف</button><button class="primary-button" id="confirmDo">${escapeHtml(yesLabel)}</button></div>`);$('#cancelConfirm').onclick=closeModal;$('#confirmDo').onclick=()=>{closeModal();action();};}
function bindEvents(){
  $('#brandHome').onclick=()=>showPage('home');$('#heroCreate').onclick=()=>openCreateModal();$('#myBotsCreate').onclick=()=>openCreateModal();$('#navCreate').onclick=()=>openCreateModal();$('#emptyCreate').onclick=()=>openCreateModal();$('#modalClose').onclick=closeModal;$('#modalBackdrop').addEventListener('click',e=>{if(e.target===$('#modalBackdrop'))closeModal();});
  $$('[data-nav]').forEach(el=>el.addEventListener('click',()=>showPage(el.dataset.nav)));
  $('#templateFilters').addEventListener('click',e=>{const btn=e.target.closest('[data-filter]');if(!btn)return;state.filter=btn.dataset.filter;$$('[data-filter]').forEach(b=>b.classList.toggle('active',b===btn));renderTemplates();});
  $('#templateSearch').addEventListener('input',e=>{state.search=e.target.value;renderTemplates();});
  document.addEventListener('click',e=>{
    const template=e.target.closest('[data-template]');if(template){openCreateModal(template.dataset.template);return;}
    const pick=e.target.closest('[data-pick-template]');if(pick){state.selectedTemplate=pick.dataset.pickTemplate;openCreateModal(state.selectedTemplate);return;}
    const bot=e.target.closest('[data-bot]');if(bot){openBot(bot.dataset.bot);return;}
  });
  // The create modal is rendered dynamically, so its Continue button must use delegation.
  document.addEventListener('click',e=>{if(e.target.closest('#continueCreate'))showTokenStep();});
  $('#toggleBotRun').onclick=toggleBot;
  $('#reconnectBot').onclick=openReconnectModal;
  $('#backFromBot').onclick=()=>showPage('mybots');
  $('#deleteBot').onclick=()=>{const bot=getActiveBot();if(!bot)return;confirmAction(`ربات «${bot.name}» و تنظیمات محلی آن حذف شود؟ این کار ربات را از روبیکا حذف نمی‌کند.`, 'حذف ربات',()=>{stopBot(bot.id);state.memoryTokens.delete(bot.id);state.bots=state.bots.filter(b=>b.id!==bot.id);saveData();addLog('','info','ربات از AppMint حذف شد',bot.name);showPage('mybots');toast('ربات از فهرست AppMint حذف شد.');});};
  $('#detailTabs').addEventListener('click',e=>{const btn=e.target.closest('[data-tab]');if(!btn)return;$$('[data-tab]').forEach(b=>b.classList.toggle('active',b===btn));$$('.detail-panel').forEach(p=>p.classList.toggle('active',p.id==='detail-'+btn.dataset.tab));});
  $('#editBotConfig').onclick=()=>{ $$('#detailTabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab==='config'));$$('.detail-panel').forEach(p=>p.classList.toggle('active',p.id==='detail-config'));};
  $('#detail-config').addEventListener('click',e=>{if(e.target.id==='saveBotConfig')persistBotConfig();});
  $('#detail-tools').addEventListener('click',e=>{
    if(e.target.id==='sendPanelMessage'){const chat=$('#toolChatId').value.trim(),text=$('#toolMessage').value.trim();if(!chat||!text){toast('شناسه چت و متن پیام را وارد کن.','error');return;}runBotMethod('sendMessage',{chat_id:chat,text},'پیام ارسال شد');}
    if(e.target.id==='deleteTargetMessage'){const chat=$('#modChatId').value.trim(),msg=$('#modMessageId').value.trim();if(!chat||!msg){toast('شناسه چت و پیام را کامل کن.','error');return;}confirmAction('این پیام از چت روبیکا حذف شود؟','حذف پیام',()=>runBotMethod('deleteMessage',{chat_id:chat,message_id:msg},'پیام حذف شد'));}
    if(e.target.id==='banTargetUser'||e.target.id==='unbanTargetUser'){const chat=$('#modChatId').value.trim(),user=$('#modUserId').value.trim();if(!chat||!user){toast('شناسه چت و کاربر را وارد کن.','error');return;}const ban=e.target.id==='banTargetUser';confirmAction(ban?'این کاربر از گروه/کانال مسدود شود؟':'مسدودیت این کاربر برداشته شود؟',ban?'مسدودسازی':'رفع مسدودیت',()=>runBotMethod(ban?'banChatMember':'unbanChatMember',{chat_id:chat,user_id:user},ban?'کاربر مسدود شد':'رفع مسدودیت انجام شد'));}
    if(e.target.id==='sendConfiguredPoll'){const bot=getActiveBot(),chat=$('#pollChatId').value.trim(),opts=String(bot.config.pollOptions||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);if(!chat||opts.length<2){toast('شناسه چت و حداقل دو گزینه لازم است.','error');return;}runBotMethod('sendPoll',{chat_id:chat,question:bot.config.pollQuestion||'نظرسنجی',options:opts},'نظرسنجی ارسال شد');}
    if(e.target.id==='sendAnnouncement'){const chat=$('#announceChatId').value.trim(),txt=$('#announceText').value.trim(),bot=getActiveBot();if(!chat||!txt){toast('شناسه چت و متن اطلاعیه لازم است.','error');return;}runBotMethod('sendMessage',{chat_id:chat,text:(bot.config.announcePrefix?bot.config.announcePrefix+'\n':'')+txt},'اطلاعیه ارسال شد');}
  });
  $('#clearLogs').onclick=()=>confirmAction('تمام گزارش‌های ذخیره‌شده در AppMint پاک شوند؟','پاک‌کردن گزارش‌ها',()=>{state.logs=[];saveData();renderActivity();toast('گزارش‌ها پاک شدند.');});
  $('#helpButton').onclick=()=>{openModal(`<h2 class="modal-title" id="modalTitle">راهنمای شروع AppMint</h2><p class="modal-subtitle">۱. در BotFather روبیکا یک ربات بساز و توکنش را بگیر.<br>۲. در AppMint قالب دلخواهت را انتخاب و توکن را متصل کن.<br>۳. برای امکانات گروه، ربات را دستی به گروه اضافه و دسترسی‌های لازم را فعال کن.<br>۴. ربات را از پنل شروع کن؛ تا وقتی برنامه باز است، دریافت آپدیت هر ۵ ثانیه انجام می‌شود.</p><div class="warning-box">AppMint نمی‌تواند خودش از طرف روبیکا توکن صادر کند. هر ربات باید قبلاً در BotFather ساخته شده باشد.</div><div class="modal-actions"><button class="primary-button" id="helpClose">متوجه شدم</button></div>`);$('#helpClose').onclick=closeModal;};
  $('#privacyInfo').onclick=()=>openModal(`<h2 class="modal-title" id="modalTitle">حریم خصوصی</h2><p class="modal-subtitle">تنظیمات، نام ربات‌ها و گزارش‌ها در فضای محلی همین دستگاه ذخیره می‌شوند. توکن‌ها به‌صورت متن ساده در فایل تنظیمات ذخیره نمی‌شوند. در صورت پشتیبانی Web Crypto، توکن با AES-GCM رمزنگاری و کلید غیرقابل‌استخراج در IndexedDB نگهداری می‌شود. اگر WebView قابلیت لازم را نداشته باشد، توکن فقط در حافظه تا زمان بسته‌شدن صفحه باقی می‌ماند.</p><div class="warning-box">هر شخصی که به گوشی یا محیط WebView دسترسی کامل داشته باشد ممکن است به داده‌های برنامه دسترسی پیدا کند؛ قفل دستگاه و نگهداری امن توکن ضروری است.</div>`);
  $('#apiInfo').onclick=()=>window.location.assign('https://rubika.ir/botapi/methods');
  $('#exportData').onclick=()=>{const blob=new Blob([JSON.stringify({bots:state.bots.map(({tokenVault,...b})=>({...b,tokenVault:undefined})),logs:state.logs},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='appmint-settings.json';a.click();URL.revokeObjectURL(a.href);toast('فایل تنظیمات بدون توکن آماده شد.','success');};
  $('#resetApp').onclick=()=>confirmAction('همه ربات‌ها و گزارش‌های AppMint از این دستگاه پاک شوند؟ این کار ربات‌ها را از روبیکا حذف یا متوقف نمی‌کند.', 'پاک‌کردن همه اطلاعات',()=>{[...state.runtime.keys()].forEach(stopBot);state.bots=[];state.logs=[];state.memoryTokens.clear();localStorage.removeItem(APP_DATA_KEY);saveData();showPage('home');toast('اطلاعات محلی پاک شد.');});
}
function init(){loadData();state.vaultPromise=openVault();$('#todayLabel').textContent=todayFa();bindEvents();renderHome();renderTemplates();renderMyBots();renderActivity();}
window.addEventListener('beforeunload',()=>{for(const id of [...state.runtime.keys()])stopBot(id);});
init();
