package ir.appmint.rubikabotbuilder;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String START_URL = "file:///android_asset/index.html";
    private static final String RUBIKA_API_BASE = "https://botapi.rubika.ir/v3/";
    private static final int CONNECT_TIMEOUT_MS = 15_000;
    private static final int READ_TIMEOUT_MS = 15_000;
    private static final int MAX_RESPONSE_BYTES = 2 * 1024 * 1024;

    private WebView webView;
    private final ExecutorService networkExecutor = Executors.newFixedThreadPool(3);

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23, 21, 44));
        getWindow().setNavigationBarColor(Color.rgb(23, 21, 44));
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(23, 21, 44));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AppMintNativeBridge(), "AppMintNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternalUrl(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternalUrl(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installPromiseBridge(view);
            }
        });

        setContentView(webView);
        webView.loadUrl(START_URL);
    }

    private boolean handleExternalUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme();
        if ("file".equalsIgnoreCase(scheme)) {
            String path = uri.getPath() == null ? "" : uri.getPath();
            return !path.startsWith("/android_asset/");
        }
        if ("about".equalsIgnoreCase(scheme)) {
            return false;
        }
        if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
                // Do not crash the app when the device has no browser handler.
            }
            return true;
        }
        return true;
    }

    private void installPromiseBridge(WebView view) {
        String script = "(function(){"
                + "if(window.__appMintBridgeInstalled)return;"
                + "window.__appMintBridgeInstalled=true;"
                + "const pending=new Map();let seq=0;"
                + "window.__appMintResolve=function(id,responseText){const item=pending.get(id);if(!item)return;pending.delete(id);clearTimeout(item.timer);item.resolve(responseText);};"
                + "window.__appMintReject=function(id,message){const item=pending.get(id);if(!item)return;pending.delete(id);clearTimeout(item.timer);item.reject(new Error(String(message||'ارتباط بومی ناموفق بود.')));};"
                + "window.AppMint=window.AppMint||{};"
                + "window.AppMint.rubikaRequest=function(request){return new Promise(function(resolve,reject){"
                + "const id=String(++seq)+'_'+Date.now();"
                + "const timer=setTimeout(function(){pending.delete(id);reject(new Error('درخواست بومی بیش از حد طول کشید.'));},18000);"
                + "pending.set(id,{resolve:resolve,reject:reject,timer:timer});"
                + "try{window.AppMintNative.rubikaRequest(JSON.stringify(request||{}),id);}"
                + "catch(error){pending.delete(id);clearTimeout(timer);reject(error);}"
                + "});};"
                + "})();";
        view.evaluateJavascript(script, null);
    }

    private final class AppMintNativeBridge {
        @JavascriptInterface
        public void rubikaRequest(String requestJson, String callbackId) {
            if (callbackId == null || callbackId.length() > 100) {
                return;
            }
            final String safeCallbackId = callbackId;
            final String token;
            final String method;
            final JSONObject payload;

            try {
                JSONObject request = new JSONObject(requestJson == null ? "{}" : requestJson);
                token = request.optString("token", "").trim();
                method = request.optString("method", "").trim();
                payload = request.optJSONObject("payload") == null
                        ? new JSONObject()
                        : request.optJSONObject("payload");
            } catch (JSONException error) {
                postFailure(safeCallbackId, "درخواست ارسالی معتبر نیست.");
                return;
            }

            if (token.isEmpty() || token.length() > 4096) {
                postFailure(safeCallbackId, "توکن ربات خالی یا نامعتبر است.");
                return;
            }
            if (!method.matches("[A-Za-z][A-Za-z0-9]{0,63}")) {
                postFailure(safeCallbackId, "نام متد API معتبر نیست.");
                return;
            }

            networkExecutor.execute(() -> {
                try {
                    String response = sendRubikaRequest(token, method, payload);
                    postSuccess(safeCallbackId, response);
                } catch (Exception error) {
                    String message = error.getMessage();
                    postFailure(safeCallbackId,
                            message == null || message.trim().isEmpty()
                                    ? "ارتباط با API روبیکا ناموفق بود."
                                    : message);
                }
            });
        }
    }

    private String sendRubikaRequest(String token, String method, JSONObject payload) throws Exception {
        String encodedToken = URLEncoder.encode(token, "UTF-8").replace("+", "%20");
        URL url = new URL(RUBIKA_API_BASE + encodedToken + "/" + method);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setUseCaches(false);
        connection.setDoOutput(true);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        connection.setFixedLengthStreamingMode(body.length);

        try {
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
                output.flush();
            }

            int statusCode = connection.getResponseCode();
            InputStream stream = statusCode >= 400 ? connection.getErrorStream() : connection.getInputStream();
            String responseBody = stream == null ? "{}" : readLimited(stream);

            try {
                new JSONObject(responseBody);
            } catch (JSONException invalidJson) {
                throw new IOException("پاسخ روبیکا JSON معتبر نیست (HTTP " + statusCode + ").");
            }

            if (statusCode < 200 || statusCode >= 300) {
                throw new IOException(extractApiError(responseBody, statusCode));
            }
            return responseBody;
        } finally {
            connection.disconnect();
        }
    }

    private String readLimited(InputStream input) throws IOException {
        try (InputStream stream = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int count;
            while ((count = stream.read(buffer)) != -1) {
                total += count;
                if (total > MAX_RESPONSE_BYTES) {
                    throw new IOException("حجم پاسخ روبیکا بیش از حد مجاز است.");
                }
                output.write(buffer, 0, count);
            }
            return output.toString("UTF-8");
        }
    }

    private String extractApiError(String responseBody, int statusCode) {
        try {
            JSONObject body = new JSONObject(responseBody);
            String description = body.optString("description", "");
            if (description.isEmpty()) description = body.optString("message", "");
            if (description.isEmpty()) description = body.optString("error", "");
            if (!description.isEmpty()) return description;
        } catch (JSONException ignored) {
            // Fall through to the generic HTTP message.
        }
        return "خطای سرور روبیکا (HTTP " + statusCode + ").";
    }

    private void postSuccess(String callbackId, String responseText) {
        runOnUiThread(() -> {
            if (webView == null) return;
            String script = "window.__appMintResolve && window.__appMintResolve("
                    + JSONObject.quote(callbackId) + "," + JSONObject.quote(responseText) + ");";
            webView.evaluateJavascript(script, null);
        });
    }

    private void postFailure(String callbackId, String message) {
        runOnUiThread(() -> {
            if (webView == null) return;
            String script = "window.__appMintReject && window.__appMintReject("
                    + JSONObject.quote(callbackId) + "," + JSONObject.quote(message) + ");";
            webView.evaluateJavascript(script, null);
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AppMintNative");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        networkExecutor.shutdownNow();
        super.onDestroy();
    }
}
