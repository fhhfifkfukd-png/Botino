package ir.appmint.rubikabotbuilder;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Stores bot credentials and settings encrypted with a non-exportable Android Keystore key. */
public final class BotCredentialVault {
    private static final String PREFS = "appmint_background_bots";
    private static final String ALIAS = "appmint_background_bot_v1";
    private static final int IV_BYTES = 12;
    private BotCredentialVault() {}

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static SecretKey getKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(ALIAS)) {
            return (SecretKey) keyStore.getKey(ALIAS, null);
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private static String encrypt(String plainText) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getKey());
        byte[] encrypted = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        byte[] iv = cipher.getIV();
        byte[] packed = new byte[iv.length + encrypted.length];
        System.arraycopy(iv, 0, packed, 0, iv.length);
        System.arraycopy(encrypted, 0, packed, iv.length, encrypted.length);
        return Base64.encodeToString(packed, Base64.NO_WRAP);
    }

    private static String decrypt(String encoded) throws Exception {
        byte[] packed = Base64.decode(encoded, Base64.NO_WRAP);
        if (packed.length <= IV_BYTES) throw new IllegalArgumentException("Encrypted record is incomplete");
        byte[] iv = new byte[IV_BYTES];
        byte[] encrypted = new byte[packed.length - IV_BYTES];
        System.arraycopy(packed, 0, iv, 0, IV_BYTES);
        System.arraycopy(packed, IV_BYTES, encrypted, 0, encrypted.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getKey(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }

    public static void put(Context context, String botId, JSONObject bot) throws Exception {
        if (botId == null || botId.trim().isEmpty()) throw new IllegalArgumentException("شناسه ربات نامعتبر است.");
        String sealed = encrypt(bot.toString());
        prefs(context).edit().putString(botId, sealed).commit();
    }

    public static JSONObject get(Context context, String botId) {
        String sealed = prefs(context).getString(botId, null);
        if (sealed == null) return null;
        try { return new JSONObject(decrypt(sealed)); }
        catch (Exception error) { return null; }
    }

    public static Map<String, JSONObject> getAll(Context context) {
        Map<String, JSONObject> result = new HashMap<>();
        for (Map.Entry<String, ?> entry : prefs(context).getAll().entrySet()) {
            if (!(entry.getValue() instanceof String)) continue;
            try { result.put(entry.getKey(), new JSONObject(decrypt((String) entry.getValue()))); }
            catch (Exception ignored) { /* A damaged record is ignored rather than exposing its contents. */ }
        }
        return result;
    }

    public static Map<String, JSONObject> getEnabledAll(Context context) {
        Map<String, JSONObject> result = new HashMap<>();
        for (Map.Entry<String, JSONObject> entry : getAll(context).entrySet()) {
            if (entry.getValue().optBoolean("enabled", true)) result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    public static ArrayList<String> ids(Context context) {
        return new ArrayList<>(getEnabledAll(context).keySet());
    }

    public static void setEnabled(Context context, String botId, boolean enabled) {
        JSONObject bot = get(context, botId);
        if (bot == null) return;
        try { bot.put("enabled", enabled); put(context, botId, bot); }
        catch (Exception ignored) { }
    }

    public static void remove(Context context, String botId) {
        prefs(context).edit().remove(botId).commit();
    }

    public static void clear(Context context) {
        prefs(context).edit().clear().commit();
    }
}
