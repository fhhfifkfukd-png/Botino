package ir.appmint.rubikabotbuilder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/** User-visible foreground service that keeps explicitly enabled Rubika bots polling. */
public class BotForegroundService extends Service {
    public static final String ACTION_START = "ir.appmint.action.START_BOT";
    public static final String ACTION_STOP = "ir.appmint.action.STOP_BOT";
    public static final String ACTION_STOP_ALL = "ir.appmint.action.STOP_ALL";
    public static final String ACTION_UPDATE_CONFIG = "ir.appmint.action.UPDATE_CONFIG";
    public static final String ACTION_REMOVE_BOT = "ir.appmint.action.REMOVE_BOT";
    public static final String EXTRA_BOT = "bot_json";
    public static final String EXTRA_BOT_ID = "bot_id";
    public static final String ACTION_UPDATE_POLL_INTERVAL = "ir.appmint.action.UPDATE_POLL_INTERVAL";
    public static final String EXTRA_POLL_INTERVAL_SECONDS = "poll_interval_seconds";
    private static final String CHANNEL_ID = "appmint_bot_service";
    private static final int NOTIFICATION_ID = 7182;
    private static final String API_BASE = "https://botapi.rubika.ir/v3/";
    private static final int DEFAULT_POLL_INTERVAL_SECONDS = 2;
    private static final int MIN_POLL_INTERVAL_SECONDS = 1;
    private static final int MAX_POLL_INTERVAL_SECONDS = 5;
    private static final int MAX_RESPONSE_BYTES = 2 * 1024 * 1024;

    private static volatile boolean running;
    private final Map<String, JSONObject> bots = new ConcurrentHashMap<>();
    private final Map<String, ArrayDeque<Long>> floodWindows = new ConcurrentHashMap<>();
    private ScheduledExecutorService executor;
    private ScheduledFuture<?> pollingFuture;
    private volatile int pollIntervalSeconds = DEFAULT_POLL_INTERVAL_SECONDS;
    private PowerManager.WakeLock wakeLock;

    public static boolean isRunning() { return running; }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        createNotificationChannel();
        pollIntervalSeconds = getSharedPreferences("appmint_runtime_settings", MODE_PRIVATE)
                .getInt("poll_interval_seconds", DEFAULT_POLL_INTERVAL_SECONDS);
        if (pollIntervalSeconds < MIN_POLL_INTERVAL_SECONDS || pollIntervalSeconds > MAX_POLL_INTERVAL_SECONDS) {
            pollIntervalSeconds = DEFAULT_POLL_INTERVAL_SECONDS;
        }
        startAsForeground();
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AppMint:BotPolling");
            wakeLock.setReferenceCounted(false);
            try { wakeLock.acquire(); } catch (RuntimeException ignored) { }
        }
        executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread thread = new Thread(r, "AppMint-Bot-Polling");
            thread.setDaemon(true);
            return thread;
        });
        bots.putAll(BotCredentialVault.getEnabledAll(this));
        schedulePolling();
        updateNotification();
    }

    private void startAsForeground() {
        Notification notification = buildNotification("در حال آماده‌سازی ربات‌ها…");
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            if (bots.isEmpty()) {
                bots.putAll(BotCredentialVault.getEnabledAll(this));
                updateNotification();
            }
            if (bots.isEmpty()) {
                stopSelf(startId);
                return START_NOT_STICKY;
            }
            return START_STICKY;
        }
        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            String raw = intent.getStringExtra(EXTRA_BOT);
            try {
                JSONObject bot = new JSONObject(raw == null ? "{}" : raw);
                String id = bot.optString("id", "");
                String token = bot.optString("token", "");
                if (id.isEmpty() || token.isEmpty() || token.length() > 4096) {
                    throw new IllegalArgumentException("شناسه یا توکن ربات معتبر نیست.");
                }
                bot.put("enabled", true);
                BotCredentialVault.put(this, id, bot);
                bots.put(id, bot);
                updateNotification();
            } catch (Exception error) {
                android.util.Log.e("AppMintService", "Could not save bot", error);
                updateNotification();
            }
        } else if (ACTION_STOP.equals(action)) {
            String id = intent.getStringExtra(EXTRA_BOT_ID);
            if (id != null) {
                bots.remove(id);
                BotCredentialVault.setEnabled(this, id, false);
            }
            stopIfEmpty(startId);
        } else if (ACTION_REMOVE_BOT.equals(action)) {
            String id = intent.getStringExtra(EXTRA_BOT_ID);
            if (id != null) { bots.remove(id); BotCredentialVault.remove(this, id); }
            stopIfEmpty(startId);
        } else if (ACTION_UPDATE_POLL_INTERVAL.equals(action)) {
            int requested = intent.getIntExtra(EXTRA_POLL_INTERVAL_SECONDS, DEFAULT_POLL_INTERVAL_SECONDS);
            if (requested >= MIN_POLL_INTERVAL_SECONDS && requested <= MAX_POLL_INTERVAL_SECONDS) {
                pollIntervalSeconds = requested;
                getSharedPreferences("appmint_runtime_settings", MODE_PRIVATE)
                        .edit().putInt("poll_interval_seconds", requested).apply();
                reschedulePolling();
                updateNotification();
            }
        } else if (ACTION_UPDATE_CONFIG.equals(action)) {
            String id = intent.getStringExtra(EXTRA_BOT_ID);
            String rawConfig = intent.getStringExtra("bot_config");
            JSONObject bot = id == null ? null : bots.get(id);
            if (bot != null && rawConfig != null) {
                try {
                    bot.put("config", new JSONObject(rawConfig));
                    BotCredentialVault.put(this, id, bot);
                } catch (Exception error) {
                    android.util.Log.w("AppMintService", "Could not update bot config", error);
                }
            }
            updateNotification();
        } else if (ACTION_STOP_ALL.equals(action)) {
            bots.clear();
            BotCredentialVault.clear(this);
            stopSelf(startId);
        }
        return START_STICKY;
    }

    private void schedulePolling() {
        if (executor == null || executor.isShutdown()) return;
        pollingFuture = executor.scheduleWithFixedDelay(
                this::pollAllBotsSafely, 0, pollIntervalSeconds, TimeUnit.SECONDS);
    }

    private void reschedulePolling() {
        if (executor == null || executor.isShutdown()) return;
        if (pollingFuture != null) pollingFuture.cancel(false);
        schedulePolling();
    }

    private void pollAllBotsSafely() {
        for (String id : new ArrayList<>(bots.keySet())) {
            JSONObject bot = bots.get(id);
            if (bot == null) continue;
            try {
                pollBot(id, bot);
                if (bot.has("lastError")) {
                    bot.remove("lastError");
                    BotCredentialVault.put(this, id, bot);
                }
            } catch (Exception error) {
                String message = error.getMessage() == null ? "خطای ارتباط با روبیکا" : error.getMessage();
                android.util.Log.w("AppMintService", "Polling failed for " + id + ": " + message);
                if (!message.equals(bot.optString("lastError", ""))) {
                    try { bot.put("lastError", message); BotCredentialVault.put(this, id, bot); }
                    catch (Exception ignored) { }
                }
            }
        }
        updateNotification();
    }

    private void pollBot(String id, JSONObject bot) throws Exception {
        String token = bot.optString("token", "");
        if (token.isEmpty()) return;
        JSONObject payload = new JSONObject();
        payload.put("limit", 50);
        String offset = bot.optString("offsetId", "");
        if (!offset.isEmpty()) payload.put("offset_id", offset);
        JSONObject result = unwrap(api(token, "getUpdates", payload));
        JSONArray updates = result.optJSONArray("updates");
        String nextOffset = result.optString("next_offset_id", result.optString("nextOffsetId", ""));
        boolean changed = false;
        if (!nextOffset.isEmpty() && !nextOffset.equals(bot.optString("offsetId", ""))) {
            bot.put("offsetId", nextOffset);
            changed = true;
        }
        if (updates != null && updates.length() > 0) {
            bot.put("totalUpdates", bot.optInt("totalUpdates", 0) + updates.length());
            changed = true;
            for (int i = 0; i < updates.length(); i++) {
                JSONObject update = updates.optJSONObject(i);
                if (update == null) continue;
                try { processUpdate(bot, update); }
                catch (Exception error) { android.util.Log.w("AppMintService", "Update processing failed", error); }
            }
        }
        if (changed) BotCredentialVault.put(this, id, bot);
    }

    private void processUpdate(JSONObject bot, JSONObject update) throws Exception {
        JSONObject message = update.optJSONObject("new_message");
        String chatId = update.optString("chat_id", "");
        if (chatId.isEmpty() && message != null) chatId = message.optString("chat_id", "");
        if (chatId.isEmpty()) return;

        String template = bot.optString("templateId", "");
        String botName = bot.optString("name", "AppMint");
        JSONObject config = bot.optJSONObject("config");
        if (config == null) config = new JSONObject();
        String helpText = config.optString("welcomeMessage", "سلام! به ربات " + botName + " خوش اومدی 🌱\nبرای راهنما /help رو بفرست.");

        if ("StartedBot".equalsIgnoreCase(update.optString("type", ""))) {
            if ("auto_reply".equals(template) || "shop".equals(template)) sendMessage(bot, chatId, helpText, null);
            return;
        }
        if (!"NewMessage".equalsIgnoreCase(update.optString("type", "")) || message == null) return;
        if ("Bot".equalsIgnoreCase(message.optString("sender_type", ""))) return;
        String text = message.optString("text", "").trim();
        if (text.isEmpty()) return;
        String messageId = message.optString("message_id", "");
        String senderId = message.optString("sender_id", "کاربر");
        String command = text.split("\\s+", 2)[0];
        if (command.contains("@")) command = command.substring(0, command.indexOf('@'));
        if ("/myid".equalsIgnoreCase(command)) {
            sendMessage(bot, chatId,
                    "🆔 شناسه این گفتگو:\n" + chatId + "\n\n👤 شناسه کاربر:\n" + senderId
                            + "\n\nاین شناسه را فقط در تنظیمات مدیر فروشگاه وارد کن.", messageId);
            return;
        }

        if ("guardian".equals(template)) {
            boolean filterWords = config.optBoolean("filterWords", true);
            boolean filterLinks = config.optBoolean("filterLinks", true);
            String lower = text.toLowerCase();
            String blocked = config.optString("blockedWords", "اسپم\nتبلیغ ناخواسته");
            boolean wordHit = false;
            for (String word : blocked.split("\\r?\\n")) {
                String candidate = word.trim().toLowerCase();
                if (filterWords && !candidate.isEmpty() && lower.contains(candidate)) { wordHit = true; break; }
            }
            boolean linkHit = filterLinks && (lower.contains("https://") || lower.contains("http://") || lower.contains("www."));
            boolean floodHit = config.optBoolean("filterFlood", true)
                    && isFlooding(chatId, senderId, config.optInt("maxMessagesPer10s", 6));
            if ((wordHit || linkHit || floodHit) && !messageId.isEmpty()) {
                JSONObject delete = new JSONObject(); delete.put("chat_id", chatId); delete.put("message_id", messageId);
                api(bot.optString("token"), "deleteMessage", delete);
                bot.put("totalActions", bot.optInt("totalActions", 0) + 1);
                return;
            }
            if ("/rules".equalsIgnoreCase(text)) {
                sendMessage(bot, chatId, config.optString("rulesText", "قوانین گروه: احترام، پرهیز از اسپم و رعایت موضوع گروه 🌿"), messageId);
            }
            return;
        }

        if ("/start".equalsIgnoreCase(text) || "/help".equalsIgnoreCase(text)) {
            sendMessage(bot, chatId, helpText, messageId);
            return;
        }

        if ("auto_reply".equals(template)) {
            String rules = config.optString("replyRules", "سلام=سلام! خوش اومدی 🌸\nقیمت=برای اطلاع از قیمت، نام محصول رو بفرست.");
            String normalizedText = text.toLowerCase();
            for (String line : rules.split("\\r?\\n")) {
                int split = line.indexOf('=');
                if (split <= 0) continue;
                String keyword = line.substring(0, split).trim();
                String reply = line.substring(split + 1).trim();
                if (!keyword.isEmpty() && !reply.isEmpty() && normalizedText.contains(keyword.toLowerCase())) {
                    sendMessage(bot, chatId, reply, messageId);
                    return;
                }
            }
            String fallback = config.optString("fallbackReply", "");
            if (!fallback.isEmpty()) sendMessage(bot, chatId, fallback, messageId);
            return;
        }

        if ("shop".equals(template)) {
            if ("/products".equalsIgnoreCase(text) || "محصولات".equals(text)) {
                sendMessage(bot, chatId, config.optString("shopProducts", "برای دریافت فهرست محصولات با پشتیبانی تماس بگیر."), messageId);
                return;
            }
            if (text.startsWith("/order") || text.startsWith("سفارش ")) {
                String order = text.replaceFirst("^/order\\s*", "").replaceFirst("^سفارش\\s*", "").trim();
                if (order.isEmpty()) {
                    sendMessage(bot, chatId, "برای ثبت سفارش بنویس:\n/order نام کالا - تعداد", messageId);
                    return;
                }
                sendMessage(bot, chatId, "✅ درخواست سفارش شما ثبت شد.\nجزئیات: " + order + "\nپشتیبانی به‌زودی پیگیری می‌کند.", messageId);
                String adminChat = config.optString("adminChatId", "").trim();
                if (!adminChat.isEmpty()) {
                    sendMessage(bot, adminChat, "🛍 سفارش جدید از " + senderId + "\nچت مشتری: " + chatId + "\nجزئیات: " + order, null);
                }
                return;
            }
            String rules = config.optString("replyRules", "ارسال=زمان ارسال بعد از تأیید سفارش اعلام می‌شود.\nپشتیبانی=پیام شما ثبت شد.");
            String normalizedText = text.toLowerCase();
            for (String line : rules.split("\\r?\\n")) {
                int split = line.indexOf('=');
                if (split <= 0) continue;
                String keyword = line.substring(0, split).trim();
                String reply = line.substring(split + 1).trim();
                if (!keyword.isEmpty() && !reply.isEmpty() && normalizedText.contains(keyword.toLowerCase())) {
                    sendMessage(bot, chatId, reply, messageId);
                    return;
                }
            }
            return;
        }

        if ("quiz".equals(template)) {
            if ("/quiz".equalsIgnoreCase(text)) {
                sendMessage(bot, chatId, "🧠 چالش مسابقه\n" + config.optString("quizQuestion", "پایتخت ایران کدام شهر است؟") + "\n\nجوابت رو بفرست!", messageId);
                return;
            }
            if ("/score".equalsIgnoreCase(text)) {
                int score = getScore(bot.optString("id"), chatId, senderId);
                sendMessage(bot, chatId, "🏆 امتیاز تو: " + score + "\nبرای دیدن سؤال جدید /quiz رو بفرست.", messageId);
                return;
            }
            if ("/leaderboard".equalsIgnoreCase(text)) {
                sendMessage(bot, chatId, getLeaderboard(bot.optString("id"), chatId), messageId);
                return;
            }
            String answer = config.optString("quizAnswer", "تهران").trim();
            if (!answer.isEmpty() && normalize(text).equals(normalize(answer))) {
                int score = addScore(bot.optString("id"), chatId, senderId);
                sendMessage(bot, chatId, "🎉 آفرین! پاسخ درست بود.\nامتیاز تو: " + score, messageId);
            }
        }
    }

    private boolean isFlooding(String chatId, String userId, int configuredLimit) {
        int limit = Math.max(3, Math.min(configuredLimit, 30));
        long now = System.currentTimeMillis();
        String key = chatId + "|" + userId;
        ArrayDeque<Long> window = floodWindows.get(key);
        if (window == null) {
            ArrayDeque<Long> created = new ArrayDeque<>();
            ArrayDeque<Long> existing = floodWindows.putIfAbsent(key, created);
            window = existing == null ? created : existing;
        }
        synchronized (window) {
            while (!window.isEmpty() && now - window.peekFirst() > 10_000L) window.removeFirst();
            window.addLast(now);
            if (floodWindows.size() > 5000) floodWindows.clear();
            return window.size() > limit;
        }
    }

    private String getLeaderboard(String botId, String chatId) {
        String prefix = botId + "|" + chatId + "|";
        ArrayList<Map.Entry<String, ?>> scores = new ArrayList<>();
        for (Map.Entry<String, ?> entry : getSharedPreferences("appmint_quiz_scores", MODE_PRIVATE).getAll().entrySet()) {
            if (entry.getKey().startsWith(prefix) && entry.getValue() instanceof Integer) scores.add(entry);
        }
        scores.sort((left, right) -> Integer.compare((Integer) right.getValue(), (Integer) left.getValue()));
        if (scores.isEmpty()) return "🏆 هنوز امتیازی ثبت نشده است.\nبرای شروع /quiz را بفرست.";
        StringBuilder text = new StringBuilder("🏆 جدول امتیاز مسابقه\n\n");
        int count = Math.min(10, scores.size());
        for (int i = 0; i < count; i++) {
            Map.Entry<String, ?> entry = scores.get(i);
            String userId = entry.getKey().substring(prefix.length());
            text.append(i + 1).append(". ").append(userId).append(" — ").append(entry.getValue()).append(" امتیاز\n");
        }
        return text.toString();
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().replace('ي', 'ی').replace('ك', 'ک').replaceAll("\\s+", " ").toLowerCase();
    }

    private int getScore(String botId, String chatId, String userId) {
        return getSharedPreferences("appmint_quiz_scores", MODE_PRIVATE).getInt(botId + "|" + chatId + "|" + userId, 0);
    }

    private int addScore(String botId, String chatId, String userId) {
        String key = botId + "|" + chatId + "|" + userId;
        int next = getScore(botId, chatId, userId) + 1;
        getSharedPreferences("appmint_quiz_scores", MODE_PRIVATE).edit().putInt(key, next).apply();
        return next;
    }

    private void sendMessage(JSONObject bot, String chatId, String text, String replyTo) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("chat_id", chatId);
        payload.put("text", text);
        if (replyTo != null && !replyTo.isEmpty()) payload.put("reply_to_message_id", replyTo);
        api(bot.optString("token"), "sendMessage", payload);
        bot.put("totalActions", bot.optInt("totalActions", 0) + 1);
    }

    private JSONObject api(String token, String method, JSONObject payload) throws Exception {
        String encodedToken = URLEncoder.encode(token, "UTF-8").replace("+", "%20");
        HttpURLConnection connection = (HttpURLConnection) new URL(API_BASE + encodedToken + "/" + method).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(15000);
        connection.setUseCaches(false);
        connection.setDoOutput(true);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        connection.setFixedLengthStreamingMode(body.length);
        try {
            try (OutputStream output = connection.getOutputStream()) { output.write(body); output.flush(); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
            String raw = stream == null ? "{}" : readLimited(stream);
            JSONObject parsed = new JSONObject(raw);
            if (code < 200 || code >= 300) {
                String error = parsed.optString("description", parsed.optString("message", "خطای API روبیکا: HTTP " + code));
                throw new java.io.IOException(error);
            }
            String status = parsed.optString("status", "OK");
            if (!"OK".equalsIgnoreCase(status) && !"SUCCESS".equalsIgnoreCase(status)) {
                throw new java.io.IOException(parsed.optString("description", parsed.optString("message", status)));
            }
            return parsed;
        } finally { connection.disconnect(); }
    }

    private JSONObject unwrap(JSONObject raw) {
        JSONObject data = raw.optJSONObject("data");
        if (data != null) return data;
        JSONObject result = raw.optJSONObject("result");
        return result == null ? raw : result;
    }

    private String readLimited(InputStream input) throws Exception {
        try (InputStream stream = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int total = 0; int count;
            while ((count = stream.read(buffer)) != -1) {
                total += count;
                if (total > MAX_RESPONSE_BYTES) throw new java.io.IOException("پاسخ روبیکا بیش از حد بزرگ است.");
                output.write(buffer, 0, count);
            }
            return output.toString("UTF-8");
        }
    }

    private void stopIfEmpty(int startId) {
        if (bots.isEmpty()) stopSelf(startId);
        else updateNotification();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "اجرای ربات‌های AppMint", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("اعلان دائمی برای ربات‌هایی که خودت فعال کرده‌ای");
            channel.setShowBadge(false);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                .setContentTitle("AppMint · ربات‌ها فعال‌اند")
                .setContentText(text)
                .setContentIntent(pending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void updateNotification() {
        if (bots.isEmpty()) return;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID,
                buildNotification(bots.size() + " ربات در پس‌زمینه فعال‌اند · بررسی هر " + pollIntervalSeconds + " ثانیه"));
    }

    @Override
    public void onDestroy() {
        running = false;
        if (pollingFuture != null) pollingFuture.cancel(true);
        if (executor != null) executor.shutdownNow();
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (RuntimeException ignored) { }
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
