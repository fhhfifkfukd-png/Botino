'use strict';

const API_BASE = 'https://botapi.rubika.ir/v3/';
const DEFAULT_POLL_INTERVAL_SECONDS = 2;
const MIN_POLL_INTERVAL_SECONDS = 1;
const MAX_POLL_INTERVAL_SECONDS = 5;
const CONTACT_URL = 'https://rubika.ir/Mind_analyst';
const DB_NAME = 'appmint-secure-vault';
const STORE_NAME = 'keys';
const APP_DATA_KEY = 'appmint_data_v1';

const TEMPLATES = [
  {id:'guardian',name:'نگهبان هوشمند گروه',emoji:'🛡️',category:'moderation',tint:'#eeeaff',desc:'ضداسپم، فیلتر کلمات و لینک‌ها و پاسخ خودکار به قوانین گروه.',tag:'امنیت گروه',features:['حذف کلمات و لینک‌های ممنوع','تشخیص پیام‌های پشت‌سرهم','نمایش قوانین با /rules'],defaults:{filterWords:true,blockedWords:'اسپم\nتبلیغ ناخواسته\nفروش فوری',filterLinks:true,filterFlood:true,maxMessagesPer10s:6,rulesText:'📌 قوانین گروه\n۱. احترام به همه اعضا\n۲. ارسال تبلیغات ممنوع\n۳. از ارسال لینک ناشناس خودداری کنید.'}},
  {id:'auto_reply',name:'پاسخگوی هوشمند ۲۴ساعته',emoji:'💬',category:'communication',tint:'#e9f8f4',desc:'پاسخ دقیق به کلمات کلیدی، راهنمایی کاربران و رسیدگی خودکار به پرسش‌های پرتکرار.',tag:'پشتیبانی خودکار',features:['پاسخ‌گویی با کلیدواژه دلخواه','پاسخ شروع گفتگو و راهنما','پاسخ جایگزین برای پیام‌های ناشناخته'],defaults:{welcomeMessage:'سلام! خوش اومدی 🌱\nمن دستیار هوشمند این صفحه هستم.\nموضوعت رو بنویس تا راهنمایی‌ات کنم.',replyRules:'سلام=سلام! خوش اومدی 🌸\nقیمت=برای اطلاع از قیمت، نام محصول رو بفرست.\nساعت کاری=هر روز از ۹ تا ۱۸ پاسخگو هستیم.\nآدرس=برای دریافت نشانی، کلمه «موقعیت» رو بفرست.',fallbackReply:'پیامت دریافت شد 🌷 لطفاً کمی دقیق‌تر بنویس یا با پشتیبانی ارتباط بگیر.'}},
  {id:'shop',name:'دستیار فروش و سفارش',emoji:'🛍️',category:'business',tint:'#fff2e8',desc:'معرفی محصولات، دریافت سفارش و خبرکردن مدیر فروشگاه در همان لحظه.',tag:'فروش آنلاین',features:['نمایش فهرست با /products','ثبت سفارش با /order','ارسال جزئیات سفارش به مدیر'],defaults:{shopName:'فروشگاه من',welcomeMessage:'سلام به فروشگاه ما خوش اومدی 🛍️\nبرای دیدن کالاها /products رو بفرست.\nبرای ثبت سفارش: /order نام کالا - تعداد',shopProducts:'🛍 محصولات فروشگاه\n۱. محصول اول — قیمت را وارد کنید\n۲. محصول دوم — قیمت را وارد کنید\nبرای سفارش بنویس: /order نام کالا - تعداد',adminChatId:'',replyRules:'ارسال=زمان ارسال پس از تأیید سفارش اعلام می‌شود.\nپشتیبانی=پیامت ثبت شد؛ پشتیبانی به‌زودی پاسخ می‌دهد.\nمرجوعی=برای پیگیری مرجوعی، شماره سفارش را ارسال کن.'}},
  {id:'quiz',name:'مسابقه‌ساز و امتیازگیر',emoji:'🏆',category:'fun',tint:'#f5edff',desc:'چالش دانستنی‌ها، تشخیص جواب درست و ثبت امتیاز هر شرکت‌کننده.',tag:'سرگرمی تعاملی',features:['سؤال مسابقه با /quiz','ثبت امتیاز خودکار','جدول رتبه‌بندی با /leaderboard'],defaults:{quizQuestion:'پایتخت ایران کدام شهر است؟',quizAnswer:'تهران'}}
];

const state = {page:'home',bots:[],logs:[],activeBotId:null,filter:'all',search:'',vaultReady:false,key:null,runtime:new Map(),memoryTokens:new Map(),reminders:new Map(),selectedTemplate:'guardian',vaultPromise:null,pollIntervalSeconds:DEFAULT_POLL_INTERVAL_SECONDS};
const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
const digits = value => String(value).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
const nowTime = () => new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});
const todayFa = () => new Date().toLocaleDateString('fa-IR',{weekday:'long',day:'numeric',month:'long'});
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid = () => 'b_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);
const templateById = id => TEMPLATES.find(t=>t.id===id) || TEMPLATES[0];

function loadData(){
  try{
    const raw=JSON.parse(localStorage.getItem(APP_DATA_KEY)||'{}');
    const legacyMap={welcome:'auto_reply',faq:'auto_reply',announcer:'auto_reply',moderator:'guardian',poll:'quiz'};
    state.bots=Array.isArray(raw.bots)?raw.bots.map(bot=>{
      const templateId=legacyMap[bot.templateId]||bot.templateId||'guardian';
      const template=templateById(templateId);
      return {...bot,templateId,config:{...(template.defaults||{}),...(bot.config||{})}};
    }):[];
    state.logs=Array.isArray(raw.logs)?raw.logs:[];
    const savedInterval=Number(raw.pollIntervalSeconds);
    state.pollIntervalSeconds=Number.isInteger(savedInterval)&&savedInterval>=MIN_POLL_INTERVAL_SECONDS&&savedInterval<=MAX_POLL_INTERVAL_SECONDS?savedInterval:DEFAULT_POLL_INTERVAL_SECONDS;
  }catch(e){state.bots=[];state.logs=[];}
}
function saveData(){
  const safeBots=state.bots.map(({token,...bot})=>bot);
  try{localStorage.setItem(APP_DATA_KEY,JSON.stringify({bots:safeBots,logs:state.logs.slice(0,300),pollIntervalSeconds:state.pollIntervalSeconds}));}catch(e){toast('فضای ذخیره‌سازی دستگاه در دسترس نیست.','error');}
}
async function openVault(){
  if(!('indexedDB' in window)||!window.crypto?.subtle)return false;
  let db;
  try{
    db=await new Promise((resolve,reject)=>{
      const req=indexedDB.open(DB_NAME,1);
      req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(STORE_NAME))req.result.createObjectStore(STORE_NAME);};
      req.onsuccess=()=>resolve(req.result);
      req.onerror=()=>reject(req.error||new Error('باز کردن مخزن امن ناموفق بود.'));
      req.onblocked=()=>reject(new Error('مخزن امن توسط پنجره دیگری قفل شده است.'));
    });
    let storedKey=await new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE_NAME,'readonly');
      const req=tx.objectStore(STORE_NAME).get('aes-key');
      req.onsuccess=()=>resolve(req.result||null);
      req.onerror=()=>reject(req.error||new Error('خواندن کلید امن ناموفق بود.'));
      tx.onabort=()=>reject(tx.error||new Error('تراکنش خواندن کلید لغو شد.'));
    });
    if(storedKey){state.key=storedKey;state.vaultReady=true;return true;}
    // Generate the CryptoKey outside an IndexedDB transaction. Awaiting crypto inside
    // an active transaction can make the transaction inactive before store.put().
    const generatedKey=await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE_NAME,'readwrite');
      tx.objectStore(STORE_NAME).put(generatedKey,'aes-key');
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error||new Error('ذخیره کلید امن ناموفق بود.'));
      tx.onabort=()=>reject(tx.error||new Error('ذخیره کلید امن لغو شد.'));
    });
    state.key=generatedKey;state.vaultReady=true;return true;
  }catch(error){
    state.key=null;state.vaultReady=false;
    console.warn('AppMint secure vault unavailable:',error);
    return false;
  }finally{if(db)db.close();}
}
async function encryptToken(token){
  if(!state.vaultReady||!state.key)return {mode:'memory',value:null};
  try{
    const iv=crypto.getRandomValues(new Uint8Array(12));const encoded=new TextEncoder().encode(token);const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},state.key,encoded);
    return {mode:'aes-gcm',iv:Array.from(iv),value:Array.from(new Uint8Array(cipher))};
  }catch(error){state.vaultReady=false;state.key=null;console.warn('AppMint token encryption failed:',error);return {mode:'memory',value:null};}
}
async function decryptToken(bot){
  if(state.memoryTokens.has(bot.id))return state.memoryTokens.get(bot.id);
  if(bot.tokenVault?.mode==='memory')return null;
  if(!state.vaultReady||!state.key||!bot.tokenVault)return null;
  try{const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:new Uint8Array(bot.tokenVault.iv)},state.key,new Uint8Array(bot.tokenVault.value));return new TextDecoder().decode(plain);}catch(e){return null;}
}
function toast(message,type='info'){
  const el=document.createElement('div');el.className='toast '+type;el.textContent=message;$('#toastStack').appendChild(el);setTimeout(()=>el.remove(),3600);
}
function addLog(botId,type,title,message){
  const bot=state.bots.find(b=>b.id===botId);state.logs.unshift({id:uid(),botId,type,title,message,time:Date.now(),botName:bot?.name||'AppMint'});state.logs=state.logs.slice(0,300);saveData();renderActivity();renderHome();if(state.activeBotId===botId)renderBotDetail();
}
function showPage(page){
  state.page=page;$$('.page').forEach(p=>{const isActive=p.dataset.page===page;p.classList.toggle('active',isActive);p.classList.toggle('hidden',!isActive);});$$('.nav-item[data-nav]').forEach(b=>b.classList.toggle('active',b.dataset.nav===page));window.scrollTo({top:0,behavior:'smooth'});
  if(page==='home')renderHome();if(page==='templates')renderTemplates();if(page==='mybots')renderMyBots();if(page==='activity')renderActivity();if(page==='settings')renderSettings();if(page==='bot-detail')renderBotDetail();
}
function getPollIntervalMs(){return state.pollIntervalSeconds*1000;}
function renderSettings(){
  const select=$('#pollIntervalSelect');
  if(select)select.value=String(state.pollIntervalSeconds);
  const summary=$('#pollIntervalSummary');
  if(summary)summary.textContent=digits(state.pollIntervalSeconds)+' ثانیه';
}
async function applyPollInterval(value){
  const seconds=Number(value);
  if(!Number.isInteger(seconds)||seconds<MIN_POLL_INTERVAL_SECONDS||seconds>MAX_POLL_INTERVAL_SECONDS){toast('فاصله پولینگ باید بین ۱ تا ۵ ثانیه باشد.','error');renderSettings();return;}
  state.pollIntervalSeconds=seconds;saveData();renderSettings();
  if(window.AppMint?.setPollingInterval){
    try{await window.AppMint.setPollingInterval(String(seconds));toast('فاصله بررسی پیام‌ها روی '+digits(seconds)+' ثانیه تنظیم شد.','success');}
    catch(error){toast('تنظیم روی دستگاه ذخیره شد، اما همگام‌سازی سرویس ناموفق بود: '+(error.message||''),'error');}
  }else{toast('فاصله پولینگ ذخیره شد؛ در اجرای اندروید به سرویس منتقل می‌شود.','success');}
}
function renderHome(){
  $('#todayLabel').textContent=todayFa();$('#statTotal').textContent=digits(state.bots.length);$('#statRunning').textContent=digits(state.bots.filter(b=>state.runtime.has(b.id)).length);$('#statEvents').textContent=digits(state.logs.filter(l=>new Date(l.time).toDateString()===new Date().toDateString()).length);
  $('#featuredTemplates').innerHTML=TEMPLATES.slice(0,4).map(t=>`<article class="featured-card" data-template="${t.id}" style="--tint:${t.tint}"><span class="template-emoji">${t.emoji}</span><div><b>${t.name}</b><small>${t.desc}</small></div></article>`).join('');
  const recent=state.bots.slice(0,3);$('#homeBotList').innerHTML=recent.length?recent.map(bot=>compactBotHTML(bot)).join(''):'<div class="empty-inline">هنوز رباتی نساختی؛ از دکمه ساخت ربات شروع کن.</div>';
}
function compactBotHTML(bot){const t=templateById(bot.templateId);const running=state.runtime.has(bot.id);return `<div class="compact-row" data-bot="${bot.id}"><span class="template-emoji" style="--tint:${t.tint}">${t.emoji}</span><div><b>${escapeHtml(bot.name)}</b><small>${t.name}</small></div><span class="status-mini" style="${running?'':'background:#f2f0f6;color:#999'}">${running?'فعال':'متوقف'}</span></div>`;}
function renderTemplates(){
  const term=state.search.trim().toLocaleLowerCase('fa');const list=TEMPLATES.filter(t=>(state.filter==='all'||t.category===state.filter)&&(!term||(t.name+' '+t.desc+' '+t.tag).toLocaleLowerCase('fa').includes(term)));
  $('#allTemplates').innerHTML=list.map(t=>`<article class="template-card" data-template="${t.id}" style="--tint:${t.tint}"><span class="template-emoji">${t.emoji}</span><b>${t.name}</b><p>${t.desc}</p><div class="template-meta">${t.features.length} قابلیت آماده · ${t.tag}</div><span class="card-arrow">←</span></article>`).join('')||'<div class="empty-inline">قالبی با این جست‌وجو پیدا نشد.</div>';
}
function renderMyBots(){
  const running=state.bots.filter(b=>state.runtime.has(b.id)).length;$('#myBotSummary').innerHTML=`<div><b>${digits(state.bots.length)} ربات</b><small>ذخیره‌شده روی همین دستگاه</small></div><div class="summary-right"><b>${digits(running)} فعال</b><small>از ${digits(state.bots.length)} ربات</small></div>`;
  $('#myBotList').innerHTML=state.bots.map(bot=>botCardHTML(bot)).join('');$('#emptyBots').classList.toggle('hidden',state.bots.length>0);
}
function botCardHTML(bot){const t=templateById(bot.templateId);const run=state.runtime.has(bot.id);const err=bot.lastError;return `<div class="bot-card" data-bot="${bot.id}"><span class="template-emoji" style="--tint:${t.tint}">${t.emoji}</span><div class="bot-card-main"><b>${escapeHtml(bot.name)}</b><small>${t.name} · ${escapeHtml(bot.username||'ربات متصل')}</small></div><div class="bot-card-end"><span class="status-pill ${run?'running':err?'error':''}">${run?'در حال اجرا':err?'نیازمند بررسی':'متوقف'}</span><span class="chevron">‹</span></div></div>`;}
function renderActivity(){
  $('#activityCount').textContent=digits(state.logs.length);$('#activityList').innerHTML=state.logs.slice(0,100).map(l=>`<div class="activity-item ${l.type==='error'?'error':l.type==='success'?'success':''}"><span class="activity-dot">${l.type==='error'?'!':l.type==='success'?'✓':'•'}</span><div><b>${escapeHtml(l.title)}</b><p>${escapeHtml(l.message)} <span class="muted">· ${escapeHtml(l.botName)}</span></p></div><time>${digits(new Date(l.time).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'}))}</time></div>`).join('');$('#emptyActivity').classList.toggle('hidden',state.logs.length>0);
}
function openModal(html){$('#modalContent').innerHTML=html;$('#modalBackdrop').classList.remove('hidden');document.body.style.overflow='hidden';}
function closeModal(){$('#modalBackdrop').classList.add('hidden');document.body.style.overflow='';}
function openCreateModal(templateId){
  state.selectedTemplate=templateId||'guardian';
  const templateOptions=TEMPLATES.map(t=>`<button class="picker-option ${t.id===state.selectedTemplate?'selected':''}" data-pick-template="${t.id}"><span class="template-emoji" style="--tint:${t.tint}">${t.emoji}</span><span><b>${t.name}</b><small>${t.tag}</small></span></button>`).join('');
  openModal(`<div class="section-kicker">مرحله ۱ از ۲ · انتخاب قالب</div><h2 class="modal-title" id="modalTitle">ربات جدید بساز</h2><p class="modal-subtitle">یک ربات آماده انتخاب کن. بعد از اتصال توکن، تنظیمات اختصاصی آن را تغییر می‌دهی.</p><div class="template-picker" id="templatePicker">${templateOptions}</div><label class="field"><span>اسم دلخواه ربات در AppMint</span><input id="newBotName" maxlength="40" placeholder="مثلاً نگهبان گروه من" value="${escapeHtml(templateById(state.selectedTemplate).name)}"></label><div class="modal-actions"><button class="primary-button" id="continueCreate">ادامه و اتصال توکن ←</button></div>`);
}
function showTokenStep(){
  const t=templateById(state.selectedTemplate);const name=$('#newBotName')?.value.trim()||t.name;
  openModal(`<div class="section-kicker">مرحله ۲ از ۲ · اتصال روبیکا</div><h2 class="modal-title" id="modalTitle">اتصال «${escapeHtml(name)}»</h2><p class="modal-subtitle">توکن را از BotFather روبیکا دریافت کن. AppMint با متد getMe اتصال را بررسی می‌کند.</p><label class="field"><span>توکن ربات</span><div class="token-field-row"><input id="botTokenInput" type="password" autocomplete="off" spellcheck="false" placeholder="توکن ربات را اینجا وارد کن"><button class="token-visibility" type="button" id="toggleTokenVisibility">نمایش</button></div></label><label class="checkline"><input type="checkbox" id="tokenConfirm"> <span>می‌دانم این توکن مانند رمز عبور ربات است و فقط توکن رباتی را وارد می‌کنم که مالک یا مجاز به مدیریت آن هستم.</span></label><div class="token-note">🔒 توکن در گزارش‌ها نمایش داده نمی‌شود. در نسخه اندروید، هنگام روشن‌کردن اجرای پس‌زمینه، توکن با Android Keystore رمزنگاری و در حافظه خصوصی برنامه نگهداری می‌شود.</div><div id="connectError" class="warning-box hidden"></div><div class="modal-actions"><button class="outline-button" id="backToTemplates">بازگشت</button><button class="primary-button" id="verifyAndCreate">✓ بررسی و ساخت ربات</button></div>`);
  $('#verifyAndCreate').addEventListener('click',()=>createBotFromToken(name));$('#backToTemplates').addEventListener('click',()=>openCreateModal(state.selectedTemplate));
  $('#toggleTokenVisibility').addEventListener('click',()=>{const input=$('#botTokenInput');const reveal=input.type==='password';input.type=reveal?'text':'password';$('#toggleTokenVisibility').textContent=reveal?'مخفی':'نمایش';});
}
async function rubikaRequest(token,method,payload={}){
  if(window.AppMint && typeof window.AppMint.rubikaRequest==='function'){
    const result=await window.AppMint.rubikaRequest({token,method,payload});return normalizeResponse(result);
  }
  let response;const controller=typeof AbortController!=='undefined'?new AbortController():null;const timeout=controller?setTimeout(()=>controller.abort(),15000):null;
  try{response=await fetch(API_BASE+encodeURIComponent(token)+'/'+method,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),cache:'no-store',signal:controller?.signal});}
  catch(error){if(error?.name==='AbortError')throw new Error('درخواست از روبیکا پس از ۱۵ ثانیه پاسخی نگرفت؛ اینترنت یا وضعیت API را بررسی کن.');throw new Error('ارتباط مستقیم WebView با API روبیکا برقرار نشد. احتمالاً دسترسی شبکه یا محدودیت CORS وجود دارد؛ AppMint باید پل ارتباطی بومی (Native) را فعال کند.');}
  finally{if(timeout)clearTimeout(timeout);}
  const text=await response.text();let data;try{data=JSON.parse(text);}catch(e){throw new Error('پاسخ روبیکا قابل خواندن نبود ('+response.status+').');}
  if(!response.ok)throw new Error(data?.description||data?.message||'خطای ارتباط با سرور روبیکا: '+response.status);
  return normalizeResponse(data);
}
function normalizeResponse(raw){
  if(typeof raw==='string'){try{raw=JSON.parse(raw);}catch(e){throw new Error('پاسخ پل بومی JSON معتبر نیست.');}}
  if(raw?.status && !['OK','SUCCESS'].includes(String(raw.status).toUpperCase())){throw new Error(raw.description||raw.message||raw.data?.description||raw.error||String(raw.status));}
  return raw?.data??raw?.result??raw;
}
async function createBotFromToken(name){
  const input=$('#botTokenInput');const token=input.value.trim();const confirm=$('#tokenConfirm').checked;const err=$('#connectError');
  if(!token){err.textContent='لطفاً توکن ربات را وارد کن.';err.classList.remove('hidden');return;}if(!confirm){err.textContent='برای ادامه، تأیید مالکیت یا مجوز مدیریت توکن لازم است.';err.classList.remove('hidden');return;}
  const button=$('#verifyAndCreate');button.disabled=true;button.textContent='در حال بررسی اتصال…';err.classList.add('hidden');
  try{
    const data=await rubikaRequest(token,'getMe',{});const botInfo=data?.bot||data?.result?.bot||data?.data?.bot||data;
    if(!botInfo?.bot_id)throw new Error('پاسخ getMe شناسه معتبر ربات ندارد؛ توکن یا پاسخ API را بررسی کن.');
    const template=templateById(state.selectedTemplate);
    if(state.vaultPromise)await state.vaultPromise;
    const tokenVault=await encryptToken(token);const bot={id:uid(),templateId:template.id,name:name||template.name,username:botInfo?.username||'',rubikaTitle:botInfo?.bot_title||'',rubikaId:botInfo.bot_id,createdAt:Date.now(),config:{...template.defaults},tokenVault,offsetId:'',lastError:'',totalUpdates:0,totalActions:0};
    state.bots.unshift(bot);if(tokenVault.mode==='memory')state.memoryTokens.set(bot.id,token);saveData();addLog(bot.id,'success','اتصال موفق',`ربات ${bot.name} با متد getMe شناسایی شد.`);closeModal();showPage('bot-detail');state.activeBotId=bot.id;renderBotDetail();toast(tokenVault.mode==='memory'?'ربات اضافه شد؛ این دستگاه ذخیره امن توکن را پشتیبانی نکرد و پس از بستن برنامه باید دوباره توکن را وارد کنی.':'ربات با موفقیت اضافه و توکن رمزنگاری شد.','success');
  }catch(e){err.textContent='اتصال برقرار نشد: '+(e.message||'خطای نامشخص')+' — ممکن است توکن اشتباه باشد یا WebView اجازه ارتباط مستقیم با API را ندهد.';err.classList.remove('hidden');button.disabled=false;button.textContent='✓ بررسی و ساخت ربات';}
}
function openReconnectModal(){
  const bot=getActiveBot();if(!bot)return;
  openModal(`<div class="section-kicker">اتصال دوباره به روبیکا</div><h2 class="modal-title" id="modalTitle">اتصال مجدد «${escapeHtml(bot.name)}»</h2><p class="modal-subtitle">توکن جدید یا همان توکن قبلی را وارد کن. قبل از ذخیره، با متد getMe بررسی می‌شود.</p><label class="field"><span>توکن ربات</span><div class="token-field-row"><input id="reconnectTokenInput" type="password" autocomplete="off" spellcheck="false" placeholder="توکن ربات را وارد کن"><button class="token-visibility" type="button" id="toggleReconnectVisibility">نمایش</button></div></label><div id="reconnectError" class="warning-box hidden"></div><div class="modal-actions"><button class="outline-button" id="cancelReconnect">انصراف</button><button class="primary-button" id="verifyReconnect">بررسی و ذخیره</button></div>`);
  $('#cancelReconnect').onclick=closeModal;
  $('#toggleReconnectVisibility').onclick=()=>{const input=$('#reconnectTokenInput');const reveal=input.type==='password';input.type=reveal?'text':'password';$('#toggleReconnectVisibility').textContent=reveal?'مخفی':'نمایش';};
  $('#verifyReconnect').onclick=async()=>{
    const token=$('#reconnectTokenInput').value.trim();const error=$('#reconnectError');const button=$('#verifyReconnect');
    if(!token){error.textContent='توکن را وارد کن.';error.classList.remove('hidden');return;}
    button.disabled=true;button.textContent='در حال بررسی…';error.classList.add('hidden');
    try{
      const data=await rubikaRequest(token,'getMe',{});const info=data?.bot||data?.result?.bot||data?.data?.bot||data;
      if(!info?.bot_id)throw new Error('شناسه ربات در پاسخ getMe پیدا نشد.');
      if(bot.rubikaId&&String(info.bot_id)!==String(bot.rubikaId))throw new Error('این توکن متعلق به ربات دیگری است. برای جلوگیری از جابه‌جایی اشتباه، توکن قبلی این ربات را وارد کن.');
      if(state.vaultPromise)await state.vaultPromise;
      bot.tokenVault=await encryptToken(token);if(bot.tokenVault.mode==='memory')state.memoryTokens.set(bot.id,token);else state.memoryTokens.delete(bot.id);
      bot.username=info.username||bot.username||'';bot.rubikaTitle=info.bot_title||bot.rubikaTitle||'';bot.rubikaId=info.bot_id;bot.lastError='';saveData();if(state.runtime.get(bot.id)?.native&&window.AppMint?.startBackgroundBot){await window.AppMint.startBackgroundBot({id:bot.id,name:bot.name,templateId:bot.templateId,token,config:bot.config||{},offsetId:bot.offsetId||''});}addLog(bot.id,'success','اتصال مجدد موفق','توکن با متد getMe تأیید و ذخیره شد.');closeModal();renderBotDetail();toast('اتصال مجدد انجام شد.','success');
    }catch(err){error.textContent='اتصال ناموفق بود: '+(err.message||'خطای نامشخص');error.classList.remove('hidden');button.disabled=false;button.textContent='بررسی و ذخیره';}
  };
}
function getActiveBot(){return state.bots.find(b=>b.id===state.activeBotId);}
function openBot(id){state.activeBotId=id;showPage('bot-detail');}
function renderBotDetail(){
  const bot=getActiveBot();if(!bot)return;const t=templateById(bot.templateId);const running=state.runtime.has(bot.id);$('#detailTitle').textContent=bot.name;$('#detailAvatar').textContent=t.emoji;
  $('#detailStatusCard').innerHTML=`<div><b>${escapeHtml(bot.name)}</b><small>${t.name} · ${escapeHtml(bot.username||'اتصال محلی')}</small></div><span class="status-pill ${running?'running':bot.lastError?'error':''}">${running?'در حال اجرا':bot.lastError?'خطا در اجرا':'متوقف'}</span>`;
  $('#toggleBotRun').textContent=running?'■ توقف ربات':'▶ شروع ربات';$('#toggleBotRun').className=running?'outline-button':'primary-button';
  const logs=state.logs.filter(l=>l.botId===bot.id);$('#detail-overview').innerHTML=`<div class="panel-card"><h3>عملکرد ربات</h3><div class="metric-grid"><div class="metric-box"><b>${digits(bot.totalUpdates||0)}</b><small>آپدیت پردازش‌شده</small></div><div class="metric-box"><b>${digits(bot.totalActions||0)}</b><small>اقدام انجام‌شده</small></div></div><p>ربات با سرویس Foreground اندروید و اعلان دائمی اجرا می‌شود؛ پس از بستن صفحه نیز تا وقتی سیستم‌عامل سرویس را متوقف نکند فعال می‌ماند.</p></div><div class="panel-card"><h3>قابلیت‌های این قالب</h3>${t.features.map(f=>`<div class="toggle-row"><span>${f}</span><span class="secure-pill">آماده</span></div>`).join('')}</div><div class="panel-card"><h3>آخرین وضعیت</h3><p>${bot.lastError?escapeHtml(bot.lastError):running?'سرویس بومی اندروید در حال دریافت پیام‌هاست؛ حتی با بسته‌شدن صفحه ادامه می‌دهد.':'ربات در حال حاضر متوقف است.'}</p><p>آخرین گزارش: ${logs[0]?digits(new Date(logs[0].time).toLocaleString('fa-IR')):'هنوز گزارشی ثبت نشده'}</p></div>`;
  $('#detail-config').innerHTML=renderConfigForm(bot,t);
  $('#detail-tools').innerHTML=renderTools(bot,t);
  $('#detail-logs').innerHTML=logs.slice(0,30).map(l=>`<div class="mini-log"><span>${escapeHtml(l.title)} — ${escapeHtml(l.message)}</span><small>${digits(new Date(l.time).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'}))}</small></div>`).join('')||'<div class="empty-inline">گزارشی برای این ربات وجود ندارد.</div>';
}
function renderConfigForm(bot,t){
  const c=bot.config||{};let fields='';
  const addText=(key,label,placeholder='')=>{fields+=`<label class="field"><span>${label}</span><textarea data-config="${key}" placeholder="${escapeHtml(placeholder)}">${escapeHtml(c[key]||'')}</textarea></label>`;};
  const addInput=(key,label,placeholder='')=>{fields+=`<label class="field"><span>${label}</span><input data-config="${key}" value="${escapeHtml(c[key]||'')}" placeholder="${escapeHtml(placeholder)}"></label>`;};
  const addToggle=(key,label,defaultVal=false)=>{fields+=`<div class="toggle-row"><span>${label}</span><input class="toggle" type="checkbox" data-config-toggle="${key}" ${(c[key]??defaultVal)?'checked':''}></div>`;};
  if(t.id==='guardian'){
    addToggle('filterWords','حذف پیام‌های دارای کلمات ممنوع',true);
    addText('blockedWords','فهرست کلمات ممنوع','هر کلمه در یک خط');
    addToggle('filterLinks','حذف پیام‌های دارای لینک',true);
    addToggle('filterFlood','تشخیص پیام‌های پشت‌سرهم',true);
    addInput('maxMessagesPer10s','حد مجاز پیام در ۱۰ ثانیه','۶');
    addText('rulesText','متن قوانین گروه','قوانین را برای دستور /rules بنویس');
    fields+='<div class="warning-box">برای حذف پیام‌ها، ربات باید در گروه ادمین و دارای مجوز حذف پیام باشد. محدودیت ضدسیل بین ۳ تا ۳۰ پیام در هر ۱۰ ثانیه تنظیم می‌شود.</div>';
  }
  if(t.id==='auto_reply'){
    addText('welcomeMessage','پیام شروع و راهنمای /start','متن خوشامدگویی');
    addText('replyRules','قوانین پاسخ خودکار','هر خط به شکل کلمه=پاسخ');
    addText('fallbackReply','پاسخ برای پیام‌های ناشناخته','');
  }
  if(t.id==='shop'){
    addInput('shopName','نام فروشگاه','فروشگاه من');
    addText('welcomeMessage','پیام خوشامدگویی','');
    addText('shopProducts','فهرست محصولات برای دستور /products','نام محصول و قیمت هر کدام در یک خط');
    addInput('adminChatId','شناسه چت مدیر برای اعلان سفارش','chat_id مدیر یا پشتیبانی');
    addText('replyRules','پاسخ‌های آماده فروشگاه','هر خط به شکل کلمه=پاسخ');
    fields+='<div class="warning-box">مدیر ابتدا در گفت‌وگوی خصوصی با ربات /myid را بفرستد؛ شناسه همان گفت‌وگو را اینجا وارد کند تا اعلان سفارش دریافت کند.</div>';
  }
  if(t.id==='quiz'){
    addText('quizQuestion','سؤال مسابقه','سؤال را بنویس');
    addInput('quizAnswer','پاسخ صحیح','جواب دقیق');
    fields+='<div class="secure-pill">دستورها: /quiz سؤال · /score امتیاز · /leaderboard رتبه‌بندی</div>';
  }
  return `<div class="panel-card"><h3>تنظیمات اختصاصی ${t.name}</h3>${fields||'<p>تنظیمات دیگری تعریف نشده است.</p>'}<button class="primary-button" id="saveBotConfig">ذخیره و همگام‌سازی</button></div><div class="panel-card"><h3>اجرای پس‌زمینه</h3><div class="toggle-row"><span>دریافت پیام حتی بعد از بستن صفحه</span><span class="secure-pill">سرویس اندروید</span></div><div class="toggle-row"><span>فاصله بررسی پیام‌ها</span><span class="secure-pill">${digits(state.pollIntervalSeconds)} ثانیه · از تنظیمات</span></div><p class="muted">سرویس با اعلان دائمی و مصرف باتری بیشتر اجرا می‌شود. محدودیت‌های سازنده گوشی یا توقف اجباری اندروید ممکن است آن را متوقف کند.</p></div>`;
}
function renderTools(bot,t){
  let html=`<div class="panel-card"><h3>ارسال پیام از پنل</h3><label class="field"><span>شناسه چت (chat_id)</span><input id="toolChatId" placeholder="شناسه چت روبیکا"></label><label class="field"><span>متن پیام</span><textarea id="toolMessage" placeholder="متن پیام برای ارسال…"></textarea></label><button class="primary-button" id="sendPanelMessage">ارسال پیام</button></div>`;
  if(t.id==='guardian')html+=`<div class="panel-card"><h3>ابزار مدیریت گروه</h3><label class="field"><span>شناسه چت</span><input id="modChatId" placeholder="chat_id"></label><label class="field"><span>شناسه پیام برای حذف</span><input id="modMessageId" placeholder="message_id"></label><button class="outline-button" id="deleteTargetMessage">حذف پیام مشخص</button><p>عملیات حذف پیام به ادمین‌بودن ربات و مجوز حذف پیام در گروه نیاز دارد.</p></div>`;
  if(t.id==='shop')html+=`<div class="panel-card"><h3>راهنمای سفارش</h3><p>کاربر با <b>/products</b> فهرست محصولات را می‌بیند و با <b>/order نام کالا - تعداد</b> سفارش می‌فرستد. مدیر ابتدا در گفت‌وگوی خصوصی با ربات دستور <b>/myid</b> را بفرستد؛ شناسه همان گفت‌وگوی خصوصی را در تنظیمات فروشگاه وارد کند تا اعلان سفارش را دریافت کند.</p></div>`;
  if(t.id==='quiz')html+=`<div class="panel-card"><h3>شروع مسابقه در یک گروه</h3><label class="field"><span>شناسه چت</span><input id="quizChatId" placeholder="chat_id"></label><button class="primary-button" id="sendQuizQuestion">ارسال سؤال مسابقه</button><p>اعضا با /score امتیاز خودشان و با /leaderboard ده نفر برتر همین گفتگو را می‌بینند.</p></div>`;
  const commands={guardian:'/rules — نمایش قوانین گروه\n/myid — نمایش شناسه گفتگو',auto_reply:'/start یا /help — راهنمای ربات\n/myid — نمایش شناسه گفتگو',shop:'/products — فهرست کالاها\n/order نام کالا - تعداد — ثبت سفارش\n/myid — نمایش شناسه گفتگو',quiz:'/quiz — سؤال مسابقه\n/score — نمایش امتیاز\n/leaderboard — جدول رتبه‌بندی\n/myid — نمایش شناسه گفتگو'};
  html+=`<div class="panel-card"><h3>دستورهای این ربات</h3><p>${(commands[t.id]||'').replace(/\n/g,'<br>')}</p></div>`;
  return html;
}
async function persistBotConfig(){const bot=getActiveBot();if(!bot)return;$$('[data-config]').forEach(el=>bot.config[el.dataset.config]=el.value);$$('[data-config-toggle]').forEach(el=>bot.config[el.dataset.configToggle]=el.checked);saveData();if(window.AppMint?.updateBackgroundBotConfig){try{await window.AppMint.updateBackgroundBotConfig({id:bot.id,config:bot.config});toast('تنظیمات ذخیره و با مخزن امن اندروید همگام شد.','success');}catch(e){toast('تنظیمات روی صفحه ذخیره شد؛ مخزن اندروید برای این ربات در دسترس نیست.','info');}}else toast('تنظیمات ذخیره شد.','success');addLog(bot.id,'info','تنظیمات به‌روزرسانی شد','تنظیمات قالب ربات ذخیره شد.');renderBotDetail();}
async function toggleBot(){const bot=getActiveBot();if(!bot)return;if(state.runtime.has(bot.id)){stopBot(bot.id);toast('ربات متوقف شد.');return;}await startBot(bot);}
function parseNativeJson(raw){if(typeof raw==='string'){try{return JSON.parse(raw);}catch(e){return {};}}return raw||{};}
async function startBot(bot){
  if(state.vaultPromise)await state.vaultPromise;
  if(state.runtime.has(bot.id))return;
  const token=await decryptToken(bot);
  if(!token&&window.AppMint&&typeof window.AppMint.resumeBackgroundBot==='function'){
    try{const response=parseNativeJson(await window.AppMint.resumeBackgroundBot(bot.id));state.runtime.set(bot.id,{native:true});bot.backgroundEnabled=true;bot.lastError='';saveData();addLog(bot.id,'success','اجرای پس‌زمینه از سر گرفته شد','توکن رمزنگاری‌شده از مخزن امن اندروید بازیابی شد.');if(response.notificationPermission===false)toast('ربات فعال شد؛ مجوز اعلان رد شده است.','info');else toast('ربات دوباره در پس‌زمینه فعال شد.','success');renderBotDetail();renderMyBots();renderHome();return;}catch(error){toast(error.message||'توکن در دسترس نیست؛ دوباره آن را متصل کن.','error');return;}
  }
  if(!token){toast('توکن این ربات در دسترس نیست. دوباره آن را متصل کن.','error');addLog(bot.id,'error','توکن در دسترس نیست','برای راه‌اندازی دوباره باید توکن ربات را وارد کنی.');return;}
  if(window.AppMint&&typeof window.AppMint.startBackgroundBot==='function'){
    try{
      const response=parseNativeJson(await window.AppMint.startBackgroundBot({id:bot.id,name:bot.name,templateId:bot.templateId,token,config:bot.config||{},offsetId:bot.offsetId||''}));
      state.runtime.set(bot.id,{native:true});bot.backgroundEnabled=true;bot.lastError='';saveData();
      addLog(bot.id,'success','اجرای پس‌زمینه روشن شد','سرویس اندروید دریافت پیام را حتی بعد از بستن صفحه ادامه می‌دهد.');
      if(response.notificationPermission===false)toast('ربات فعال شد؛ مجوز اعلان رد شده است. وضعیت سرویس در بخش برنامه‌های فعال اندروید دیده می‌شود.','info');
      else toast('ربات در پس‌زمینه فعال شد. اعلان دائمی AppMint را می‌بینی.','success');
      renderBotDetail();renderMyBots();renderHome();return;
    }catch(error){toast('اجرای پس‌زمینه شروع نشد: '+(error.message||'خطای نامشخص'),'error');addLog(bot.id,'error','شروع پس‌زمینه ناموفق بود',error.message||'خطای نامشخص');return;}
  }
  // Web fallback is provided for browser previews only; Android builds use the native foreground service.
  const runtime={stopped:false,token,loop:null,busy:false,lastErrorAt:0,native:false};state.runtime.set(bot.id,runtime);bot.lastError='';saveData();
  const loop=async()=>{if(runtime.stopped)return;runtime.busy=true;try{const payload={limit:50};if(bot.offsetId)payload.offset_id=bot.offsetId;const result=await rubikaRequest(token,'getUpdates',payload);const updates=Array.isArray(result?.updates)?result.updates:[];if(result?.next_offset_id)bot.offsetId=String(result.next_offset_id);else if(result?.nextOffsetId)bot.offsetId=String(result.nextOffsetId);if(updates.length){bot.totalUpdates=(bot.totalUpdates||0)+updates.length;for(const update of updates){try{await processUpdate(bot,token,update);}catch(err){addLog(bot.id,'error','خطا در پردازش آپدیت',err.message||'خطای نامشخص');}}saveData();}else if(result?.next_offset_id||result?.nextOffsetId)saveData();bot.lastError='';}catch(err){bot.lastError=err.message||'خطای ارتباط با روبیکا';if(Date.now()-runtime.lastErrorAt>20000){addLog(bot.id,'error','خطای دریافت آپدیت',bot.lastError);runtime.lastErrorAt=Date.now();}saveData();}runtime.busy=false;if(!runtime.stopped)runtime.loop=setTimeout(loop,getPollIntervalMs());};
  addLog(bot.id,'success','ربات در پیش‌نمایش شروع شد','در نسخه مرورگر، اجرا فقط تا بازبودن صفحه ادامه دارد.');renderBotDetail();renderMyBots();runtime.loop=setTimeout(loop,0);
}
function stopBot(botId,removeCredentials=false){
  const runtime=state.runtime.get(botId);
  if(window.AppMint){
    const action=removeCredentials?'removeBackgroundBot':'stopBackgroundBot';
    if(typeof window.AppMint[action]==='function')window.AppMint[action](botId).catch(e=>toast((removeCredentials?'پاک‌کردن اطلاعات':'توقف سرویس')+' ناموفق بود: '+e.message,'error'));
  }else if(runtime){runtime.stopped=true;clearTimeout(runtime.loop);}
  state.runtime.delete(botId);
  const bot=state.bots.find(b=>b.id===botId);
  if(bot){bot.backgroundEnabled=false;addLog(botId,'info',removeCredentials?'ربات حذف شد':'ربات متوقف شد',removeCredentials?'اطلاعات امن این ربات هم پاک شد.':'سرویس دریافت پیام متوقف شد.');}
  saveData();renderBotDetail();renderMyBots();renderHome();
}
async function restoreBackgroundStatus(attempt=0){
  if(!window.AppMint?.getBackgroundStatus){if(attempt<12){setTimeout(()=>restoreBackgroundStatus(attempt+1),350);return;}return;}
  try{const status=parseNativeJson(await window.AppMint.getBackgroundStatus());const ids=new Set(Array.isArray(status.ids)?status.ids:[]);const stats=new Map((Array.isArray(status.bots)?status.bots:[]).map(item=>[item.id,item]));state.bots.forEach(bot=>{if(ids.has(bot.id)){state.runtime.set(bot.id,{native:true});bot.backgroundEnabled=true;}else{state.runtime.delete(bot.id);bot.backgroundEnabled=false;}const saved=stats.get(bot.id);if(saved){bot.totalUpdates=saved.totalUpdates||0;bot.totalActions=saved.totalActions||0;bot.lastError=saved.lastError||'';}});saveData();renderHome();renderMyBots();if(state.page==='bot-detail')renderBotDetail();if(ids.size&&!status.notificationPermission)toast('ربات‌های پس‌زمینه فعال‌اند؛ مجوز اعلان داده نشده و اعلان دائمی در نوار اعلان نمایش داده نمی‌شود.','info');}catch(error){console.warn('Background status unavailable',error);}
}

async function processUpdate(bot,token,update){
  const msg=update?.new_message;const chatId=update.chat_id||msg?.chat_id;if(!chatId)return;
  const cfg=bot.config||{};const template=bot.templateId;
  if(update.type==='StartedBot' && ['auto_reply','shop'].includes(template)){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:cfg.welcomeMessage||`سلام! من ${bot.name} هستم. برای راهنما /help رو بفرست.`});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','پیام شروع ارسال شد','کاربر گفت‌وگو با ربات را آغاز کرد.');return;}
  if(update.type!=='NewMessage'||!msg||msg.sender_type==='Bot')return;const text=String(msg.text||'').trim();const messageId=msg.message_id;const senderId=msg.sender_id;
  if(!text)return;
  const command=text.split(/\s+/,1)[0].replace(/@.*$/,'').toLowerCase();
  if(command==='/myid'){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:'🆔 شناسه این گفتگو:\n'+chatId+'\n\n👤 شناسه کاربر:\n'+(senderId||'نامشخص')+'\n\nاین شناسه را فقط در تنظیمات مدیر فروشگاه وارد کن.',reply_to_message_id:messageId});return;}
  if(template==='guardian'){
    const words=String(cfg.blockedWords||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
    const containsBad=cfg.filterWords!==false&&words.some(w=>w&&text.toLocaleLowerCase('fa').includes(w.toLocaleLowerCase('fa')));const hasLink=cfg.filterLinks===true&&/(https?:\/\/|www\.)/i.test(text);
    if((containsBad||hasLink)&&messageId){await rubikaRequest(token,'deleteMessage',{chat_id:chatId,message_id:messageId});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','پیام حذف شد',containsBad?'پیام شامل کلمه فیلترشده بود.':'پیام شامل لینک بود.');return;}
  }
  if(text==='/start'||text==='/help'){
    const greeting=cfg.welcomeMessage||`سلام! من ${bot.name} هستم.\nبرای راهنما /help رو بفرست.`;await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:greeting});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','پاسخ به دستور',`دستور ${text} پاسخ داده شد.`);return;
  }
  if(template==='shop'&&(text==='/products'||text==='محصولات')){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:cfg.shopProducts||'فهرست محصولات در تنظیمات فروشگاه ثبت نشده است.',reply_to_message_id:messageId});return;}
  if(template==='shop'&&(text.startsWith('/order')||text.startsWith('سفارش '))){const order=text.replace(/^\/order\s*/,'').replace(/^سفارش\s*/,'').trim();if(!order){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:'برای ثبت سفارش بنویس: /order نام کالا - تعداد',reply_to_message_id:messageId});return;}await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:'✅ درخواست سفارش شما ثبت شد.\nجزئیات: '+order+'\nپشتیبانی به‌زودی پیگیری می‌کند.',reply_to_message_id:messageId});if(cfg.adminChatId)await rubikaRequest(token,'sendMessage',{chat_id:cfg.adminChatId,text:'🛍 سفارش جدید از '+senderId+'\nچت مشتری: '+chatId+'\nجزئیات: '+order});return;}
  if(template==='auto_reply'||template==='shop'){
    const rules=String(cfg.replyRules||'').split(/\r?\n/).map(line=>{const i=line.indexOf('=');return i>0?{key:line.slice(0,i).trim(),value:line.slice(i+1).trim()}:null;}).filter(Boolean);
    const match=rules.find(r=>r.key&&text.toLocaleLowerCase('fa').includes(r.key.toLocaleLowerCase('fa')));if(match){await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:match.value,reply_to_message_id:messageId});bot.totalActions=(bot.totalActions||0)+1;addLog(bot.id,'success','پاسخ خودکار ارسال شد',`کلیدواژه: ${match.key}`);return;}
    if(template==='auto_reply'&&cfg.fallbackReply)await rubikaRequest(token,'sendMessage',{chat_id:chatId,text:cfg.fallbackReply,reply_to_message_id:messageId});
  }
  if(text.startsWith('/'))addLog(bot.id,'info','دستور دریافت شد',text.slice(0,100));
}
async function runBotMethod(method,payload,successMessage){
  const bot=getActiveBot();if(!bot)return;const token=await decryptToken(bot);
  try{if(token)await rubikaRequest(token,method,payload);else if(window.AppMint?.rubikaRequestForBot)await window.AppMint.rubikaRequestForBot({id:bot.id,method,payload});else throw new Error('توکن در دسترس نیست؛ دوباره آن را متصل کن.');bot.totalActions=(bot.totalActions||0)+1;bot.lastError='';addLog(bot.id,'success',successMessage,'درخواست با موفقیت به API روبیکا ارسال شد.');toast(successMessage,'success');renderBotDetail();}
  catch(e){addLog(bot.id,'error','عملیات ناموفق بود',e.message);toast('خطا: '+e.message,'error');}
}
function confirmAction(message,yesLabel,action){openModal(`<h2 class="modal-title" id="modalTitle">تأیید عملیات</h2><p class="modal-subtitle">${escapeHtml(message)}</p><div class="modal-actions"><button class="outline-button" id="cancelConfirm">انصراف</button><button class="primary-button" id="confirmDo">${escapeHtml(yesLabel)}</button></div>`);$('#cancelConfirm').onclick=closeModal;$('#confirmDo').onclick=()=>{closeModal();action();};}
function bindEvents(){
  $('#brandHome').onclick=()=>showPage('home');$('#heroCreate').onclick=()=>openCreateModal();$('#myBotsCreate').onclick=()=>openCreateModal();$('#navCreate').onclick=()=>openCreateModal();$('#emptyCreate').onclick=()=>openCreateModal();$('#modalClose').onclick=closeModal;$('#modalBackdrop').addEventListener('click',e=>{if(e.target===$('#modalBackdrop'))closeModal();});
  $$('[data-nav]').forEach(el=>el.addEventListener('click',()=>showPage(el.dataset.nav)));
  $('#templateFilters').addEventListener('click',e=>{const btn=e.target.closest('[data-filter]');if(!btn)return;state.filter=btn.dataset.filter;$$('[data-filter]').forEach(b=>b.classList.toggle('active',b===btn));renderTemplates();});
  $('#templateSearch').addEventListener('input',e=>{state.search=e.target.value;renderTemplates();});
  document.addEventListener('click',e=>{
    const template=e.target.closest('[data-template]');if(template){openCreateModal(template.dataset.template);return;}
    const pick=e.target.closest('[data-pick-template]');if(pick){state.selectedTemplate=pick.dataset.pickTemplate;openCreateModal(state.selectedTemplate);return;}
    const bot=e.target.closest('[data-bot]');if(bot){openBot(bot.dataset.bot);return;}
  });
  // The create modal is rendered dynamically, so its Continue button must use delegation.
  document.addEventListener('click',e=>{if(e.target.closest('#continueCreate'))showTokenStep();});
  $('#toggleBotRun').onclick=toggleBot;
  $('#reconnectBot').onclick=openReconnectModal;
  $('#backFromBot').onclick=()=>showPage('mybots');
  $('#deleteBot').onclick=()=>{const bot=getActiveBot();if(!bot)return;confirmAction(`ربات «${bot.name}» و تنظیمات محلی آن حذف شود؟ این کار ربات را از روبیکا حذف نمی‌کند.`, 'حذف ربات',()=>{stopBot(bot.id,true);state.memoryTokens.delete(bot.id);state.bots=state.bots.filter(b=>b.id!==bot.id);saveData();addLog('','info','ربات از AppMint حذف شد',bot.name);showPage('mybots');toast('ربات از فهرست AppMint حذف شد.');});};
  $('#detailTabs').addEventListener('click',e=>{const btn=e.target.closest('[data-tab]');if(!btn)return;$$('[data-tab]').forEach(b=>b.classList.toggle('active',b===btn));$$('.detail-panel').forEach(p=>p.classList.toggle('active',p.id==='detail-'+btn.dataset.tab));});
  $('#editBotConfig').onclick=()=>{ $$('#detailTabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab==='config'));$$('.detail-panel').forEach(p=>p.classList.toggle('active',p.id==='detail-config'));};
  $('#detail-config').addEventListener('click',e=>{if(e.target.id==='saveBotConfig')persistBotConfig();});
  $('#detail-tools').addEventListener('click',e=>{
    if(e.target.id==='sendPanelMessage'){const chat=$('#toolChatId').value.trim(),text=$('#toolMessage').value.trim();if(!chat||!text){toast('شناسه چت و متن پیام را وارد کن.','error');return;}runBotMethod('sendMessage',{chat_id:chat,text},'پیام ارسال شد');}
    if(e.target.id==='deleteTargetMessage'){const chat=$('#modChatId').value.trim(),msg=$('#modMessageId').value.trim();if(!chat||!msg){toast('شناسه چت و پیام را کامل کن.','error');return;}confirmAction('این پیام از چت روبیکا حذف شود؟','حذف پیام',()=>runBotMethod('deleteMessage',{chat_id:chat,message_id:msg},'پیام حذف شد'));}
    if(e.target.id==='banTargetUser'||e.target.id==='unbanTargetUser'){const chat=$('#modChatId').value.trim(),user=$('#modUserId').value.trim();if(!chat||!user){toast('شناسه چت و کاربر را وارد کن.','error');return;}const ban=e.target.id==='banTargetUser';confirmAction(ban?'این کاربر از گروه/کانال مسدود شود؟':'مسدودیت این کاربر برداشته شود؟',ban?'مسدودسازی':'رفع مسدودیت',()=>runBotMethod(ban?'banChatMember':'unbanChatMember',{chat_id:chat,user_id:user},ban?'کاربر مسدود شد':'رفع مسدودیت انجام شد'));}
    if(e.target.id==='sendQuizQuestion'){const chat=$('#quizChatId').value.trim(),bot=getActiveBot();if(!chat){toast('شناسه چت را وارد کن.','error');return;}runBotMethod('sendMessage',{chat_id:chat,text:'🧠 چالش مسابقه\n'+(bot.config.quizQuestion||'سؤال مسابقه')+'\n\nجوابت رو بفرست!'},'سؤال مسابقه ارسال شد');}
  });
  $('#clearLogs').onclick=()=>confirmAction('تمام گزارش‌های ذخیره‌شده در AppMint پاک شوند؟','پاک‌کردن گزارش‌ها',()=>{state.logs=[];saveData();renderActivity();toast('گزارش‌ها پاک شدند.');});
  $('#helpButton').onclick=()=>{openModal(`<h2 class="modal-title" id="modalTitle">راهنمای شروع AppMint</h2><p class="modal-subtitle">۱. در BotFather روبیکا یک ربات بساز و توکنش را بگیر.<br>۲. در AppMint قالب دلخواهت را انتخاب و توکن را متصل کن.<br>۳. برای امکانات گروه، ربات را دستی به گروه اضافه و دسترسی‌های لازم را فعال کن.<br>۴. ربات را از پنل روشن کن؛ سرویس اندروید با اعلان دائمی حتی پس از بستن صفحه کار می‌کند.</p><div class="warning-box">AppMint نمی‌تواند خودش از طرف روبیکا توکن صادر کند. هر ربات باید قبلاً در BotFather ساخته شده باشد.</div><div class="modal-actions"><button class="primary-button" id="helpClose">متوجه شدم</button></div>`);$('#helpClose').onclick=closeModal;};
  $('#privacyInfo').onclick=()=>openModal(`<h2 class="modal-title" id="modalTitle">حریم خصوصی</h2><p class="modal-subtitle">تنظیمات، نام ربات‌ها و گزارش‌ها در فضای محلی همین دستگاه ذخیره می‌شوند. توکن‌ها به‌صورت متن ساده در فایل تنظیمات ذخیره نمی‌شوند. در صورت پشتیبانی Web Crypto، توکن با AES-GCM رمزنگاری و کلید غیرقابل‌استخراج در IndexedDB نگهداری می‌شود. برای اجرای پس‌زمینه، نسخه اندروید توکن را جداگانه با Android Keystore و رمزنگاری AES-GCM نگهداری می‌کند.</p><div class="warning-box">هر شخصی که به گوشی یا محیط WebView دسترسی کامل داشته باشد ممکن است به داده‌های برنامه دسترسی پیدا کند؛ قفل دستگاه و نگهداری امن توکن ضروری است.</div>`);
  $('#apiInfo').onclick=()=>window.location.assign('https://rubika.ir/botapi/methods');
  $('#contactUs').onclick=()=>window.location.assign(CONTACT_URL);
  $('#pollIntervalSelect').addEventListener('change',e=>applyPollInterval(e.target.value));
  $('#exportData').onclick=()=>{const blob=new Blob([JSON.stringify({bots:state.bots.map(({tokenVault,...b})=>({...b,tokenVault:undefined})),logs:state.logs},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='appmint-settings.json';a.click();URL.revokeObjectURL(a.href);toast('فایل تنظیمات بدون توکن آماده شد.','success');};
  $('#resetApp').onclick=()=>confirmAction('همه ربات‌ها و گزارش‌های AppMint از این دستگاه پاک شوند؟ این کار ربات‌ها را از روبیکا حذف یا متوقف نمی‌کند.', 'پاک‌کردن همه اطلاعات',()=>{[...state.runtime.keys()].forEach(id=>stopBot(id,true));state.bots=[];state.logs=[];state.memoryTokens.clear();localStorage.removeItem(APP_DATA_KEY);saveData();showPage('home');toast('اطلاعات محلی پاک شد.');});
}
function init(){loadData();state.vaultPromise=openVault();$('#todayLabel').textContent=todayFa();bindEvents();renderHome();renderTemplates();renderMyBots();renderActivity();renderSettings();setTimeout(()=>restoreBackgroundStatus(),400);}
init();
