# No custom shrinking rules are needed for the current WebView-based build.
